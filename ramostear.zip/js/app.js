!function (t) {
    var e = {};

    function n(r) {
        if (e[r]) return e[r].exports;
        var i = e[r] = {i: r, l: !1, exports: {}};
        return t[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports
    }

    n.m = t, n.c = e, n.d = function (t, e, r) {
        n.o(t, e) || Object.defineProperty(t, e, {enumerable: !0, get: r})
    }, n.r = function (t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {value: "Module"}), Object.defineProperty(t, "__esModule", {value: !0})
    }, n.t = function (t, e) {
        if (1 & e && (t = n(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
            enumerable: !0,
            value: t
        }), 2 & e && "string" != typeof t) for (var i in t) n.d(r, i, function (e) {
            return t[e]
        }.bind(null, i));
        return r
    }, n.n = function (t) {
        var e = t && t.__esModule ? function () {
            return t.default
        } : function () {
            return t
        };
        return n.d(e, "a", e), e
    }, n.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, n.p = "", n(n.s = 48)
}([function (t, e, n) {
    var r, i;
    /*!
* svg.js - A lightweight library for manipulating and animating SVG.
* @version 2.7.1
* https://svgdotjs.github.io/
*
* @copyright Wout Fierens <wout@mick-wout.com>
* @license MIT
*
* BUILT: Fri Nov 30 2018 10:01:55 GMT+0100 (GMT+01:00)
*/
    i = "undefined" != typeof window ? window : this, void 0 === (r = function () {
        return function (t, e) {
            var n = (void 0 !== this ? this : t).SVG = function (t) {
                if (n.supported) return t = new n.Doc(t), n.parser.draw || n.prepare(), t
            };
            if (n.ns = "http://www.w3.org/2000/svg", n.xmlns = "http://www.w3.org/2000/xmlns/", n.xlink = "http://www.w3.org/1999/xlink", n.svgjs = "http://svgjs.com/svgjs", n.supported = !!e.createElementNS && !!e.createElementNS(n.ns, "svg").createSVGRect, !n.supported) return !1;
            n.did = 1e3, n.eid = function (t) {
                return "Svgjs" + u(t) + n.did++
            }, n.create = function (t) {
                var n = e.createElementNS(this.ns, t);
                return n.setAttribute("id", this.eid(t)), n
            }, n.extend = function () {
                var t, e, r, i;
                for (t = [].slice.call(arguments), e = t.pop(), i = t.length - 1; i >= 0; i--) if (t[i]) for (r in e) t[i].prototype[r] = e[r];
                n.Set && n.Set.inherit && n.Set.inherit()
            }, n.invent = function (t) {
                var e = "function" == typeof t.create ? t.create : function () {
                    this.constructor.call(this, n.create(t.create))
                };
                return t.inherit && (e.prototype = new t.inherit), t.extend && n.extend(e, t.extend), t.construct && n.extend(t.parent || n.Container, t.construct), e
            }, n.adopt = function (e) {
                return e ? e.instance ? e.instance : ((r = "svg" == e.nodeName ? e.parentNode instanceof t.SVGElement ? new n.Nested : new n.Doc : "linearGradient" == e.nodeName ? new n.Gradient("linear") : "radialGradient" == e.nodeName ? new n.Gradient("radial") : n[u(e.nodeName)] ? new (n[u(e.nodeName)]) : new n.Element(e)).type = e.nodeName, r.node = e, e.instance = r, r instanceof n.Doc && r.namespace().defs(), r.setData(JSON.parse(e.getAttribute("svgjs:data")) || {}), r) : null;
                var r
            }, n.prepare = function () {
                var t = e.getElementsByTagName("body")[0],
                    r = (t ? new n.Doc(t) : n.adopt(e.documentElement).nested()).size(2, 0);
                n.parser = {
                    body: t || e.documentElement,
                    draw: r.style("opacity:0;position:absolute;left:-100%;top:-100%;overflow:hidden").attr("focusable", "false").node,
                    poly: r.polyline().node,
                    path: r.path().node,
                    native: n.create("svg")
                }
            }, n.parser = {native: n.create("svg")}, e.addEventListener("DOMContentLoaded", function () {
                n.parser.draw || n.prepare()
            }, !1), n.regex = {
                numberAndUnit: /^([+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?)([a-z%]*)$/i,
                hex: /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i,
                rgb: /rgb\((\d+),(\d+),(\d+)\)/,
                reference: /#([a-z0-9\-_]+)/i,
                transforms: /\)\s*,?\s*/,
                whitespace: /\s/g,
                isHex: /^#[a-f0-9]{3,6}$/i,
                isRgb: /^rgb\(/,
                isCss: /[^:]+:[^;]+;?/,
                isBlank: /^(\s+)?$/,
                isNumber: /^[+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i,
                isPercent: /^-?[\d\.]+%$/,
                isImage: /\.(jpg|jpeg|png|gif|svg)(\?[^=]+.*)?/i,
                delimiter: /[\s,]+/,
                hyphen: /([^e])\-/gi,
                pathLetters: /[MLHVCSQTAZ]/gi,
                isPathLetter: /[MLHVCSQTAZ]/i,
                numbersWithDots: /((\d?\.\d+(?:e[+-]?\d+)?)((?:\.\d+(?:e[+-]?\d+)?)+))+/gi,
                dots: /\./g
            }, n.utils = {
                map: function (t, e) {
                    var n, r = t.length, i = [];
                    for (n = 0; n < r; n++) i.push(e(t[n]));
                    return i
                }, filter: function (t, e) {
                    var n, r = t.length, i = [];
                    for (n = 0; n < r; n++) e(t[n]) && i.push(t[n]);
                    return i
                }, radians: function (t) {
                    return t % 360 * Math.PI / 180
                }, degrees: function (t) {
                    return 180 * t / Math.PI % 360
                }, filterSVGElements: function (e) {
                    return this.filter(e, function (e) {
                        return e instanceof t.SVGElement
                    })
                }
            }, n.defaults = {
                attrs: {
                    "fill-opacity": 1,
                    "stroke-opacity": 1,
                    "stroke-width": 0,
                    "stroke-linejoin": "miter",
                    "stroke-linecap": "butt",
                    fill: "#000000",
                    stroke: "#000000",
                    opacity: 1,
                    x: 0,
                    y: 0,
                    cx: 0,
                    cy: 0,
                    width: 0,
                    height: 0,
                    r: 0,
                    rx: 0,
                    ry: 0,
                    offset: 0,
                    "stop-opacity": 1,
                    "stop-color": "#000000",
                    "font-size": 16,
                    "font-family": "Helvetica, Arial, sans-serif",
                    "text-anchor": "start"
                }
            }, n.Color = function (t) {
                var e, r;
                this.r = 0, this.g = 0, this.b = 0, t && ("string" == typeof t ? n.regex.isRgb.test(t) ? (e = n.regex.rgb.exec(t.replace(n.regex.whitespace, "")), this.r = parseInt(e[1]), this.g = parseInt(e[2]), this.b = parseInt(e[3])) : n.regex.isHex.test(t) && (e = n.regex.hex.exec(4 == (r = t).length ? ["#", r.substring(1, 2), r.substring(1, 2), r.substring(2, 3), r.substring(2, 3), r.substring(3, 4), r.substring(3, 4)].join("") : r), this.r = parseInt(e[1], 16), this.g = parseInt(e[2], 16), this.b = parseInt(e[3], 16)) : "object" == typeof t && (this.r = t.r, this.g = t.g, this.b = t.b))
            }, n.extend(n.Color, {
                toString: function () {
                    return this.toHex()
                }, toHex: function () {
                    return "#" + h(this.r) + h(this.g) + h(this.b)
                }, toRgb: function () {
                    return "rgb(" + [this.r, this.g, this.b].join() + ")"
                }, brightness: function () {
                    return this.r / 255 * .3 + this.g / 255 * .59 + this.b / 255 * .11
                }, morph: function (t) {
                    return this.destination = new n.Color(t), this
                }, at: function (t) {
                    return this.destination ? (t = t < 0 ? 0 : t > 1 ? 1 : t, new n.Color({
                        r: ~~(this.r + (this.destination.r - this.r) * t),
                        g: ~~(this.g + (this.destination.g - this.g) * t),
                        b: ~~(this.b + (this.destination.b - this.b) * t)
                    })) : this
                }
            }), n.Color.test = function (t) {
                return t += "", n.regex.isHex.test(t) || n.regex.isRgb.test(t)
            }, n.Color.isRgb = function (t) {
                return t && "number" == typeof t.r && "number" == typeof t.g && "number" == typeof t.b
            }, n.Color.isColor = function (t) {
                return n.Color.isRgb(t) || n.Color.test(t)
            }, n.Array = function (t, e) {
                0 == (t = (t || []).valueOf()).length && e && (t = e.valueOf()), this.value = this.parse(t)
            }, n.extend(n.Array, {
                morph: function (t) {
                    if (this.destination = this.parse(t), this.value.length != this.destination.length) {
                        for (var e = this.value[this.value.length - 1], n = this.destination[this.destination.length - 1]; this.value.length > this.destination.length;) this.destination.push(n);
                        for (; this.value.length < this.destination.length;) this.value.push(e)
                    }
                    return this
                }, settle: function () {
                    for (var t = 0, e = this.value.length, n = []; t < e; t++) -1 == n.indexOf(this.value[t]) && n.push(this.value[t]);
                    return this.value = n
                }, at: function (t) {
                    if (!this.destination) return this;
                    for (var e = 0, r = this.value.length, i = []; e < r; e++) i.push(this.value[e] + (this.destination[e] - this.value[e]) * t);
                    return new n.Array(i)
                }, toString: function () {
                    return this.value.join(" ")
                }, valueOf: function () {
                    return this.value
                }, parse: function (t) {
                    return t = t.valueOf(), Array.isArray(t) ? t : this.split(t)
                }, split: function (t) {
                    return t.trim().split(n.regex.delimiter).map(parseFloat)
                }, reverse: function () {
                    return this.value.reverse(), this
                }, clone: function () {
                    var t = new this.constructor;
                    return t.value = function t(e) {
                        for (var n = e.slice(0), r = n.length; r--;) Array.isArray(n[r]) && (n[r] = t(n[r]));
                        return n
                    }(this.value), t
                }
            }), n.PointArray = function (t, e) {
                n.Array.call(this, t, e || [[0, 0]])
            }, n.PointArray.prototype = new n.Array, n.PointArray.prototype.constructor = n.PointArray, n.extend(n.PointArray, {
                toString: function () {
                    for (var t = 0, e = this.value.length, n = []; t < e; t++) n.push(this.value[t].join(","));
                    return n.join(" ")
                }, toLine: function () {
                    return {x1: this.value[0][0], y1: this.value[0][1], x2: this.value[1][0], y2: this.value[1][1]}
                }, at: function (t) {
                    if (!this.destination) return this;
                    for (var e = 0, r = this.value.length, i = []; e < r; e++) i.push([this.value[e][0] + (this.destination[e][0] - this.value[e][0]) * t, this.value[e][1] + (this.destination[e][1] - this.value[e][1]) * t]);
                    return new n.PointArray(i)
                }, parse: function (t) {
                    var e = [];
                    if (t = t.valueOf(), Array.isArray(t)) {
                        if (Array.isArray(t[0])) return t.map(function (t) {
                            return t.slice()
                        });
                        if (null != t[0].x) return t.map(function (t) {
                            return [t.x, t.y]
                        })
                    } else t = t.trim().split(n.regex.delimiter).map(parseFloat);
                    t.length % 2 != 0 && t.pop();
                    for (var r = 0, i = t.length; r < i; r += 2) e.push([t[r], t[r + 1]]);
                    return e
                }, move: function (t, e) {
                    var n = this.bbox();
                    if (t -= n.x, e -= n.y, !isNaN(t) && !isNaN(e)) for (var r = this.value.length - 1; r >= 0; r--) this.value[r] = [this.value[r][0] + t, this.value[r][1] + e];
                    return this
                }, size: function (t, e) {
                    var n, r = this.bbox();
                    for (n = this.value.length - 1; n >= 0; n--) r.width && (this.value[n][0] = (this.value[n][0] - r.x) * t / r.width + r.x), r.height && (this.value[n][1] = (this.value[n][1] - r.y) * e / r.height + r.y);
                    return this
                }, bbox: function () {
                    return n.parser.poly.setAttribute("points", this.toString()), n.parser.poly.getBBox()
                }
            });
            for (var r = {
                M: function (t, e, n) {
                    return e.x = n.x = t[0], e.y = n.y = t[1], ["M", e.x, e.y]
                }, L: function (t, e) {
                    return e.x = t[0], e.y = t[1], ["L", t[0], t[1]]
                }, H: function (t, e) {
                    return e.x = t[0], ["H", t[0]]
                }, V: function (t, e) {
                    return e.y = t[0], ["V", t[0]]
                }, C: function (t, e) {
                    return e.x = t[4], e.y = t[5], ["C", t[0], t[1], t[2], t[3], t[4], t[5]]
                }, S: function (t, e) {
                    return e.x = t[2], e.y = t[3], ["S", t[0], t[1], t[2], t[3]]
                }, Q: function (t, e) {
                    return e.x = t[2], e.y = t[3], ["Q", t[0], t[1], t[2], t[3]]
                }, T: function (t, e) {
                    return e.x = t[0], e.y = t[1], ["T", t[0], t[1]]
                }, Z: function (t, e, n) {
                    return e.x = n.x, e.y = n.y, ["Z"]
                }, A: function (t, e) {
                    return e.x = t[5], e.y = t[6], ["A", t[0], t[1], t[2], t[3], t[4], t[5], t[6]]
                }
            }, i = "mlhvqtcsaz".split(""), o = 0, s = i.length; o < s; ++o) r[i[o]] = function (t) {
                return function (e, n, i) {
                    if ("H" == t) e[0] = e[0] + n.x; else if ("V" == t) e[0] = e[0] + n.y; else if ("A" == t) e[5] = e[5] + n.x, e[6] = e[6] + n.y; else for (var o = 0, s = e.length; o < s; ++o) e[o] = e[o] + (o % 2 ? n.y : n.x);
                    return r[t](e, n, i)
                }
            }(i[o].toUpperCase());
            n.PathArray = function (t, e) {
                n.Array.call(this, t, e || [["M", 0, 0]])
            }, n.PathArray.prototype = new n.Array, n.PathArray.prototype.constructor = n.PathArray, n.extend(n.PathArray, {
                toString: function () {
                    return function (t) {
                        for (var e = 0, n = t.length, r = ""; e < n; e++) r += t[e][0], null != t[e][1] && (r += t[e][1], null != t[e][2] && (r += " ", r += t[e][2], null != t[e][3] && (r += " ", r += t[e][3], r += " ", r += t[e][4], null != t[e][5] && (r += " ", r += t[e][5], r += " ", r += t[e][6], null != t[e][7] && (r += " ", r += t[e][7])))));
                        return r + " "
                    }(this.value)
                }, move: function (t, e) {
                    var n = this.bbox();
                    if (t -= n.x, e -= n.y, !isNaN(t) && !isNaN(e)) for (var r, i = this.value.length - 1; i >= 0; i--) "M" == (r = this.value[i][0]) || "L" == r || "T" == r ? (this.value[i][1] += t, this.value[i][2] += e) : "H" == r ? this.value[i][1] += t : "V" == r ? this.value[i][1] += e : "C" == r || "S" == r || "Q" == r ? (this.value[i][1] += t, this.value[i][2] += e, this.value[i][3] += t, this.value[i][4] += e, "C" == r && (this.value[i][5] += t, this.value[i][6] += e)) : "A" == r && (this.value[i][6] += t, this.value[i][7] += e);
                    return this
                }, size: function (t, e) {
                    var n, r, i = this.bbox();
                    for (n = this.value.length - 1; n >= 0; n--) "M" == (r = this.value[n][0]) || "L" == r || "T" == r ? (this.value[n][1] = (this.value[n][1] - i.x) * t / i.width + i.x, this.value[n][2] = (this.value[n][2] - i.y) * e / i.height + i.y) : "H" == r ? this.value[n][1] = (this.value[n][1] - i.x) * t / i.width + i.x : "V" == r ? this.value[n][1] = (this.value[n][1] - i.y) * e / i.height + i.y : "C" == r || "S" == r || "Q" == r ? (this.value[n][1] = (this.value[n][1] - i.x) * t / i.width + i.x, this.value[n][2] = (this.value[n][2] - i.y) * e / i.height + i.y, this.value[n][3] = (this.value[n][3] - i.x) * t / i.width + i.x, this.value[n][4] = (this.value[n][4] - i.y) * e / i.height + i.y, "C" == r && (this.value[n][5] = (this.value[n][5] - i.x) * t / i.width + i.x, this.value[n][6] = (this.value[n][6] - i.y) * e / i.height + i.y)) : "A" == r && (this.value[n][1] = this.value[n][1] * t / i.width, this.value[n][2] = this.value[n][2] * e / i.height, this.value[n][6] = (this.value[n][6] - i.x) * t / i.width + i.x, this.value[n][7] = (this.value[n][7] - i.y) * e / i.height + i.y);
                    return this
                }, equalCommands: function (t) {
                    var e, r, i;
                    for (t = new n.PathArray(t), i = this.value.length === t.value.length, e = 0, r = this.value.length; i && e < r; e++) i = this.value[e][0] === t.value[e][0];
                    return i
                }, morph: function (t) {
                    return t = new n.PathArray(t), this.equalCommands(t) ? this.destination = t : this.destination = null, this
                }, at: function (t) {
                    if (!this.destination) return this;
                    var e, r, i, o, s = this.value, a = this.destination.value, c = [], l = new n.PathArray;
                    for (e = 0, r = s.length; e < r; e++) {
                        for (c[e] = [s[e][0]], i = 1, o = s[e].length; i < o; i++) c[e][i] = s[e][i] + (a[e][i] - s[e][i]) * t;
                        "A" === c[e][0] && (c[e][4] = +(0 != c[e][4]), c[e][5] = +(0 != c[e][5]))
                    }
                    return l.value = c, l
                }, parse: function (t) {
                    if (t instanceof n.PathArray) return t.valueOf();
                    var e, i = {M: 2, L: 2, H: 1, V: 1, C: 6, S: 4, Q: 4, T: 2, A: 7, Z: 0};
                    t = "string" == typeof t ? t.replace(n.regex.numbersWithDots, c).replace(n.regex.pathLetters, " $& ").replace(n.regex.hyphen, "$1 -").trim().split(n.regex.delimiter) : t.reduce(function (t, e) {
                        return [].concat.call(t, e)
                    }, []);
                    var o = [], s = new n.Point, a = new n.Point, l = 0, u = t.length;
                    do {
                        n.regex.isPathLetter.test(t[l]) ? (e = t[l], ++l) : "M" == e ? e = "L" : "m" == e && (e = "l"), o.push(r[e].call(null, t.slice(l, l += i[e.toUpperCase()]).map(parseFloat), s, a))
                    } while (u > l);
                    return o
                }, bbox: function () {
                    return n.parser.path.setAttribute("d", this.toString()), n.parser.path.getBBox()
                }
            }), n.Number = n.invent({
                create: function (t, e) {
                    this.value = 0, this.unit = e || "", "number" == typeof t ? this.value = isNaN(t) ? 0 : isFinite(t) ? t : t < 0 ? -34e37 : 34e37 : "string" == typeof t ? (e = t.match(n.regex.numberAndUnit)) && (this.value = parseFloat(e[1]), "%" == e[5] ? this.value /= 100 : "s" == e[5] && (this.value *= 1e3), this.unit = e[5]) : t instanceof n.Number && (this.value = t.valueOf(), this.unit = t.unit)
                }, extend: {
                    toString: function () {
                        return ("%" == this.unit ? ~~(1e8 * this.value) / 1e6 : "s" == this.unit ? this.value / 1e3 : this.value) + this.unit
                    }, toJSON: function () {
                        return this.toString()
                    }, valueOf: function () {
                        return this.value
                    }, plus: function (t) {
                        return t = new n.Number(t), new n.Number(this + t, this.unit || t.unit)
                    }, minus: function (t) {
                        return t = new n.Number(t), new n.Number(this - t, this.unit || t.unit)
                    }, times: function (t) {
                        return t = new n.Number(t), new n.Number(this * t, this.unit || t.unit)
                    }, divide: function (t) {
                        return t = new n.Number(t), new n.Number(this / t, this.unit || t.unit)
                    }, to: function (t) {
                        var e = new n.Number(this);
                        return "string" == typeof t && (e.unit = t), e
                    }, morph: function (t) {
                        return this.destination = new n.Number(t), t.relative && (this.destination.value += this.value), this
                    }, at: function (t) {
                        return this.destination ? new n.Number(this.destination).minus(this).times(t).plus(this) : this
                    }
                }
            }), n.Element = n.invent({
                create: function (t) {
                    this._stroke = n.defaults.attrs.stroke, this._event = null, this._events = {}, this.dom = {}, (this.node = t) && (this.type = t.nodeName, this.node.instance = this, this._events = t._events || {}, this._stroke = t.getAttribute("stroke") || this._stroke)
                }, extend: {
                    x: function (t) {
                        return this.attr("x", t)
                    }, y: function (t) {
                        return this.attr("y", t)
                    }, cx: function (t) {
                        return null == t ? this.x() + this.width() / 2 : this.x(t - this.width() / 2)
                    }, cy: function (t) {
                        return null == t ? this.y() + this.height() / 2 : this.y(t - this.height() / 2)
                    }, move: function (t, e) {
                        return this.x(t).y(e)
                    }, center: function (t, e) {
                        return this.cx(t).cy(e)
                    }, width: function (t) {
                        return this.attr("width", t)
                    }, height: function (t) {
                        return this.attr("height", t)
                    }, size: function (t, e) {
                        var r = f(this, t, e);
                        return this.width(new n.Number(r.width)).height(new n.Number(r.height))
                    }, clone: function (t) {
                        this.writeDataToDom();
                        var e = m(this.node.cloneNode(!0));
                        return t ? t.add(e) : this.after(e), e
                    }, remove: function () {
                        return this.parent() && this.parent().removeElement(this), this
                    }, replace: function (t) {
                        return this.after(t).remove(), t
                    }, addTo: function (t) {
                        return t.put(this)
                    }, putIn: function (t) {
                        return t.add(this)
                    }, id: function (t) {
                        return this.attr("id", t)
                    }, inside: function (t, e) {
                        var n = this.bbox();
                        return t > n.x && e > n.y && t < n.x + n.width && e < n.y + n.height
                    }, show: function () {
                        return this.style("display", "")
                    }, hide: function () {
                        return this.style("display", "none")
                    }, visible: function () {
                        return "none" != this.style("display")
                    }, toString: function () {
                        return this.attr("id")
                    }, classes: function () {
                        var t = this.attr("class");
                        return null == t ? [] : t.trim().split(n.regex.delimiter)
                    }, hasClass: function (t) {
                        return -1 != this.classes().indexOf(t)
                    }, addClass: function (t) {
                        if (!this.hasClass(t)) {
                            var e = this.classes();
                            e.push(t), this.attr("class", e.join(" "))
                        }
                        return this
                    }, removeClass: function (t) {
                        return this.hasClass(t) && this.attr("class", this.classes().filter(function (e) {
                            return e != t
                        }).join(" ")), this
                    }, toggleClass: function (t) {
                        return this.hasClass(t) ? this.removeClass(t) : this.addClass(t)
                    }, reference: function (t) {
                        return n.get(this.attr(t))
                    }, parent: function (e) {
                        var r = this;
                        if (!r.node.parentNode) return null;
                        if (r = n.adopt(r.node.parentNode), !e) return r;
                        for (; r && r.node instanceof t.SVGElement;) {
                            if ("string" == typeof e ? r.matches(e) : r instanceof e) return r;
                            if (!r.node.parentNode || "#document" == r.node.parentNode.nodeName || "#document-fragment" == r.node.parentNode.nodeName) return null;
                            r = n.adopt(r.node.parentNode)
                        }
                    }, doc: function () {
                        return this instanceof n.Doc ? this : this.parent(n.Doc)
                    }, parents: function (t) {
                        var e = [], n = this;
                        do {
                            if (!(n = n.parent(t)) || !n.node) break;
                            e.push(n)
                        } while (n.parent);
                        return e
                    }, matches: function (t) {
                        return function (t, e) {
                            return (t.matches || t.matchesSelector || t.msMatchesSelector || t.mozMatchesSelector || t.webkitMatchesSelector || t.oMatchesSelector).call(t, e)
                        }(this.node, t)
                    }, native: function () {
                        return this.node
                    }, svg: function (t) {
                        var r = e.createElement("svg");
                        if (!(t && this instanceof n.Parent)) return r.appendChild(t = e.createElement("svg")), this.writeDataToDom(), t.appendChild(this.node.cloneNode(!0)), r.innerHTML.replace(/^<svg>/, "").replace(/<\/svg>$/, "");
                        r.innerHTML = "<svg>" + t.replace(/\n/, "").replace(/<([\w:-]+)([^<]+?)\/>/g, "<$1$2></$1>") + "</svg>";
                        for (var i = 0, o = r.firstChild.childNodes.length; i < o; i++) this.node.appendChild(r.firstChild.firstChild);
                        return this
                    }, writeDataToDom: function () {
                        if (this.each || this.lines) {
                            var t = this.each ? this : this.lines();
                            t.each(function () {
                                this.writeDataToDom()
                            })
                        }
                        return this.node.removeAttribute("svgjs:data"), Object.keys(this.dom).length && this.node.setAttribute("svgjs:data", JSON.stringify(this.dom)), this
                    }, setData: function (t) {
                        return this.dom = t, this
                    }, is: function (t) {
                        return function (t, e) {
                            return t instanceof e
                        }(this, t)
                    }
                }
            }), n.easing = {
                "-": function (t) {
                    return t
                }, "<>": function (t) {
                    return -Math.cos(t * Math.PI) / 2 + .5
                }, ">": function (t) {
                    return Math.sin(t * Math.PI / 2)
                }, "<": function (t) {
                    return 1 - Math.cos(t * Math.PI / 2)
                }
            }, n.morph = function (t) {
                return function (e, r) {
                    return new n.MorphObj(e, r).at(t)
                }
            }, n.Situation = n.invent({
                create: function (t) {
                    this.init = !1, this.reversed = !1, this.reversing = !1, this.duration = new n.Number(t.duration).valueOf(), this.delay = new n.Number(t.delay).valueOf(), this.start = +new Date + this.delay, this.finish = this.start + this.duration, this.ease = t.ease, this.loop = 0, this.loops = !1, this.animations = {}, this.attrs = {}, this.styles = {}, this.transforms = [], this.once = {}
                }
            }), n.FX = n.invent({
                create: function (t) {
                    this._target = t, this.situations = [], this.active = !1, this.situation = null, this.paused = !1, this.lastPos = 0, this.pos = 0, this.absPos = 0, this._speed = 1
                }, extend: {
                    animate: function (t, e, r) {
                        "object" == typeof t && (e = t.ease, r = t.delay, t = t.duration);
                        var i = new n.Situation({duration: t || 1e3, delay: r || 0, ease: n.easing[e || "-"] || e});
                        return this.queue(i), this
                    }, delay: function (t) {
                        var e = new n.Situation({duration: t, delay: 0, ease: n.easing["-"]});
                        return this.queue(e)
                    }, target: function (t) {
                        return t && t instanceof n.Element ? (this._target = t, this) : this._target
                    }, timeToAbsPos: function (t) {
                        return (t - this.situation.start) / (this.situation.duration / this._speed)
                    }, absPosToTime: function (t) {
                        return this.situation.duration / this._speed * t + this.situation.start
                    }, startAnimFrame: function () {
                        this.stopAnimFrame(), this.animationFrame = t.requestAnimationFrame(function () {
                            this.step()
                        }.bind(this))
                    }, stopAnimFrame: function () {
                        t.cancelAnimationFrame(this.animationFrame)
                    }, start: function () {
                        return !this.active && this.situation && (this.active = !0, this.startCurrent()), this
                    }, startCurrent: function () {
                        return this.situation.start = +new Date + this.situation.delay / this._speed, this.situation.finish = this.situation.start + this.situation.duration / this._speed, this.initAnimations().step()
                    }, queue: function (t) {
                        return ("function" == typeof t || t instanceof n.Situation) && this.situations.push(t), this.situation || (this.situation = this.situations.shift()), this
                    }, dequeue: function () {
                        return this.stop(), this.situation = this.situations.shift(), this.situation && (this.situation instanceof n.Situation ? this.start() : this.situation.call(this)), this
                    }, initAnimations: function () {
                        var t, e, r, i = this.situation;
                        if (i.init) return this;
                        for (t in i.animations) for (r = this.target()[t](), Array.isArray(r) || (r = [r]), Array.isArray(i.animations[t]) || (i.animations[t] = [i.animations[t]]), e = r.length; e--;) i.animations[t][e] instanceof n.Number && (r[e] = new n.Number(r[e])), i.animations[t][e] = r[e].morph(i.animations[t][e]);
                        for (t in i.attrs) i.attrs[t] = new n.MorphObj(this.target().attr(t), i.attrs[t]);
                        for (t in i.styles) i.styles[t] = new n.MorphObj(this.target().style(t), i.styles[t]);
                        return i.initialTransformation = this.target().matrixify(), i.init = !0, this
                    }, clearQueue: function () {
                        return this.situations = [], this
                    }, clearCurrent: function () {
                        return this.situation = null, this
                    }, stop: function (t, e) {
                        var n = this.active;
                        return this.active = !1, e && this.clearQueue(), t && this.situation && (!n && this.startCurrent(), this.atEnd()), this.stopAnimFrame(), this.clearCurrent()
                    }, reset: function () {
                        if (this.situation) {
                            var t = this.situation;
                            this.stop(), this.situation = t, this.atStart()
                        }
                        return this
                    }, finish: function () {
                        for (this.stop(!0, !1); this.dequeue().situation && this.stop(!0, !1);) ;
                        return this.clearQueue().clearCurrent(), this
                    }, atStart: function () {
                        return this.at(0, !0)
                    }, atEnd: function () {
                        return !0 === this.situation.loops && (this.situation.loops = this.situation.loop + 1), "number" == typeof this.situation.loops ? this.at(this.situation.loops, !0) : this.at(1, !0)
                    }, at: function (t, e) {
                        var n = this.situation.duration / this._speed;
                        return this.absPos = t, e || (this.situation.reversed && (this.absPos = 1 - this.absPos), this.absPos += this.situation.loop), this.situation.start = +new Date - this.absPos * n, this.situation.finish = this.situation.start + n, this.step(!0)
                    }, speed: function (t) {
                        return 0 === t ? this.pause() : t ? (this._speed = t, this.at(this.absPos, !0)) : this._speed
                    }, loop: function (t, e) {
                        var n = this.last();
                        return n.loops = null == t || t, n.loop = 0, e && (n.reversing = !0), this
                    }, pause: function () {
                        return this.paused = !0, this.stopAnimFrame(), this
                    }, play: function () {
                        return this.paused ? (this.paused = !1, this.at(this.absPos, !0)) : this
                    }, reverse: function (t) {
                        var e = this.last();
                        return e.reversed = void 0 === t ? !e.reversed : t, this
                    }, progress: function (t) {
                        return t ? this.situation.ease(this.pos) : this.pos
                    }, after: function (t) {
                        var e = this.last();
                        return this.target().on("finished.fx", function n(r) {
                            r.detail.situation == e && (t.call(this, e), this.off("finished.fx", n))
                        }), this._callStart()
                    }, during: function (t) {
                        var e = this.last(), r = function (r) {
                            r.detail.situation == e && t.call(this, r.detail.pos, n.morph(r.detail.pos), r.detail.eased, e)
                        };
                        return this.target().off("during.fx", r).on("during.fx", r), this.after(function () {
                            this.off("during.fx", r)
                        }), this._callStart()
                    }, afterAll: function (t) {
                        var e = function e(n) {
                            t.call(this), this.off("allfinished.fx", e)
                        };
                        return this.target().off("allfinished.fx", e).on("allfinished.fx", e), this._callStart()
                    }, duringAll: function (t) {
                        var e = function (e) {
                            t.call(this, e.detail.pos, n.morph(e.detail.pos), e.detail.eased, e.detail.situation)
                        };
                        return this.target().off("during.fx", e).on("during.fx", e), this.afterAll(function () {
                            this.off("during.fx", e)
                        }), this._callStart()
                    }, last: function () {
                        return this.situations.length ? this.situations[this.situations.length - 1] : this.situation
                    }, add: function (t, e, n) {
                        return this.last()[n || "animations"][t] = e, this._callStart()
                    }, step: function (t) {
                        var e, n, r;
                        t || (this.absPos = this.timeToAbsPos(+new Date)), !1 !== this.situation.loops ? (e = Math.max(this.absPos, 0), n = Math.floor(e), !0 === this.situation.loops || n < this.situation.loops ? (this.pos = e - n, r = this.situation.loop, this.situation.loop = n) : (this.absPos = this.situation.loops, this.pos = 1, r = this.situation.loop - 1, this.situation.loop = this.situation.loops), this.situation.reversing && (this.situation.reversed = this.situation.reversed != Boolean((this.situation.loop - r) % 2))) : (this.absPos = Math.min(this.absPos, 1), this.pos = this.absPos), this.pos < 0 && (this.pos = 0), this.situation.reversed && (this.pos = 1 - this.pos);
                        var i = this.situation.ease(this.pos);
                        for (var o in this.situation.once) o > this.lastPos && o <= i && (this.situation.once[o].call(this.target(), this.pos, i), delete this.situation.once[o]);
                        return this.active && this.target().fire("during", {
                            pos: this.pos,
                            eased: i,
                            fx: this,
                            situation: this.situation
                        }), this.situation ? (this.eachAt(), 1 == this.pos && !this.situation.reversed || this.situation.reversed && 0 == this.pos ? (this.stopAnimFrame(), this.target().fire("finished", {
                            fx: this,
                            situation: this.situation
                        }), this.situations.length || (this.target().fire("allfinished"), this.situations.length || (this.target().off(".fx"), this.active = !1)), this.active ? this.dequeue() : this.clearCurrent()) : !this.paused && this.active && this.startAnimFrame(), this.lastPos = i, this) : this
                    }, eachAt: function () {
                        var t, e, r, i = this, o = this.target(), s = this.situation;
                        for (t in s.animations) r = [].concat(s.animations[t]).map(function (t) {
                            return "string" != typeof t && t.at ? t.at(s.ease(i.pos), i.pos) : t
                        }), o[t].apply(o, r);
                        for (t in s.attrs) r = [t].concat(s.attrs[t]).map(function (t) {
                            return "string" != typeof t && t.at ? t.at(s.ease(i.pos), i.pos) : t
                        }), o.attr.apply(o, r);
                        for (t in s.styles) r = [t].concat(s.styles[t]).map(function (t) {
                            return "string" != typeof t && t.at ? t.at(s.ease(i.pos), i.pos) : t
                        }), o.style.apply(o, r);
                        if (s.transforms.length) {
                            for (r = s.initialTransformation, t = 0, e = s.transforms.length; t < e; t++) {
                                var a = s.transforms[t];
                                a instanceof n.Matrix ? r = a.relative ? r.multiply((new n.Matrix).morph(a).at(s.ease(this.pos))) : r.morph(a).at(s.ease(this.pos)) : (a.relative || a.undo(r.extract()), r = r.multiply(a.at(s.ease(this.pos))))
                            }
                            o.matrix(r)
                        }
                        return this
                    }, once: function (t, e, n) {
                        var r = this.last();
                        return n || (t = r.ease(t)), r.once[t] = e, this
                    }, _callStart: function () {
                        return setTimeout(function () {
                            this.start()
                        }.bind(this), 0), this
                    }
                }, parent: n.Element, construct: {
                    animate: function (t, e, r) {
                        return (this.fx || (this.fx = new n.FX(this))).animate(t, e, r)
                    }, delay: function (t) {
                        return (this.fx || (this.fx = new n.FX(this))).delay(t)
                    }, stop: function (t, e) {
                        return this.fx && this.fx.stop(t, e), this
                    }, finish: function () {
                        return this.fx && this.fx.finish(), this
                    }, pause: function () {
                        return this.fx && this.fx.pause(), this
                    }, play: function () {
                        return this.fx && this.fx.play(), this
                    }, speed: function (t) {
                        if (this.fx) {
                            if (null == t) return this.fx.speed();
                            this.fx.speed(t)
                        }
                        return this
                    }
                }
            }), n.MorphObj = n.invent({
                create: function (t, e) {
                    return n.Color.isColor(e) ? new n.Color(t).morph(e) : n.regex.delimiter.test(t) ? n.regex.pathLetters.test(t) ? new n.PathArray(t).morph(e) : new n.Array(t).morph(e) : n.regex.numberAndUnit.test(e) ? new n.Number(t).morph(e) : (this.value = t, void (this.destination = e))
                }, extend: {
                    at: function (t, e) {
                        return e < 1 ? this.value : this.destination
                    }, valueOf: function () {
                        return this.value
                    }
                }
            }), n.extend(n.FX, {
                attr: function (t, e, n) {
                    if ("object" == typeof t) for (var r in t) this.attr(r, t[r]); else this.add(t, e, "attrs");
                    return this
                }, style: function (t, e) {
                    if ("object" == typeof t) for (var n in t) this.style(n, t[n]); else this.add(t, e, "styles");
                    return this
                }, x: function (t, e) {
                    if (this.target() instanceof n.G) return this.transform({x: t}, e), this;
                    var r = new n.Number(t);
                    return r.relative = e, this.add("x", r)
                }, y: function (t, e) {
                    if (this.target() instanceof n.G) return this.transform({y: t}, e), this;
                    var r = new n.Number(t);
                    return r.relative = e, this.add("y", r)
                }, cx: function (t) {
                    return this.add("cx", new n.Number(t))
                }, cy: function (t) {
                    return this.add("cy", new n.Number(t))
                }, move: function (t, e) {
                    return this.x(t).y(e)
                }, center: function (t, e) {
                    return this.cx(t).cy(e)
                }, size: function (t, e) {
                    var r;
                    return this.target() instanceof n.Text ? this.attr("font-size", t) : (t && e || (r = this.target().bbox()), t || (t = r.width / r.height * e), e || (e = r.height / r.width * t), this.add("width", new n.Number(t)).add("height", new n.Number(e))), this
                }, width: function (t) {
                    return this.add("width", new n.Number(t))
                }, height: function (t) {
                    return this.add("height", new n.Number(t))
                }, plot: function (t, e, n, r) {
                    return 4 == arguments.length ? this.plot([t, e, n, r]) : this.add("plot", new (this.target().morphArray)(t))
                }, leading: function (t) {
                    return this.target().leading ? this.add("leading", new n.Number(t)) : this
                }, viewbox: function (t, e, r, i) {
                    return this.target() instanceof n.Container && this.add("viewbox", new n.ViewBox(t, e, r, i)), this
                }, update: function (t) {
                    if (this.target() instanceof n.Stop) {
                        if ("number" == typeof t || t instanceof n.Number) return this.update({
                            offset: arguments[0],
                            color: arguments[1],
                            opacity: arguments[2]
                        });
                        null != t.opacity && this.attr("stop-opacity", t.opacity), null != t.color && this.attr("stop-color", t.color), null != t.offset && this.attr("offset", t.offset)
                    }
                    return this
                }
            }), n.Box = n.invent({
                create: function (t, e, r, i) {
                    if (!("object" != typeof t || t instanceof n.Element)) return n.Box.call(this, null != t.left ? t.left : t.x, null != t.top ? t.top : t.y, t.width, t.height);
                    4 == arguments.length && (this.x = t, this.y = e, this.width = r, this.height = i), v(this)
                }, extend: {
                    merge: function (t) {
                        var e = new this.constructor;
                        return e.x = Math.min(this.x, t.x), e.y = Math.min(this.y, t.y), e.width = Math.max(this.x + this.width, t.x + t.width) - e.x, e.height = Math.max(this.y + this.height, t.y + t.height) - e.y, v(e)
                    }, transform: function (t) {
                        var e, r = 1 / 0, i = -1 / 0, o = 1 / 0, s = -1 / 0,
                            a = [new n.Point(this.x, this.y), new n.Point(this.x2, this.y), new n.Point(this.x, this.y2), new n.Point(this.x2, this.y2)];
                        return a.forEach(function (e) {
                            e = e.transform(t), r = Math.min(r, e.x), i = Math.max(i, e.x), o = Math.min(o, e.y), s = Math.max(s, e.y)
                        }), (e = new this.constructor).x = r, e.width = i - r, e.y = o, e.height = s - o, v(e), e
                    }
                }
            }), n.BBox = n.invent({
                create: function (t) {
                    if (n.Box.apply(this, [].slice.call(arguments)), t instanceof n.Element) {
                        var r;
                        try {
                            if (e.documentElement.contains) {
                                if (!e.documentElement.contains(t.node)) throw new Exception("Element not in the dom")
                            } else {
                                for (var i = t.node; i.parentNode;) i = i.parentNode;
                                if (i != e) throw new Exception("Element not in the dom")
                            }
                            r = t.node.getBBox()
                        } catch (e) {
                            if (t instanceof n.Shape) {
                                var o = t.clone(n.parser.draw.instance).show();
                                r = o.node.getBBox(), o.remove()
                            } else r = {
                                x: t.node.clientLeft,
                                y: t.node.clientTop,
                                width: t.node.clientWidth,
                                height: t.node.clientHeight
                            }
                        }
                        n.Box.call(this, r)
                    }
                }, inherit: n.Box, parent: n.Element, construct: {
                    bbox: function () {
                        return new n.BBox(this)
                    }
                }
            }), n.BBox.prototype.constructor = n.BBox, n.extend(n.Element, {
                tbox: function () {
                    return console.warn("Use of TBox is deprecated and mapped to RBox. Use .rbox() instead."), this.rbox(this.doc())
                }
            }), n.RBox = n.invent({
                create: function (t) {
                    n.Box.apply(this, [].slice.call(arguments)), t instanceof n.Element && n.Box.call(this, t.node.getBoundingClientRect())
                }, inherit: n.Box, parent: n.Element, extend: {
                    addOffset: function () {
                        return this.x += t.pageXOffset, this.y += t.pageYOffset, this
                    }
                }, construct: {
                    rbox: function (t) {
                        return t ? new n.RBox(this).transform(t.screenCTM().inverse()) : new n.RBox(this).addOffset()
                    }
                }
            }), n.RBox.prototype.constructor = n.RBox, n.Matrix = n.invent({
                create: function (t) {
                    var e, r = d([1, 0, 0, 1, 0, 0]);
                    for (t = t instanceof n.Element ? t.matrixify() : "string" == typeof t ? d(t.split(n.regex.delimiter).map(parseFloat)) : 6 == arguments.length ? d([].slice.call(arguments)) : Array.isArray(t) ? d(t) : "object" == typeof t ? t : r, e = x.length - 1; e >= 0; --e) this[x[e]] = null != t[x[e]] ? t[x[e]] : r[x[e]]
                }, extend: {
                    extract: function () {
                        var t = p(this, 0, 1), e = p(this, 1, 0), r = 180 / Math.PI * Math.atan2(t.y, t.x) - 90;
                        return {
                            x: this.e,
                            y: this.f,
                            transformedX: (this.e * Math.cos(r * Math.PI / 180) + this.f * Math.sin(r * Math.PI / 180)) / Math.sqrt(this.a * this.a + this.b * this.b),
                            transformedY: (this.f * Math.cos(r * Math.PI / 180) + this.e * Math.sin(-r * Math.PI / 180)) / Math.sqrt(this.c * this.c + this.d * this.d),
                            skewX: -r,
                            skewY: 180 / Math.PI * Math.atan2(e.y, e.x),
                            scaleX: Math.sqrt(this.a * this.a + this.b * this.b),
                            scaleY: Math.sqrt(this.c * this.c + this.d * this.d),
                            rotation: r,
                            a: this.a,
                            b: this.b,
                            c: this.c,
                            d: this.d,
                            e: this.e,
                            f: this.f,
                            matrix: new n.Matrix(this)
                        }
                    }, clone: function () {
                        return new n.Matrix(this)
                    }, morph: function (t) {
                        return this.destination = new n.Matrix(t), this
                    }, at: function (t) {
                        if (!this.destination) return this;
                        var e = new n.Matrix({
                            a: this.a + (this.destination.a - this.a) * t,
                            b: this.b + (this.destination.b - this.b) * t,
                            c: this.c + (this.destination.c - this.c) * t,
                            d: this.d + (this.destination.d - this.d) * t,
                            e: this.e + (this.destination.e - this.e) * t,
                            f: this.f + (this.destination.f - this.f) * t
                        });
                        return e
                    }, multiply: function (t) {
                        return new n.Matrix(this.native().multiply(function (t) {
                            return t instanceof n.Matrix || (t = new n.Matrix(t)), t
                        }(t).native()))
                    }, inverse: function () {
                        return new n.Matrix(this.native().inverse())
                    }, translate: function (t, e) {
                        return new n.Matrix(this.native().translate(t || 0, e || 0))
                    }, scale: function (t, e, r, i) {
                        return 1 == arguments.length ? e = t : 3 == arguments.length && (i = r, r = e, e = t), this.around(r, i, new n.Matrix(t, 0, 0, e, 0, 0))
                    }, rotate: function (t, e, r) {
                        return t = n.utils.radians(t), this.around(e, r, new n.Matrix(Math.cos(t), Math.sin(t), -Math.sin(t), Math.cos(t), 0, 0))
                    }, flip: function (t, e) {
                        return "x" == t ? this.scale(-1, 1, e, 0) : "y" == t ? this.scale(1, -1, 0, e) : this.scale(-1, -1, t, null != e ? e : t)
                    }, skew: function (t, e, r, i) {
                        return 1 == arguments.length ? e = t : 3 == arguments.length && (i = r, r = e, e = t), t = n.utils.radians(t), e = n.utils.radians(e), this.around(r, i, new n.Matrix(1, Math.tan(e), Math.tan(t), 1, 0, 0))
                    }, skewX: function (t, e, n) {
                        return this.skew(t, 0, e, n)
                    }, skewY: function (t, e, n) {
                        return this.skew(0, t, e, n)
                    }, around: function (t, e, r) {
                        return this.multiply(new n.Matrix(1, 0, 0, 1, t || 0, e || 0)).multiply(r).multiply(new n.Matrix(1, 0, 0, 1, -t || 0, -e || 0))
                    }, native: function () {
                        for (var t = n.parser.native.createSVGMatrix(), e = x.length - 1; e >= 0; e--) t[x[e]] = this[x[e]];
                        return t
                    }, toString: function () {
                        return "matrix(" + g(this.a) + "," + g(this.b) + "," + g(this.c) + "," + g(this.d) + "," + g(this.e) + "," + g(this.f) + ")"
                    }
                }, parent: n.Element, construct: {
                    ctm: function () {
                        return new n.Matrix(this.node.getCTM())
                    }, screenCTM: function () {
                        if (this instanceof n.Nested) {
                            var t = this.rect(1, 1), e = t.node.getScreenCTM();
                            return t.remove(), new n.Matrix(e)
                        }
                        return new n.Matrix(this.node.getScreenCTM())
                    }
                }
            }), n.Point = n.invent({
                create: function (t, e) {
                    var n;
                    n = Array.isArray(t) ? {x: t[0], y: t[1]} : "object" == typeof t ? {
                        x: t.x,
                        y: t.y
                    } : null != t ? {x: t, y: null != e ? e : t} : {x: 0, y: 0}, this.x = n.x, this.y = n.y
                }, extend: {
                    clone: function () {
                        return new n.Point(this)
                    }, morph: function (t, e) {
                        return this.destination = new n.Point(t, e), this
                    }, at: function (t) {
                        if (!this.destination) return this;
                        var e = new n.Point({
                            x: this.x + (this.destination.x - this.x) * t,
                            y: this.y + (this.destination.y - this.y) * t
                        });
                        return e
                    }, native: function () {
                        var t = n.parser.native.createSVGPoint();
                        return t.x = this.x, t.y = this.y, t
                    }, transform: function (t) {
                        return new n.Point(this.native().matrixTransform(t.native()))
                    }
                }
            }), n.extend(n.Element, {
                point: function (t, e) {
                    return new n.Point(t, e).transform(this.screenCTM().inverse())
                }
            }), n.extend(n.Element, {
                attr: function (t, e, r) {
                    if (null == t) {
                        for (t = {}, e = this.node.attributes, r = e.length - 1; r >= 0; r--) t[e[r].nodeName] = n.regex.isNumber.test(e[r].nodeValue) ? parseFloat(e[r].nodeValue) : e[r].nodeValue;
                        return t
                    }
                    if ("object" == typeof t) for (e in t) this.attr(e, t[e]); else if (null === e) this.node.removeAttribute(t); else {
                        if (null == e) return null == (e = this.node.getAttribute(t)) ? n.defaults.attrs[t] : n.regex.isNumber.test(e) ? parseFloat(e) : e;
                        "stroke-width" == t ? this.attr("stroke", parseFloat(e) > 0 ? this._stroke : null) : "stroke" == t && (this._stroke = e), "fill" != t && "stroke" != t || (n.regex.isImage.test(e) && (e = this.doc().defs().image(e, 0, 0)), e instanceof n.Image && (e = this.doc().defs().pattern(0, 0, function () {
                            this.add(e)
                        }))), "number" == typeof e ? e = new n.Number(e) : n.Color.isColor(e) ? e = new n.Color(e) : Array.isArray(e) && (e = new n.Array(e)), "leading" == t ? this.leading && this.leading(e) : "string" == typeof r ? this.node.setAttributeNS(r, t, e.toString()) : this.node.setAttribute(t, e.toString()), !this.rebuild || "font-size" != t && "x" != t || this.rebuild(t, e)
                    }
                    return this
                }
            }), n.extend(n.Element, {
                transform: function (t, e) {
                    var r, i;
                    if ("object" != typeof t) return r = new n.Matrix(this).extract(), "string" == typeof t ? r[t] : r;
                    if (r = new n.Matrix(this), e = !!e || !!t.relative, null != t.a) r = e ? r.multiply(new n.Matrix(t)) : new n.Matrix(t); else if (null != t.rotation) y(t, this), r = e ? r.rotate(t.rotation, t.cx, t.cy) : r.rotate(t.rotation - r.extract().rotation, t.cx, t.cy); else if (null != t.scale || null != t.scaleX || null != t.scaleY) {
                        if (y(t, this), t.scaleX = null != t.scale ? t.scale : null != t.scaleX ? t.scaleX : 1, t.scaleY = null != t.scale ? t.scale : null != t.scaleY ? t.scaleY : 1, !e) {
                            var o = r.extract();
                            t.scaleX = 1 * t.scaleX / o.scaleX, t.scaleY = 1 * t.scaleY / o.scaleY
                        }
                        r = r.scale(t.scaleX, t.scaleY, t.cx, t.cy)
                    } else if (null != t.skew || null != t.skewX || null != t.skewY) {
                        if (y(t, this), t.skewX = null != t.skew ? t.skew : null != t.skewX ? t.skewX : 0, t.skewY = null != t.skew ? t.skew : null != t.skewY ? t.skewY : 0, !e) {
                            var o = r.extract();
                            r = r.multiply((new n.Matrix).skew(o.skewX, o.skewY, t.cx, t.cy).inverse())
                        }
                        r = r.skew(t.skewX, t.skewY, t.cx, t.cy)
                    } else t.flip ? ("x" == t.flip || "y" == t.flip ? t.offset = null == t.offset ? this.bbox()["c" + t.flip] : t.offset : null == t.offset ? (i = this.bbox(), t.flip = i.cx, t.offset = i.cy) : t.flip = t.offset, r = (new n.Matrix).flip(t.flip, t.offset)) : null == t.x && null == t.y || (e ? r = r.translate(t.x, t.y) : (null != t.x && (r.e = t.x), null != t.y && (r.f = t.y)));
                    return this.attr("transform", r)
                }
            }), n.extend(n.FX, {
                transform: function (t, e) {
                    var r, i, o = this.target();
                    return "object" != typeof t ? (r = new n.Matrix(o).extract(), "string" == typeof t ? r[t] : r) : (e = !!e || !!t.relative, null != t.a ? r = new n.Matrix(t) : null != t.rotation ? (y(t, o), r = new n.Rotate(t.rotation, t.cx, t.cy)) : null != t.scale || null != t.scaleX || null != t.scaleY ? (y(t, o), t.scaleX = null != t.scale ? t.scale : null != t.scaleX ? t.scaleX : 1, t.scaleY = null != t.scale ? t.scale : null != t.scaleY ? t.scaleY : 1, r = new n.Scale(t.scaleX, t.scaleY, t.cx, t.cy)) : null != t.skewX || null != t.skewY ? (y(t, o), t.skewX = null != t.skewX ? t.skewX : 0, t.skewY = null != t.skewY ? t.skewY : 0, r = new n.Skew(t.skewX, t.skewY, t.cx, t.cy)) : t.flip ? ("x" == t.flip || "y" == t.flip ? t.offset = null == t.offset ? o.bbox()["c" + t.flip] : t.offset : null == t.offset ? (i = o.bbox(), t.flip = i.cx, t.offset = i.cy) : t.flip = t.offset, r = (new n.Matrix).flip(t.flip, t.offset)) : null == t.x && null == t.y || (r = new n.Translate(t.x, t.y)), r ? (r.relative = e, this.last().transforms.push(r), this._callStart()) : this)
                }
            }), n.extend(n.Element, {
                untransform: function () {
                    return this.attr("transform", null)
                }, matrixify: function () {
                    var t = (this.attr("transform") || "").split(n.regex.transforms).slice(0, -1).map(function (t) {
                        var e = t.trim().split("(");
                        return [e[0], e[1].split(n.regex.delimiter).map(function (t) {
                            return parseFloat(t)
                        })]
                    }).reduce(function (t, e) {
                        return "matrix" == e[0] ? t.multiply(d(e[1])) : t[e[0]].apply(t, e[1])
                    }, new n.Matrix);
                    return t
                }, toParent: function (t) {
                    if (this == t) return this;
                    var e = this.screenCTM(), n = t.screenCTM().inverse();
                    return this.addTo(t).untransform().transform(n.multiply(e)), this
                }, toDoc: function () {
                    return this.toParent(this.doc())
                }
            }), n.Transformation = n.invent({
                create: function (t, e) {
                    if (arguments.length > 1 && "boolean" != typeof e) return this.constructor.call(this, [].slice.call(arguments));
                    if (Array.isArray(t)) for (var n = 0, r = this.arguments.length; n < r; ++n) this[this.arguments[n]] = t[n]; else if ("object" == typeof t) for (var n = 0, r = this.arguments.length; n < r; ++n) this[this.arguments[n]] = t[this.arguments[n]];
                    this.inversed = !1, !0 === e && (this.inversed = !0)
                }, extend: {
                    arguments: [], method: "", at: function (t) {
                        for (var e = [], r = 0, i = this.arguments.length; r < i; ++r) e.push(this[this.arguments[r]]);
                        var o = this._undo || new n.Matrix;
                        return o = (new n.Matrix).morph(n.Matrix.prototype[this.method].apply(o, e)).at(t), this.inversed ? o.inverse() : o
                    }, undo: function (t) {
                        for (var e = 0, r = this.arguments.length; e < r; ++e) t[this.arguments[e]] = void 0 === this[this.arguments[e]] ? 0 : t[this.arguments[e]];
                        return t.cx = this.cx, t.cy = this.cy, this._undo = new (n[u(this.method)])(t, !0).at(1), this
                    }
                }
            }), n.Translate = n.invent({
                parent: n.Matrix, inherit: n.Transformation, create: function (t, e) {
                    this.constructor.apply(this, [].slice.call(arguments))
                }, extend: {arguments: ["transformedX", "transformedY"], method: "translate"}
            }), n.Rotate = n.invent({
                parent: n.Matrix, inherit: n.Transformation, create: function (t, e) {
                    this.constructor.apply(this, [].slice.call(arguments))
                }, extend: {
                    arguments: ["rotation", "cx", "cy"], method: "rotate", at: function (t) {
                        var e = (new n.Matrix).rotate((new n.Number).morph(this.rotation - (this._undo ? this._undo.rotation : 0)).at(t), this.cx, this.cy);
                        return this.inversed ? e.inverse() : e
                    }, undo: function (t) {
                        return this._undo = t, this
                    }
                }
            }), n.Scale = n.invent({
                parent: n.Matrix, inherit: n.Transformation, create: function (t, e) {
                    this.constructor.apply(this, [].slice.call(arguments))
                }, extend: {arguments: ["scaleX", "scaleY", "cx", "cy"], method: "scale"}
            }), n.Skew = n.invent({
                parent: n.Matrix, inherit: n.Transformation, create: function (t, e) {
                    this.constructor.apply(this, [].slice.call(arguments))
                }, extend: {arguments: ["skewX", "skewY", "cx", "cy"], method: "skew"}
            }), n.extend(n.Element, {
                style: function (t, e) {
                    if (0 == arguments.length) return this.node.style.cssText || "";
                    if (arguments.length < 2) if ("object" == typeof t) for (e in t) this.style(e, t[e]); else {
                        if (!n.regex.isCss.test(t)) return this.node.style[l(t)];
                        for (t = t.split(/\s*;\s*/).filter(function (t) {
                            return !!t
                        }).map(function (t) {
                            return t.split(/\s*:\s*/)
                        }); e = t.pop();) this.style(e[0], e[1])
                    } else this.node.style[l(t)] = null === e || n.regex.isBlank.test(e) ? "" : e;
                    return this
                }
            }), n.Parent = n.invent({
                create: function (t) {
                    this.constructor.call(this, t)
                }, inherit: n.Element, extend: {
                    children: function () {
                        return n.utils.map(n.utils.filterSVGElements(this.node.childNodes), function (t) {
                            return n.adopt(t)
                        })
                    }, add: function (t, e) {
                        return null == e ? this.node.appendChild(t.node) : t.node != this.node.childNodes[e] && this.node.insertBefore(t.node, this.node.childNodes[e]), this
                    }, put: function (t, e) {
                        return this.add(t, e), t
                    }, has: function (t) {
                        return this.index(t) >= 0
                    }, index: function (t) {
                        return [].slice.call(this.node.childNodes).indexOf(t.node)
                    }, get: function (t) {
                        return n.adopt(this.node.childNodes[t])
                    }, first: function () {
                        return this.get(0)
                    }, last: function () {
                        return this.get(this.node.childNodes.length - 1)
                    }, each: function (t, e) {
                        var r, i, o = this.children();
                        for (r = 0, i = o.length; r < i; r++) o[r] instanceof n.Element && t.apply(o[r], [r, o]), e && o[r] instanceof n.Container && o[r].each(t, e);
                        return this
                    }, removeElement: function (t) {
                        return this.node.removeChild(t.node), this
                    }, clear: function () {
                        for (; this.node.hasChildNodes();) this.node.removeChild(this.node.lastChild);
                        return delete this._defs, this
                    }, defs: function () {
                        return this.doc().defs()
                    }
                }
            }), n.extend(n.Parent, {
                ungroup: function (t, e) {
                    return 0 === e || this instanceof n.Defs || this.node == n.parser.draw ? this : (t = t || (this instanceof n.Doc ? this : this.parent(n.Parent)), e = e || 1 / 0, this.each(function () {
                        return this instanceof n.Defs ? this : this instanceof n.Parent ? this.ungroup(t, e - 1) : this.toParent(t)
                    }), this.node.firstChild || this.remove(), this)
                }, flatten: function (t, e) {
                    return this.ungroup(t, e)
                }
            }), n.Container = n.invent({
                create: function (t) {
                    this.constructor.call(this, t)
                }, inherit: n.Parent
            }), n.ViewBox = n.invent({
                create: function (t) {
                    var e, r, i, o, s, a, c, l = [0, 0, 0, 0], u = 1, h = 1,
                        f = /[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?/gi;
                    if (t instanceof n.Element) {
                        for (a = t, c = t, s = (t.attr("viewBox") || "").match(f), t.bbox, i = new n.Number(t.width()), o = new n.Number(t.height()); "%" == i.unit;) u *= i.value, i = new n.Number(a instanceof n.Doc ? a.parent().offsetWidth : a.parent().width()), a = a.parent();
                        for (; "%" == o.unit;) h *= o.value, o = new n.Number(c instanceof n.Doc ? c.parent().offsetHeight : c.parent().height()), c = c.parent();
                        this.x = 0, this.y = 0, this.width = i * u, this.height = o * h, this.zoom = 1, s && (e = parseFloat(s[0]), r = parseFloat(s[1]), i = parseFloat(s[2]), o = parseFloat(s[3]), this.zoom = this.width / this.height > i / o ? this.height / o : this.width / i, this.x = e, this.y = r, this.width = i, this.height = o)
                    } else t = "string" == typeof t ? t.match(f).map(function (t) {
                        return parseFloat(t)
                    }) : Array.isArray(t) ? t : "object" == typeof t ? [t.x, t.y, t.width, t.height] : 4 == arguments.length ? [].slice.call(arguments) : l, this.x = t[0], this.y = t[1], this.width = t[2], this.height = t[3]
                }, extend: {
                    toString: function () {
                        return this.x + " " + this.y + " " + this.width + " " + this.height
                    }, morph: function (t, e, r, i) {
                        return this.destination = new n.ViewBox(t, e, r, i), this
                    }, at: function (t) {
                        return this.destination ? new n.ViewBox([this.x + (this.destination.x - this.x) * t, this.y + (this.destination.y - this.y) * t, this.width + (this.destination.width - this.width) * t, this.height + (this.destination.height - this.height) * t]) : this
                    }
                }, parent: n.Container, construct: {
                    viewbox: function (t, e, r, i) {
                        return 0 == arguments.length ? new n.ViewBox(this) : this.attr("viewBox", new n.ViewBox(t, e, r, i))
                    }
                }
            }), ["click", "dblclick", "mousedown", "mouseup", "mouseover", "mouseout", "mousemove", "mouseenter", "mouseleave", "touchstart", "touchmove", "touchleave", "touchend", "touchcancel"].forEach(function (t) {
                n.Element.prototype[t] = function (e) {
                    return null == e ? n.off(this, t) : n.on(this, t, e), this
                }
            }), n.listenerId = 0, n.on = function (t, e, r, i, o) {
                var s = r.bind(i || t), a = t instanceof n.Element ? t.node : t;
                a.instance = a.instance || {_events: {}};
                var c = a.instance._events;
                r._svgjsListenerId || (r._svgjsListenerId = ++n.listenerId), e.split(n.regex.delimiter).forEach(function (t) {
                    var e = t.split(".")[0], n = t.split(".")[1] || "*";
                    c[e] = c[e] || {}, c[e][n] = c[e][n] || {}, c[e][n][r._svgjsListenerId] = s, a.addEventListener(e, s, o || !1)
                })
            }, n.off = function (t, e, r, i) {
                var o = t instanceof n.Element ? t.node : t;
                if (o.instance && ("function" != typeof r || (r = r._svgjsListenerId))) {
                    var s = o.instance._events;
                    (e || "").split(n.regex.delimiter).forEach(function (t) {
                        var e, a, c = t && t.split(".")[0], l = t && t.split(".")[1];
                        if (r) s[c] && s[c][l || "*"] && (o.removeEventListener(c, s[c][l || "*"][r], i || !1), delete s[c][l || "*"][r]); else if (c && l) {
                            if (s[c] && s[c][l]) {
                                for (a in s[c][l]) n.off(o, [c, l].join("."), a);
                                delete s[c][l]
                            }
                        } else if (l) for (t in s) for (e in s[t]) l === e && n.off(o, [t, l].join(".")); else if (c) {
                            if (s[c]) {
                                for (e in s[c]) n.off(o, [c, e].join("."));
                                delete s[c]
                            }
                        } else {
                            for (t in s) n.off(o, t);
                            o.instance._events = {}
                        }
                    })
                }
            }, n.extend(n.Element, {
                on: function (t, e, r, i) {
                    return n.on(this, t, e, r, i), this
                }, off: function (t, e) {
                    return n.off(this.node, t, e), this
                }, fire: function (e, r) {
                    return e instanceof t.Event ? this.node.dispatchEvent(e) : this.node.dispatchEvent(e = new n.CustomEvent(e, {
                        detail: r,
                        cancelable: !0
                    })), this._event = e, this
                }, event: function () {
                    return this._event
                }
            }), n.Defs = n.invent({create: "defs", inherit: n.Container}), n.G = n.invent({
                create: "g",
                inherit: n.Container,
                extend: {
                    x: function (t) {
                        return null == t ? this.transform("x") : this.transform({x: t - this.x()}, !0)
                    }, y: function (t) {
                        return null == t ? this.transform("y") : this.transform({y: t - this.y()}, !0)
                    }, cx: function (t) {
                        return null == t ? this.gbox().cx : this.x(t - this.gbox().width / 2)
                    }, cy: function (t) {
                        return null == t ? this.gbox().cy : this.y(t - this.gbox().height / 2)
                    }, gbox: function () {
                        var t = this.bbox(), e = this.transform();
                        return t.x += e.x, t.x2 += e.x, t.cx += e.x, t.y += e.y, t.y2 += e.y, t.cy += e.y, t
                    }
                },
                construct: {
                    group: function () {
                        return this.put(new n.G)
                    }
                }
            }), n.Doc = n.invent({
                create: function (t) {
                    t && ("svg" == (t = "string" == typeof t ? e.getElementById(t) : t).nodeName ? this.constructor.call(this, t) : (this.constructor.call(this, n.create("svg")), t.appendChild(this.node), this.size("100%", "100%")), this.namespace().defs())
                }, inherit: n.Container, extend: {
                    namespace: function () {
                        return this.attr({
                            xmlns: n.ns,
                            version: "1.1"
                        }).attr("xmlns:xlink", n.xlink, n.xmlns).attr("xmlns:svgjs", n.svgjs, n.xmlns)
                    }, defs: function () {
                        var t;
                        return this._defs || ((t = this.node.getElementsByTagName("defs")[0]) ? this._defs = n.adopt(t) : this._defs = new n.Defs, this.node.appendChild(this._defs.node)), this._defs
                    }, parent: function () {
                        return this.node.parentNode && "#document" != this.node.parentNode.nodeName && "#document-fragment" != this.node.parentNode.nodeName ? this.node.parentNode : null
                    }, spof: function () {
                        var t = this.node.getScreenCTM();
                        return t && this.style("left", -t.e % 1 + "px").style("top", -t.f % 1 + "px"), this
                    }, remove: function () {
                        return this.parent() && this.parent().removeChild(this.node), this
                    }, clear: function () {
                        for (; this.node.hasChildNodes();) this.node.removeChild(this.node.lastChild);
                        return delete this._defs, n.parser.draw.parentNode || this.node.appendChild(n.parser.draw), this
                    }, clone: function (t) {
                        this.writeDataToDom();
                        var e = this.node, n = m(e.cloneNode(!0));
                        return t ? (t.node || t).appendChild(n.node) : e.parentNode.insertBefore(n.node, e.nextSibling), n
                    }
                }
            }), n.extend(n.Element, {
                siblings: function () {
                    return this.parent().children()
                }, position: function () {
                    return this.parent().index(this)
                }, next: function () {
                    return this.siblings()[this.position() + 1]
                }, previous: function () {
                    return this.siblings()[this.position() - 1]
                }, forward: function () {
                    var t = this.position() + 1, e = this.parent();
                    return e.removeElement(this).add(this, t), e instanceof n.Doc && e.node.appendChild(e.defs().node), this
                }, backward: function () {
                    var t = this.position();
                    return t > 0 && this.parent().removeElement(this).add(this, t - 1), this
                }, front: function () {
                    var t = this.parent();
                    return t.node.appendChild(this.node), t instanceof n.Doc && t.node.appendChild(t.defs().node), this
                }, back: function () {
                    return this.position() > 0 && this.parent().removeElement(this).add(this, 0), this
                }, before: function (t) {
                    t.remove();
                    var e = this.position();
                    return this.parent().add(t, e), this
                }, after: function (t) {
                    t.remove();
                    var e = this.position();
                    return this.parent().add(t, e + 1), this
                }
            }), n.Mask = n.invent({
                create: function () {
                    this.constructor.call(this, n.create("mask")), this.targets = []
                }, inherit: n.Container, extend: {
                    remove: function () {
                        for (var t = this.targets.length - 1; t >= 0; t--) this.targets[t] && this.targets[t].unmask();
                        return this.targets = [], n.Element.prototype.remove.call(this), this
                    }
                }, construct: {
                    mask: function () {
                        return this.defs().put(new n.Mask)
                    }
                }
            }), n.extend(n.Element, {
                maskWith: function (t) {
                    return this.masker = t instanceof n.Mask ? t : this.parent().mask().add(t), this.masker.targets.push(this), this.attr("mask", 'url("#' + this.masker.attr("id") + '")')
                }, unmask: function () {
                    return delete this.masker, this.attr("mask", null)
                }
            }), n.ClipPath = n.invent({
                create: function () {
                    this.constructor.call(this, n.create("clipPath")), this.targets = []
                }, inherit: n.Container, extend: {
                    remove: function () {
                        for (var t = this.targets.length - 1; t >= 0; t--) this.targets[t] && this.targets[t].unclip();
                        return this.targets = [], this.parent().removeElement(this), this
                    }
                }, construct: {
                    clip: function () {
                        return this.defs().put(new n.ClipPath)
                    }
                }
            }), n.extend(n.Element, {
                clipWith: function (t) {
                    return this.clipper = t instanceof n.ClipPath ? t : this.parent().clip().add(t), this.clipper.targets.push(this), this.attr("clip-path", 'url("#' + this.clipper.attr("id") + '")')
                }, unclip: function () {
                    return delete this.clipper, this.attr("clip-path", null)
                }
            }), n.Gradient = n.invent({
                create: function (t) {
                    this.constructor.call(this, n.create(t + "Gradient")), this.type = t
                }, inherit: n.Container, extend: {
                    at: function (t, e, r) {
                        return this.put(new n.Stop).update(t, e, r)
                    }, update: function (t) {
                        return this.clear(), "function" == typeof t && t.call(this, this), this
                    }, fill: function () {
                        return "url(#" + this.id() + ")"
                    }, toString: function () {
                        return this.fill()
                    }, attr: function (t, e, r) {
                        return "transform" == t && (t = "gradientTransform"), n.Container.prototype.attr.call(this, t, e, r)
                    }
                }, construct: {
                    gradient: function (t, e) {
                        return this.defs().gradient(t, e)
                    }
                }
            }), n.extend(n.Gradient, n.FX, {
                from: function (t, e) {
                    return "radial" == (this._target || this).type ? this.attr({
                        fx: new n.Number(t),
                        fy: new n.Number(e)
                    }) : this.attr({x1: new n.Number(t), y1: new n.Number(e)})
                }, to: function (t, e) {
                    return "radial" == (this._target || this).type ? this.attr({
                        cx: new n.Number(t),
                        cy: new n.Number(e)
                    }) : this.attr({x2: new n.Number(t), y2: new n.Number(e)})
                }
            }), n.extend(n.Defs, {
                gradient: function (t, e) {
                    return this.put(new n.Gradient(t)).update(e)
                }
            }), n.Stop = n.invent({
                create: "stop", inherit: n.Element, extend: {
                    update: function (t) {
                        return ("number" == typeof t || t instanceof n.Number) && (t = {
                            offset: arguments[0],
                            color: arguments[1],
                            opacity: arguments[2]
                        }), null != t.opacity && this.attr("stop-opacity", t.opacity), null != t.color && this.attr("stop-color", t.color), null != t.offset && this.attr("offset", new n.Number(t.offset)), this
                    }
                }
            }), n.Pattern = n.invent({
                create: "pattern", inherit: n.Container, extend: {
                    fill: function () {
                        return "url(#" + this.id() + ")"
                    }, update: function (t) {
                        return this.clear(), "function" == typeof t && t.call(this, this), this
                    }, toString: function () {
                        return this.fill()
                    }, attr: function (t, e, r) {
                        return "transform" == t && (t = "patternTransform"), n.Container.prototype.attr.call(this, t, e, r)
                    }
                }, construct: {
                    pattern: function (t, e, n) {
                        return this.defs().pattern(t, e, n)
                    }
                }
            }), n.extend(n.Defs, {
                pattern: function (t, e, r) {
                    return this.put(new n.Pattern).update(r).attr({
                        x: 0,
                        y: 0,
                        width: t,
                        height: e,
                        patternUnits: "userSpaceOnUse"
                    })
                }
            }), n.Shape = n.invent({
                create: function (t) {
                    this.constructor.call(this, t)
                }, inherit: n.Element
            }), n.Bare = n.invent({
                create: function (t, e) {
                    if (this.constructor.call(this, n.create(t)), e) for (var r in e.prototype) "function" == typeof e.prototype[r] && (this[r] = e.prototype[r])
                }, inherit: n.Element, extend: {
                    words: function (t) {
                        for (; this.node.hasChildNodes();) this.node.removeChild(this.node.lastChild);
                        return this.node.appendChild(e.createTextNode(t)), this
                    }
                }
            }), n.extend(n.Parent, {
                element: function (t, e) {
                    return this.put(new n.Bare(t, e))
                }
            }), n.Symbol = n.invent({
                create: "symbol", inherit: n.Container, construct: {
                    symbol: function () {
                        return this.put(new n.Symbol)
                    }
                }
            }), n.Use = n.invent({
                create: "use", inherit: n.Shape, extend: {
                    element: function (t, e) {
                        return this.attr("href", (e || "") + "#" + t, n.xlink)
                    }
                }, construct: {
                    use: function (t, e) {
                        return this.put(new n.Use).element(t, e)
                    }
                }
            }), n.Rect = n.invent({
                create: "rect", inherit: n.Shape, construct: {
                    rect: function (t, e) {
                        return this.put(new n.Rect).size(t, e)
                    }
                }
            }), n.Circle = n.invent({
                create: "circle", inherit: n.Shape, construct: {
                    circle: function (t) {
                        return this.put(new n.Circle).rx(new n.Number(t).divide(2)).move(0, 0)
                    }
                }
            }), n.extend(n.Circle, n.FX, {
                rx: function (t) {
                    return this.attr("r", t)
                }, ry: function (t) {
                    return this.rx(t)
                }
            }), n.Ellipse = n.invent({
                create: "ellipse", inherit: n.Shape, construct: {
                    ellipse: function (t, e) {
                        return this.put(new n.Ellipse).size(t, e).move(0, 0)
                    }
                }
            }), n.extend(n.Ellipse, n.Rect, n.FX, {
                rx: function (t) {
                    return this.attr("rx", t)
                }, ry: function (t) {
                    return this.attr("ry", t)
                }
            }), n.extend(n.Circle, n.Ellipse, {
                x: function (t) {
                    return null == t ? this.cx() - this.rx() : this.cx(t + this.rx())
                }, y: function (t) {
                    return null == t ? this.cy() - this.ry() : this.cy(t + this.ry())
                }, cx: function (t) {
                    return null == t ? this.attr("cx") : this.attr("cx", t)
                }, cy: function (t) {
                    return null == t ? this.attr("cy") : this.attr("cy", t)
                }, width: function (t) {
                    return null == t ? 2 * this.rx() : this.rx(new n.Number(t).divide(2))
                }, height: function (t) {
                    return null == t ? 2 * this.ry() : this.ry(new n.Number(t).divide(2))
                }, size: function (t, e) {
                    var r = f(this, t, e);
                    return this.rx(new n.Number(r.width).divide(2)).ry(new n.Number(r.height).divide(2))
                }
            }), n.Line = n.invent({
                create: "line", inherit: n.Shape, extend: {
                    array: function () {
                        return new n.PointArray([[this.attr("x1"), this.attr("y1")], [this.attr("x2"), this.attr("y2")]])
                    }, plot: function (t, e, r, i) {
                        return null == t ? this.array() : (t = void 0 !== e ? {
                            x1: t,
                            y1: e,
                            x2: r,
                            y2: i
                        } : new n.PointArray(t).toLine(), this.attr(t))
                    }, move: function (t, e) {
                        return this.attr(this.array().move(t, e).toLine())
                    }, size: function (t, e) {
                        var n = f(this, t, e);
                        return this.attr(this.array().size(n.width, n.height).toLine())
                    }
                }, construct: {
                    line: function (t, e, r, i) {
                        return n.Line.prototype.plot.apply(this.put(new n.Line), null != t ? [t, e, r, i] : [0, 0, 0, 0])
                    }
                }
            }), n.Polyline = n.invent({
                create: "polyline", inherit: n.Shape, construct: {
                    polyline: function (t) {
                        return this.put(new n.Polyline).plot(t || new n.PointArray)
                    }
                }
            }), n.Polygon = n.invent({
                create: "polygon", inherit: n.Shape, construct: {
                    polygon: function (t) {
                        return this.put(new n.Polygon).plot(t || new n.PointArray)
                    }
                }
            }), n.extend(n.Polyline, n.Polygon, {
                array: function () {
                    return this._array || (this._array = new n.PointArray(this.attr("points")))
                }, plot: function (t) {
                    return null == t ? this.array() : this.clear().attr("points", "string" == typeof t ? t : this._array = new n.PointArray(t))
                }, clear: function () {
                    return delete this._array, this
                }, move: function (t, e) {
                    return this.attr("points", this.array().move(t, e))
                }, size: function (t, e) {
                    var n = f(this, t, e);
                    return this.attr("points", this.array().size(n.width, n.height))
                }
            }), n.extend(n.Line, n.Polyline, n.Polygon, {
                morphArray: n.PointArray, x: function (t) {
                    return null == t ? this.bbox().x : this.move(t, this.bbox().y)
                }, y: function (t) {
                    return null == t ? this.bbox().y : this.move(this.bbox().x, t)
                }, width: function (t) {
                    var e = this.bbox();
                    return null == t ? e.width : this.size(t, e.height)
                }, height: function (t) {
                    var e = this.bbox();
                    return null == t ? e.height : this.size(e.width, t)
                }
            }), n.Path = n.invent({
                create: "path",
                inherit: n.Shape,
                extend: {
                    morphArray: n.PathArray, array: function () {
                        return this._array || (this._array = new n.PathArray(this.attr("d")))
                    }, plot: function (t) {
                        return null == t ? this.array() : this.clear().attr("d", "string" == typeof t ? t : this._array = new n.PathArray(t))
                    }, clear: function () {
                        return delete this._array, this
                    }, move: function (t, e) {
                        return this.attr("d", this.array().move(t, e))
                    }, x: function (t) {
                        return null == t ? this.bbox().x : this.move(t, this.bbox().y)
                    }, y: function (t) {
                        return null == t ? this.bbox().y : this.move(this.bbox().x, t)
                    }, size: function (t, e) {
                        var n = f(this, t, e);
                        return this.attr("d", this.array().size(n.width, n.height))
                    }, width: function (t) {
                        return null == t ? this.bbox().width : this.size(t, this.bbox().height)
                    }, height: function (t) {
                        return null == t ? this.bbox().height : this.size(this.bbox().width, t)
                    }
                },
                construct: {
                    path: function (t) {
                        return this.put(new n.Path).plot(t || new n.PathArray)
                    }
                }
            }), n.Image = n.invent({
                create: "image", inherit: n.Shape, extend: {
                    load: function (e) {
                        if (!e) return this;
                        var r = this, i = new t.Image;
                        return n.on(i, "load", function () {
                            n.off(i);
                            var t = r.parent(n.Pattern);
                            null !== t && (0 == r.width() && 0 == r.height() && r.size(i.width, i.height), t && 0 == t.width() && 0 == t.height() && t.size(r.width(), r.height()), "function" == typeof r._loaded && r._loaded.call(r, {
                                width: i.width,
                                height: i.height,
                                ratio: i.width / i.height,
                                url: e
                            }))
                        }), n.on(i, "error", function (t) {
                            n.off(i), "function" == typeof r._error && r._error.call(r, t)
                        }), this.attr("href", i.src = this.src = e, n.xlink)
                    }, loaded: function (t) {
                        return this._loaded = t, this
                    }, error: function (t) {
                        return this._error = t, this
                    }
                }, construct: {
                    image: function (t, e, r) {
                        return this.put(new n.Image).load(t).size(e || 0, r || e || 0)
                    }
                }
            }), n.Text = n.invent({
                create: function () {
                    this.constructor.call(this, n.create("text")), this.dom.leading = new n.Number(1.3), this._rebuild = !0, this._build = !1, this.attr("font-family", n.defaults.attrs["font-family"])
                }, inherit: n.Shape, extend: {
                    x: function (t) {
                        return null == t ? this.attr("x") : this.attr("x", t)
                    }, y: function (t) {
                        var e = this.attr("y"), n = "number" == typeof e ? e - this.bbox().y : 0;
                        return null == t ? "number" == typeof e ? e - n : e : this.attr("y", "number" == typeof t.valueOf() ? t + n : t)
                    }, cx: function (t) {
                        return null == t ? this.bbox().cx : this.x(t - this.bbox().width / 2)
                    }, cy: function (t) {
                        return null == t ? this.bbox().cy : this.y(t - this.bbox().height / 2)
                    }, text: function (t) {
                        if (void 0 === t) {
                            for (var t = "", e = this.node.childNodes, r = 0, i = e.length; r < i; ++r) 0 != r && 3 != e[r].nodeType && 1 == n.adopt(e[r]).dom.newLined && (t += "\n"), t += e[r].textContent;
                            return t
                        }
                        if (this.clear().build(!0), "function" == typeof t) t.call(this, this); else {
                            t = t.split("\n");
                            for (var r = 0, o = t.length; r < o; r++) this.tspan(t[r]).newLine()
                        }
                        return this.build(!1).rebuild()
                    }, size: function (t) {
                        return this.attr("font-size", t).rebuild()
                    }, leading: function (t) {
                        return null == t ? this.dom.leading : (this.dom.leading = new n.Number(t), this.rebuild())
                    }, lines: function () {
                        var t = (this.textPath && this.textPath() || this).node,
                            e = n.utils.map(n.utils.filterSVGElements(t.childNodes), function (t) {
                                return n.adopt(t)
                            });
                        return new n.Set(e)
                    }, rebuild: function (t) {
                        if ("boolean" == typeof t && (this._rebuild = t), this._rebuild) {
                            var e = this, r = 0, i = this.dom.leading * new n.Number(this.attr("font-size"));
                            this.lines().each(function () {
                                this.dom.newLined && (e.textPath() || this.attr("x", e.attr("x")), "\n" == this.text() ? r += i : (this.attr("dy", i + r), r = 0))
                            }), this.fire("rebuild")
                        }
                        return this
                    }, build: function (t) {
                        return this._build = !!t, this
                    }, setData: function (t) {
                        return this.dom = t, this.dom.leading = new n.Number(t.leading || 1.3), this
                    }
                }, construct: {
                    text: function (t) {
                        return this.put(new n.Text).text(t)
                    }, plain: function (t) {
                        return this.put(new n.Text).plain(t)
                    }
                }
            }), n.Tspan = n.invent({
                create: "tspan", inherit: n.Shape, extend: {
                    text: function (t) {
                        return null == t ? this.node.textContent + (this.dom.newLined ? "\n" : "") : ("function" == typeof t ? t.call(this, this) : this.plain(t), this)
                    }, dx: function (t) {
                        return this.attr("dx", t)
                    }, dy: function (t) {
                        return this.attr("dy", t)
                    }, newLine: function () {
                        var t = this.parent(n.Text);
                        return this.dom.newLined = !0, this.dy(t.dom.leading * t.attr("font-size")).attr("x", t.x())
                    }
                }
            }), n.extend(n.Text, n.Tspan, {
                plain: function (t) {
                    return !1 === this._build && this.clear(), this.node.appendChild(e.createTextNode(t)), this
                }, tspan: function (t) {
                    var e = (this.textPath && this.textPath() || this).node, r = new n.Tspan;
                    return !1 === this._build && this.clear(), e.appendChild(r.node), r.text(t)
                }, clear: function () {
                    for (var t = (this.textPath && this.textPath() || this).node; t.hasChildNodes();) t.removeChild(t.lastChild);
                    return this
                }, length: function () {
                    return this.node.getComputedTextLength()
                }
            }), n.TextPath = n.invent({
                create: "textPath",
                inherit: n.Parent,
                parent: n.Text,
                construct: {
                    morphArray: n.PathArray, path: function (t) {
                        for (var e = new n.TextPath, r = this.doc().defs().path(t); this.node.hasChildNodes();) e.node.appendChild(this.node.firstChild);
                        return this.node.appendChild(e.node), e.attr("href", "#" + r, n.xlink), this
                    }, array: function () {
                        var t = this.track();
                        return t ? t.array() : null
                    }, plot: function (t) {
                        var e = this.track(), n = null;
                        return e && (n = e.plot(t)), null == t ? n : this
                    }, track: function () {
                        var t = this.textPath();
                        if (t) return t.reference("href")
                    }, textPath: function () {
                        if (this.node.firstChild && "textPath" == this.node.firstChild.nodeName) return n.adopt(this.node.firstChild)
                    }
                }
            }), n.Nested = n.invent({
                create: function () {
                    this.constructor.call(this, n.create("svg")), this.style("overflow", "visible")
                }, inherit: n.Container, construct: {
                    nested: function () {
                        return this.put(new n.Nested)
                    }
                }
            }), n.A = n.invent({
                create: "a", inherit: n.Container, extend: {
                    to: function (t) {
                        return this.attr("href", t, n.xlink)
                    }, show: function (t) {
                        return this.attr("show", t, n.xlink)
                    }, target: function (t) {
                        return this.attr("target", t)
                    }
                }, construct: {
                    link: function (t) {
                        return this.put(new n.A).to(t)
                    }
                }
            }), n.extend(n.Element, {
                linkTo: function (t) {
                    var e = new n.A;
                    return "function" == typeof t ? t.call(e, e) : e.to(t), this.parent().put(e).put(this)
                }
            }), n.Marker = n.invent({
                create: "marker", inherit: n.Container, extend: {
                    width: function (t) {
                        return this.attr("markerWidth", t)
                    }, height: function (t) {
                        return this.attr("markerHeight", t)
                    }, ref: function (t, e) {
                        return this.attr("refX", t).attr("refY", e)
                    }, update: function (t) {
                        return this.clear(), "function" == typeof t && t.call(this, this), this
                    }, toString: function () {
                        return "url(#" + this.id() + ")"
                    }
                }, construct: {
                    marker: function (t, e, n) {
                        return this.defs().marker(t, e, n)
                    }
                }
            }), n.extend(n.Defs, {
                marker: function (t, e, r) {
                    return this.put(new n.Marker).size(t, e).ref(t / 2, e / 2).viewbox(0, 0, t, e).attr("orient", "auto").update(r)
                }
            }), n.extend(n.Line, n.Polyline, n.Polygon, n.Path, {
                marker: function (t, e, r, i) {
                    var o = ["marker"];
                    return "all" != t && o.push(t), o = o.join("-"), t = arguments[1] instanceof n.Marker ? arguments[1] : this.doc().marker(e, r, i), this.attr(o, t)
                }
            });
            var a = {
                stroke: ["color", "width", "opacity", "linecap", "linejoin", "miterlimit", "dasharray", "dashoffset"],
                fill: ["color", "opacity", "rule"],
                prefix: function (t, e) {
                    return "color" == e ? t : t + "-" + e
                }
            };

            function c(t, e, r, i) {
                return r + i.replace(n.regex.dots, " .")
            }

            function l(t) {
                return t.toLowerCase().replace(/-(.)/g, function (t, e) {
                    return e.toUpperCase()
                })
            }

            function u(t) {
                return t.charAt(0).toUpperCase() + t.slice(1)
            }

            function h(t) {
                var e = t.toString(16);
                return 1 == e.length ? "0" + e : e
            }

            function f(t, e, n) {
                if (null == e || null == n) {
                    var r = t.bbox();
                    null == e ? e = r.width / r.height * n : null == n && (n = r.height / r.width * e)
                }
                return {width: e, height: n}
            }

            function p(t, e, n) {
                return {x: e * t.a + n * t.c + 0, y: e * t.b + n * t.d + 0}
            }

            function d(t) {
                return {a: t[0], b: t[1], c: t[2], d: t[3], e: t[4], f: t[5]}
            }

            function y(t, e) {
                t.cx = null == t.cx ? e.bbox().cx : t.cx, t.cy = null == t.cy ? e.bbox().cy : t.cy
            }

            function m(e) {
                for (var r = e.childNodes.length - 1; r >= 0; r--) e.childNodes[r] instanceof t.SVGElement && m(e.childNodes[r]);
                return n.adopt(e).id(n.eid(e.nodeName))
            }

            function v(t) {
                return null == t.x && (t.x = 0, t.y = 0, t.width = 0, t.height = 0), t.w = t.width, t.h = t.height, t.x2 = t.x + t.width, t.y2 = t.y + t.height, t.cx = t.x + t.width / 2, t.cy = t.y + t.height / 2, t
            }

            function g(t) {
                return Math.abs(t) > 1e-37 ? t : 0
            }

            ["fill", "stroke"].forEach(function (t) {
                var e, r = {};
                r[t] = function (r) {
                    if (void 0 === r) return this;
                    if ("string" == typeof r || n.Color.isRgb(r) || r && "function" == typeof r.fill) this.attr(t, r); else for (e = a[t].length - 1; e >= 0; e--) null != r[a[t][e]] && this.attr(a.prefix(t, a[t][e]), r[a[t][e]]);
                    return this
                }, n.extend(n.Element, n.FX, r)
            }), n.extend(n.Element, n.FX, {
                rotate: function (t, e, n) {
                    return this.transform({rotation: t, cx: e, cy: n})
                }, skew: function (t, e, n, r) {
                    return 1 == arguments.length || 3 == arguments.length ? this.transform({
                        skew: t,
                        cx: e,
                        cy: n
                    }) : this.transform({skewX: t, skewY: e, cx: n, cy: r})
                }, scale: function (t, e, n, r) {
                    return 1 == arguments.length || 3 == arguments.length ? this.transform({
                        scale: t,
                        cx: e,
                        cy: n
                    }) : this.transform({scaleX: t, scaleY: e, cx: n, cy: r})
                }, translate: function (t, e) {
                    return this.transform({x: t, y: e})
                }, flip: function (t, e) {
                    return e = "number" == typeof t ? t : e, this.transform({flip: t || "both", offset: e})
                }, matrix: function (t) {
                    return this.attr("transform", new n.Matrix(6 == arguments.length ? [].slice.call(arguments) : t))
                }, opacity: function (t) {
                    return this.attr("opacity", t)
                }, dx: function (t) {
                    return this.x(new n.Number(t).plus(this instanceof n.FX ? 0 : this.x()), !0)
                }, dy: function (t) {
                    return this.y(new n.Number(t).plus(this instanceof n.FX ? 0 : this.y()), !0)
                }, dmove: function (t, e) {
                    return this.dx(t).dy(e)
                }
            }), n.extend(n.Rect, n.Ellipse, n.Circle, n.Gradient, n.FX, {
                radius: function (t, e) {
                    var r = (this._target || this).type;
                    return "radial" == r || "circle" == r ? this.attr("r", new n.Number(t)) : this.rx(t).ry(null == e ? t : e)
                }
            }), n.extend(n.Path, {
                length: function () {
                    return this.node.getTotalLength()
                }, pointAt: function (t) {
                    return this.node.getPointAtLength(t)
                }
            }), n.extend(n.Parent, n.Text, n.Tspan, n.FX, {
                font: function (t, e) {
                    if ("object" == typeof t) for (e in t) this.font(e, t[e]);
                    return "leading" == t ? this.leading(e) : "anchor" == t ? this.attr("text-anchor", e) : "size" == t || "family" == t || "weight" == t || "stretch" == t || "variant" == t || "style" == t ? this.attr("font-" + t, e) : this.attr(t, e)
                }
            }), n.Set = n.invent({
                create: function (t) {
                    t instanceof n.Set ? this.members = t.members.slice() : Array.isArray(t) ? this.members = t : this.clear()
                }, extend: {
                    add: function () {
                        var t, e, n = [].slice.call(arguments);
                        for (t = 0, e = n.length; t < e; t++) this.members.push(n[t]);
                        return this
                    }, remove: function (t) {
                        var e = this.index(t);
                        return e > -1 && this.members.splice(e, 1), this
                    }, each: function (t) {
                        for (var e = 0, n = this.members.length; e < n; e++) t.apply(this.members[e], [e, this.members]);
                        return this
                    }, clear: function () {
                        return this.members = [], this
                    }, length: function () {
                        return this.members.length
                    }, has: function (t) {
                        return this.index(t) >= 0
                    }, index: function (t) {
                        return this.members.indexOf(t)
                    }, get: function (t) {
                        return this.members[t]
                    }, first: function () {
                        return this.get(0)
                    }, last: function () {
                        return this.get(this.members.length - 1)
                    }, valueOf: function () {
                        return this.members
                    }, bbox: function () {
                        if (0 == this.members.length) return new n.RBox;
                        var t = this.members[0].rbox(this.members[0].doc());
                        return this.each(function () {
                            t = t.merge(this.rbox(this.doc()))
                        }), t
                    }
                }, construct: {
                    set: function (t) {
                        return new n.Set(t)
                    }
                }
            }), n.FX.Set = n.invent({
                create: function (t) {
                    this.set = t
                }
            }), n.Set.inherit = function () {
                var t = [];
                for (var e in n.Shape.prototype) "function" == typeof n.Shape.prototype[e] && "function" != typeof n.Set.prototype[e] && t.push(e);
                for (var e in t.forEach(function (t) {
                    n.Set.prototype[t] = function () {
                        for (var e = 0, r = this.members.length; e < r; e++) this.members[e] && "function" == typeof this.members[e][t] && this.members[e][t].apply(this.members[e], arguments);
                        return "animate" == t ? this.fx || (this.fx = new n.FX.Set(this)) : this
                    }
                }), t = [], n.FX.prototype) "function" == typeof n.FX.prototype[e] && "function" != typeof n.FX.Set.prototype[e] && t.push(e);
                t.forEach(function (t) {
                    n.FX.Set.prototype[t] = function () {
                        for (var e = 0, n = this.set.members.length; e < n; e++) this.set.members[e].fx[t].apply(this.set.members[e].fx, arguments);
                        return this
                    }
                })
            }, n.extend(n.Element, {
                data: function (t, e, n) {
                    if ("object" == typeof t) for (e in t) this.data(e, t[e]); else if (arguments.length < 2) try {
                        return JSON.parse(this.attr("data-" + t))
                    } catch (e) {
                        return this.attr("data-" + t)
                    } else this.attr("data-" + t, null === e ? null : !0 === n || "string" == typeof e || "number" == typeof e ? e : JSON.stringify(e));
                    return this
                }
            }), n.extend(n.Element, {
                remember: function (t, e) {
                    if ("object" == typeof arguments[0]) for (var e in t) this.remember(e, t[e]); else {
                        if (1 == arguments.length) return this.memory()[t];
                        this.memory()[t] = e
                    }
                    return this
                }, forget: function () {
                    if (0 == arguments.length) this._memory = {}; else for (var t = arguments.length - 1; t >= 0; t--) delete this.memory()[arguments[t]];
                    return this
                }, memory: function () {
                    return this._memory || (this._memory = {})
                }
            }), n.get = function (t) {
                var r = e.getElementById(function (t) {
                    var e = (t || "").toString().match(n.regex.reference);
                    if (e) return e[1]
                }(t) || t);
                return n.adopt(r)
            }, n.select = function (t, r) {
                return new n.Set(n.utils.map((r || e).querySelectorAll(t), function (t) {
                    return n.adopt(t)
                }))
            }, n.extend(n.Parent, {
                select: function (t) {
                    return n.select(t, this.node)
                }
            });
            var x = "abcdef".split("");
            if ("function" != typeof t.CustomEvent) {
                var b = function (t, n) {
                    n = n || {bubbles: !1, cancelable: !1, detail: void 0};
                    var r = e.createEvent("CustomEvent");
                    return r.initCustomEvent(t, n.bubbles, n.cancelable, n.detail), r
                };
                b.prototype = t.Event.prototype, n.CustomEvent = b
            } else n.CustomEvent = t.CustomEvent;
            return function (e) {
                for (var n = 0, r = ["moz", "webkit"], i = 0; i < r.length && !t.requestAnimationFrame; ++i) e.requestAnimationFrame = e[r[i] + "RequestAnimationFrame"], e.cancelAnimationFrame = e[r[i] + "CancelAnimationFrame"] || e[r[i] + "CancelRequestAnimationFrame"];
                e.requestAnimationFrame = e.requestAnimationFrame || function (t) {
                    var r = (new Date).getTime(), i = Math.max(0, 16 - (r - n)), o = e.setTimeout(function () {
                        t(r + i)
                    }, i);
                    return n = r + i, o
                }, e.cancelAnimationFrame = e.cancelAnimationFrame || e.clearTimeout
            }(t), n
        }(i, i.document)
    }.call(e, n, e, t)) || (t.exports = r)
}, function (t, e) {
    var n = {}.toString;
    t.exports = Array.isArray || function (t) {
        return "[object Array]" == n.call(t)
    }
}, function (t, e) {
    t.exports = function (t) {
        return JSON.parse(JSON.stringify(t))
    }
}, function (t, e, n) {
    "use strict";
    var r = n(6);

    function i(t, e) {
        var r = n(4), i = this;
        "function" == typeof Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : i.stack = (new Error).stack || "Cannot get a stacktrace, browser is too old", this.name = "AlgoliaSearchError", this.message = t || "Unknown error", e && r(e, function (t, e) {
            i[e] = t
        })
    }

    function o(t, e) {
        function n() {
            var n = Array.prototype.slice.call(arguments, 0);
            "string" != typeof n[0] && n.unshift(e), i.apply(this, n), this.name = "AlgoliaSearch" + t + "Error"
        }

        return r(n, i), n
    }

    r(i, Error), t.exports = {
        AlgoliaSearchError: i,
        UnparsableJSON: o("UnparsableJSON", "Could not parse the incoming response as JSON, see err.more for details"),
        RequestTimeout: o("RequestTimeout", "Request timed out before getting a response"),
        Network: o("Network", "Network issue, see err.more for details"),
        JSONPScriptFail: o("JSONPScriptFail", "<script> was loaded but did not call our provided callback"),
        JSONPScriptError: o("JSONPScriptError", "<script> unable to load due to an `error` event on it"),
        Unknown: o("Unknown", "Unknown error occured")
    }
}, function (t, e) {
    var n = Object.prototype.hasOwnProperty, r = Object.prototype.toString;
    t.exports = function (t, e, i) {
        if ("[object Function]" !== r.call(e)) throw new TypeError("iterator must be a function");
        var o = t.length;
        if (o === +o) for (var s = 0; s < o; s++) e.call(i, t[s], s, t); else for (var a in t) n.call(t, a) && e.call(i, t[a], a, t)
    }
}, function (t, e, n) {
    var r = n(4);
    t.exports = function (t, e) {
        var n = [];
        return r(t, function (r, i) {
            n.push(e(r, i, t))
        }), n
    }
}, function (t, e) {
    "function" == typeof Object.create ? t.exports = function (t, e) {
        e && (t.super_ = e, t.prototype = Object.create(e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }))
    } : t.exports = function (t, e) {
        if (e) {
            t.super_ = e;
            var n = function () {
            };
            n.prototype = e.prototype, t.prototype = new n, t.prototype.constructor = t
        }
    }
}, function (t, e, n) {
    "use strict";
    const r = n(23), i = n(24), o = n(25);

    function s(t, e) {
        return e.encode ? e.strict ? r(t) : encodeURIComponent(t) : t
    }

    function a(t, e) {
        return e.decode ? i(t) : t
    }

    function c(t) {
        const e = t.indexOf("#");
        return -1 !== e && (t = t.slice(0, e)), t
    }

    function l(t) {
        const e = (t = c(t)).indexOf("?");
        return -1 === e ? "" : t.slice(e + 1)
    }

    function u(t, e) {
        const n = function (t) {
                let e;
                switch (t.arrayFormat) {
                    case"index":
                        return (t, n, r) => {
                            e = /\[(\d*)\]$/.exec(t), t = t.replace(/\[\d*\]$/, ""), e ? (void 0 === r[t] && (r[t] = {}), r[t][e[1]] = n) : r[t] = n
                        };
                    case"bracket":
                        return (t, n, r) => {
                            e = /(\[\])$/.exec(t), t = t.replace(/\[\]$/, ""), e ? void 0 !== r[t] ? r[t] = [].concat(r[t], n) : r[t] = [n] : r[t] = n
                        };
                    case"comma":
                        return (t, e, n) => {
                            const r = "string" == typeof e && e.split("").indexOf(",") > -1 ? e.split(",") : e;
                            n[t] = r
                        };
                    default:
                        return (t, e, n) => {
                            void 0 !== n[t] ? n[t] = [].concat(n[t], e) : n[t] = e
                        }
                }
            }(e = Object.assign({decode: !0, sort: !0, arrayFormat: "none", parseNumbers: !1, parseBooleans: !1}, e)),
            r = Object.create(null);
        if ("string" != typeof t) return r;
        if (!(t = t.trim().replace(/^[?#&]/, ""))) return r;
        for (const i of t.split("&")) {
            let [t, s] = o(i.replace(/\+/g, " "), "=");
            s = void 0 === s ? null : a(s, e), e.parseNumbers && !Number.isNaN(Number(s)) && "string" == typeof s && "" !== s.trim() ? s = Number(s) : !e.parseBooleans || null === s || "true" !== s.toLowerCase() && "false" !== s.toLowerCase() || (s = "true" === s.toLowerCase()), n(a(t, e), s, r)
        }
        return !1 === e.sort ? r : (!0 === e.sort ? Object.keys(r).sort() : Object.keys(r).sort(e.sort)).reduce((t, e) => {
            const n = r[e];
            return Boolean(n) && "object" == typeof n && !Array.isArray(n) ? t[e] = function t(e) {
                return Array.isArray(e) ? e.sort() : "object" == typeof e ? t(Object.keys(e)).sort((t, e) => Number(t) - Number(e)).map(t => e[t]) : e
            }(n) : t[e] = n, t
        }, Object.create(null))
    }

    e.extract = l, e.parse = u, e.stringify = (t, e) => {
        if (!t) return "";
        const n = function (t) {
            switch (t.arrayFormat) {
                case"index":
                    return e => (n, r) => {
                        const i = n.length;
                        return void 0 === r ? n : null === r ? [...n, [s(e, t), "[", i, "]"].join("")] : [...n, [s(e, t), "[", s(i, t), "]=", s(r, t)].join("")]
                    };
                case"bracket":
                    return e => (n, r) => void 0 === r ? n : null === r ? [...n, [s(e, t), "[]"].join("")] : [...n, [s(e, t), "[]=", s(r, t)].join("")];
                case"comma":
                    return e => (n, r, i) => null == r || 0 === r.length ? n : 0 === i ? [[s(e, t), "=", s(r, t)].join("")] : [[n, s(r, t)].join(",")];
                default:
                    return e => (n, r) => void 0 === r ? n : null === r ? [...n, s(e, t)] : [...n, [s(e, t), "=", s(r, t)].join("")]
            }
        }(e = Object.assign({encode: !0, strict: !0, arrayFormat: "none"}, e)), r = Object.keys(t);
        return !1 !== e.sort && r.sort(e.sort), r.map(r => {
            const i = t[r];
            return void 0 === i ? "" : null === i ? s(r, e) : Array.isArray(i) ? i.reduce(n(r), []).join("&") : s(r, e) + "=" + s(i, e)
        }).filter(t => t.length > 0).join("&")
    }, e.parseUrl = (t, e) => ({url: c(t).split("?")[0] || "", query: u(l(t), e)})
}, function (t, e) {
    var n;
    n = function () {
        return this
    }();
    try {
        n = n || new Function("return this")()
    } catch (t) {
        "object" == typeof window && (n = window)
    }
    t.exports = n
}, function (t, e, n) {
    (function (r) {
        function i() {
            var t;
            try {
                t = e.storage.debug
            } catch (t) {
            }
            return !t && void 0 !== r && "env" in r && (t = r.env.DEBUG), t
        }

        (e = t.exports = n(34)).log = function () {
            return "object" == typeof console && console.log && Function.prototype.apply.call(console.log, console, arguments)
        }, e.formatArgs = function (t) {
            var n = this.useColors;
            if (t[0] = (n ? "%c" : "") + this.namespace + (n ? " %c" : " ") + t[0] + (n ? "%c " : " ") + "+" + e.humanize(this.diff), !n) return;
            var r = "color: " + this.color;
            t.splice(1, 0, r, "color: inherit");
            var i = 0, o = 0;
            t[0].replace(/%[a-zA-Z%]/g, function (t) {
                "%%" !== t && (i++, "%c" === t && (o = i))
            }), t.splice(o, 0, r)
        }, e.save = function (t) {
            try {
                null == t ? e.storage.removeItem("debug") : e.storage.debug = t
            } catch (t) {
            }
        }, e.load = i, e.useColors = function () {
            if ("undefined" != typeof window && window.process && "renderer" === window.process.type) return !0;
            return "undefined" != typeof document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" != typeof window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31 || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/)
        }, e.storage = "undefined" != typeof chrome && void 0 !== chrome.storage ? chrome.storage.local : function () {
            try {
                return window.localStorage
            } catch (t) {
            }
        }(), e.colors = ["lightseagreen", "forestgreen", "goldenrod", "dodgerblue", "darkorchid", "crimson"], e.formatters.j = function (t) {
            try {
                return JSON.stringify(t)
            } catch (t) {
                return "[UnexpectedJSONParseError]: " + t.message
            }
        }, e.enable(i())
    }).call(this, n(12))
}, function (t, e) {
    t.exports = function (t, e) {
        var n = !1;
        return function () {
            return n || (console.warn(e), n = !0), t.apply(this, arguments)
        }
    }
}, function (t, e) {
    t.exports = function (t, e) {
        var n = t.toLowerCase().replace(/[\.\(\)]/g, "");
        return "algoliasearch: `" + t + "` was replaced by `" + e + "`. Please see https://github.com/algolia/algoliasearch-client-javascript/wiki/Deprecated#" + n
    }
}, function (t, e) {
    var n, r, i = t.exports = {};

    function o() {
        throw new Error("setTimeout has not been defined")
    }

    function s() {
        throw new Error("clearTimeout has not been defined")
    }

    function a(t) {
        if (n === setTimeout) return setTimeout(t, 0);
        if ((n === o || !n) && setTimeout) return n = setTimeout, setTimeout(t, 0);
        try {
            return n(t, 0)
        } catch (e) {
            try {
                return n.call(null, t, 0)
            } catch (e) {
                return n.call(this, t, 0)
            }
        }
    }

    !function () {
        try {
            n = "function" == typeof setTimeout ? setTimeout : o
        } catch (t) {
            n = o
        }
        try {
            r = "function" == typeof clearTimeout ? clearTimeout : s
        } catch (t) {
            r = s
        }
    }();
    var c, l = [], u = !1, h = -1;

    function f() {
        u && c && (u = !1, c.length ? l = c.concat(l) : h = -1, l.length && p())
    }

    function p() {
        if (!u) {
            var t = a(f);
            u = !0;
            for (var e = l.length; e;) {
                for (c = l, l = []; ++h < e;) c && c[h].run();
                h = -1, e = l.length
            }
            c = null, u = !1, function (t) {
                if (r === clearTimeout) return clearTimeout(t);
                if ((r === s || !r) && clearTimeout) return r = clearTimeout, clearTimeout(t);
                try {
                    r(t)
                } catch (e) {
                    try {
                        return r.call(null, t)
                    } catch (e) {
                        return r.call(this, t)
                    }
                }
            }(t)
        }
    }

    function d(t, e) {
        this.fun = t, this.array = e
    }

    function y() {
    }

    i.nextTick = function (t) {
        var e = new Array(arguments.length - 1);
        if (arguments.length > 1) for (var n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
        l.push(new d(t, e)), 1 !== l.length || u || a(p)
    }, d.prototype.run = function () {
        this.fun.apply(null, this.array)
    }, i.title = "browser", i.browser = !0, i.env = {}, i.argv = [], i.version = "", i.versions = {}, i.on = y, i.addListener = y, i.once = y, i.off = y, i.removeListener = y, i.removeAllListeners = y, i.emit = y, i.prependListener = y, i.prependOnceListener = y, i.listeners = function (t) {
        return []
    }, i.binding = function (t) {
        throw new Error("process.binding is not supported")
    }, i.cwd = function () {
        return "/"
    }, i.chdir = function (t) {
        throw new Error("process.chdir is not supported")
    }, i.umask = function () {
        return 0
    }
}, function (t, e, n) {
    "use strict";
    var r = n(26), i = n(37);
    t.exports = i(r, "Browser")
}, function (t, e, n) {
    var r = n(15), i = n(10), o = n(11);

    function s(t, e) {
        this.indexName = e, this.as = t, this.typeAheadArgs = null, this.typeAheadValueOption = null, this.cache = {}
    }

    t.exports = s, s.prototype.clearCache = function () {
        this.cache = {}
    }, s.prototype.search = r("query"), s.prototype.similarSearch = i(r("similarQuery"), o("index.similarSearch(query[, callback])", "index.search({ similarQuery: query }[, callback])")), s.prototype.browse = function (t, e, r) {
        var i, o, s = n(16), a = this;
        0 === arguments.length || 1 === arguments.length && "function" == typeof arguments[0] ? (i = 0, r = arguments[0], t = void 0) : "number" == typeof arguments[0] ? (i = arguments[0], "number" == typeof arguments[1] ? o = arguments[1] : "function" == typeof arguments[1] && (r = arguments[1], o = void 0), t = void 0, e = void 0) : "object" == typeof arguments[0] ? ("function" == typeof arguments[1] && (r = arguments[1]), e = arguments[0], t = void 0) : "string" == typeof arguments[0] && "function" == typeof arguments[1] && (r = arguments[1], e = void 0), e = s({}, e || {}, {
            page: i,
            hitsPerPage: o,
            query: t
        });
        var c = this.as._getSearchParams(e, "");
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(a.indexName) + "/browse",
            body: {params: c},
            hostType: "read",
            callback: r
        })
    }, s.prototype.browseFrom = function (t, e) {
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/browse",
            body: {cursor: t},
            hostType: "read",
            callback: e
        })
    }, s.prototype.searchForFacetValues = function (t, e) {
        var r = n(2), i = n(17);
        if (void 0 === t.facetName || void 0 === t.facetQuery) throw new Error("Usage: index.searchForFacetValues({facetName, facetQuery, ...params}[, callback])");
        var o = t.facetName, s = i(r(t), function (t) {
            return "facetName" === t
        }), a = this.as._getSearchParams(s, "");
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/facets/" + encodeURIComponent(o) + "/query",
            hostType: "read",
            body: {params: a},
            callback: e
        })
    }, s.prototype.searchFacet = i(function (t, e) {
        return this.searchForFacetValues(t, e)
    }, o("index.searchFacet(params[, callback])", "index.searchForFacetValues(params[, callback])")), s.prototype._search = function (t, e, n, r) {
        return this.as._jsonRequest({
            cache: this.cache,
            method: "POST",
            url: e || "/1/indexes/" + encodeURIComponent(this.indexName) + "/query",
            body: {params: t},
            hostType: "read",
            fallback: {method: "GET", url: "/1/indexes/" + encodeURIComponent(this.indexName), body: {params: t}},
            callback: n,
            additionalUA: r
        })
    }, s.prototype.getObject = function (t, e, n) {
        var r = this;
        1 !== arguments.length && "function" != typeof e || (n = e, e = void 0);
        var i = "";
        if (void 0 !== e) {
            i = "?attributes=";
            for (var o = 0; o < e.length; ++o) 0 !== o && (i += ","), i += e[o]
        }
        return this.as._jsonRequest({
            method: "GET",
            url: "/1/indexes/" + encodeURIComponent(r.indexName) + "/" + encodeURIComponent(t) + i,
            hostType: "read",
            callback: n
        })
    }, s.prototype.getObjects = function (t, e, r) {
        var i = n(1), o = n(5), s = "Usage: index.getObjects(arrayOfObjectIDs[, callback])";
        if (!i(t)) throw new Error(s);
        var a = this;
        1 !== arguments.length && "function" != typeof e || (r = e, e = void 0);
        var c = {
            requests: o(t, function (t) {
                var n = {indexName: a.indexName, objectID: t};
                return e && (n.attributesToRetrieve = e.join(",")), n
            })
        };
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/*/objects",
            hostType: "read",
            body: c,
            callback: r
        })
    }, s.prototype.as = null, s.prototype.indexName = null, s.prototype.typeAheadArgs = null, s.prototype.typeAheadValueOption = null
}, function (t, e, n) {
    t.exports = function (t, e) {
        return function (n, i, o) {
            if ("function" == typeof n && "object" == typeof i || "object" == typeof o) throw new r.AlgoliaSearchError("index.search usage is index.search(query, params, cb)");
            0 === arguments.length || "function" == typeof n ? (o = n, n = "") : 1 !== arguments.length && "function" != typeof i || (o = i, i = void 0), "object" == typeof n && null !== n ? (i = n, n = void 0) : null == n && (n = "");
            var s, a = "";
            return void 0 !== n && (a += t + "=" + encodeURIComponent(n)), void 0 !== i && (i.additionalUA && (s = i.additionalUA, delete i.additionalUA), a = this.as._getSearchParams(i, a)), this._search(a, e, o, s)
        }
    };
    var r = n(3)
}, function (t, e, n) {
    var r = n(4);
    t.exports = function t(e) {
        var n = Array.prototype.slice.call(arguments);
        return r(n, function (n) {
            for (var r in n) n.hasOwnProperty(r) && ("object" == typeof e[r] && "object" == typeof n[r] ? e[r] = t({}, e[r], n[r]) : void 0 !== n[r] && (e[r] = n[r]))
        }), e
    }
}, function (t, e, n) {
    t.exports = function (t, e) {
        var r = n(28), i = n(4), o = {};
        return i(r(t), function (n) {
            !0 !== e(n) && (o[n] = t[n])
        }), o
    }
}, function (t, e, n) {
    "use strict";
    var r = Object.prototype.toString;
    t.exports = function (t) {
        var e = r.call(t), n = "[object Arguments]" === e;
        return n || (n = "[object Array]" !== e && null !== t && "object" == typeof t && "number" == typeof t.length && t.length >= 0 && "[object Function]" === r.call(t.callee)), n
    }
}, function (t, e) {
    t.exports = function (t, e) {
        e(t, 0)
    }
}, function (t, e, n) {
    "use strict";
    var r = function (t) {
        switch (typeof t) {
            case"string":
                return t;
            case"boolean":
                return t ? "true" : "false";
            case"number":
                return isFinite(t) ? t : "";
            default:
                return ""
        }
    };
    t.exports = function (t, e, n, a) {
        return e = e || "&", n = n || "=", null === t && (t = void 0), "object" == typeof t ? o(s(t), function (s) {
            var a = encodeURIComponent(r(s)) + n;
            return i(t[s]) ? o(t[s], function (t) {
                return a + encodeURIComponent(r(t))
            }).join(e) : a + encodeURIComponent(r(t[s]))
        }).join(e) : a ? encodeURIComponent(r(a)) + n + encodeURIComponent(r(t)) : ""
    };
    var i = Array.isArray || function (t) {
        return "[object Array]" === Object.prototype.toString.call(t)
    };

    function o(t, e) {
        if (t.map) return t.map(e);
        for (var n = [], r = 0; r < t.length; r++) n.push(e(t[r], r));
        return n
    }

    var s = Object.keys || function (t) {
        var e = [];
        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && e.push(n);
        return e
    }
}, function (t, e, n) {
    "use strict";
    (function (t) {
        var n = "object" == typeof t && t && t.Object === Object && t;
        e.a = n
    }).call(this, n(8))
}, function (t, e, n) {
    t.exports = function () {
        "use strict";
        var t = function () {
            return document.documentElement.clientWidth
        }, e = function () {
            return document.documentElement.clientHeight
        }, n = function (t, e) {
            this.w = t, this.h = e
        }, r = function (t, e) {
            this.img = t, this.preservedTransform = t.style.transform, this.wrap = null, this.overlay = null, this.offset = e
        };
        r.prototype.forceRepaint = function () {
            this.img.offsetWidth
        }, r.prototype.zoom = function () {
            var t = new n(this.img.naturalWidth, this.img.naturalHeight);
            this.wrap = document.createElement("div"), this.wrap.classList.add("zoom-img-wrap"), this.img.parentNode.insertBefore(this.wrap, this.img), this.wrap.appendChild(this.img), this.img.classList.add("zoom-img"), this.img.setAttribute("data-action", "zoom-out"), this.overlay = document.createElement("div"), this.overlay.classList.add("zoom-overlay"), document.body.appendChild(this.overlay), this.forceRepaint();
            var e = this.calculateScale(t);
            this.forceRepaint(), this.animate(e), document.body.classList.add("zoom-overlay-open")
        }, r.prototype.calculateScale = function (n) {
            var r = n.w / this.img.width, i = t() - this.offset, o = e() - this.offset, s = n.w / n.h, a = i / o;
            return n.w < i && n.h < o ? r : s < a ? o / n.h * r : i / n.w * r
        }, r.prototype.animate = function (n) {
            var r, i, o, s,
                a = (r = this.img, i = r.getBoundingClientRect(), o = document.documentElement, s = window, {
                    top: i.top + s.pageYOffset - o.clientTop,
                    left: i.left + s.pageXOffset - o.clientLeft
                }), c = window.pageYOffset, l = t() / 2, u = c + e() / 2, h = a.left + this.img.width / 2,
                f = a.top + this.img.height / 2, p = l - h, d = u - f, y = "scale(" + n + ")",
                m = "translate3d(" + p + "px, " + d + "px, 0px)";
            this.img.style.transform = y, this.wrap.style.transform = m
        }, r.prototype.dispose = function () {
            null !== this.wrap && null !== this.wrap.parentNode && (this.img.classList.remove("zoom-img"), this.img.setAttribute("data-action", "zoom"), this.wrap.parentNode.insertBefore(this.img, this.wrap), this.wrap.parentNode.removeChild(this.wrap), document.body.removeChild(this.overlay), document.body.classList.remove("zoom-overlay-transitioning"))
        }, r.prototype.close = function () {
            var t, e, n, r, i = this;
            document.body.classList.add("zoom-overlay-transitioning"), this.img.style.transform = this.preservedTransform, 0 === this.img.style.length && this.img.removeAttribute("style"), this.wrap.style.transform = "none", t = this.img, e = "transitionend", n = function () {
                i.dispose(), document.body.classList.remove("zoom-overlay-open")
            }, r = function (t) {
                t.target.removeEventListener(e, r), n()
            }, t.addEventListener(e, r)
        };
        /**
         * Pure JavaScript implementation of zoom.js.
         *
         * Original preamble:
         * zoom.js - It's the best way to zoom an image
         * @version v0.0.2
         * @link https://github.com/fat/zoom.js
         * @license MIT
         *
         * Needs a related CSS file to work. See the README at
         * https://github.com/nishanths/zoom.js for more info.
         *
         * This is a fork of the original zoom.js implementation by @fat.
         * Copyrights for the original project are held by @fat. All other copyright
         * for changes in the fork are held by Nishanth Shanmugham.
         *
         * Copyright (c) 2013 @fat
         * The MIT License. Copyright © 2016 Nishanth Shanmugham.
         */
        var i = null, o = 80, s = -1, a = -1;

        function c() {
            -1 === s && (s = window.pageYOffset);
            var t = Math.abs(s - window.pageYOffset);
            t >= 40 && p()
        }

        function l(t) {
            27 === t.keyCode && p()
        }

        function u(t) {
            var e = t.touches[0];
            null !== e && (a = e.pageY, t.target.addEventListener("touchmove", h))
        }

        function h(t) {
            var e = t.touches[0];
            null !== e && Math.abs(e.pageY - a) > 10 && (p(), t.target.removeEventListener("touchmove", h))
        }

        function f() {
            p()
        }

        function p(t) {
            null !== i && (t ? i.dispose() : i.close(), document.removeEventListener("scroll", c), document.removeEventListener("keyup", l), document.removeEventListener("touchstart", u), document.removeEventListener("click", f, !0), i = null)
        }

        function d(e) {
            document.body.classList.contains("zoom-overlay-open") || (e.metaKey || e.ctrlKey ? window.open(e.target.getAttribute("data-original") || e.target.src, "_blank") : e.target.width >= t() - o || (p(!0), (i = new r(e.target, o)).zoom(), document.addEventListener("scroll", c), document.addEventListener("keyup", l), document.addEventListener("touchstart", u), document.addEventListener("click", f, !0)))
        }

        return function (t) {
            return t.setAttribute("data-action", "zoom"), t.addEventListener("click", d), function () {
                return t.removeEventListener("click", d)
            }
        }
    }()
}, function (t, e, n) {
    "use strict";
    t.exports = t => encodeURIComponent(t).replace(/[!'()*]/g, t => `%${t.charCodeAt(0).toString(16).toUpperCase()}`)
}, function (t, e, n) {
    "use strict";
    var r = new RegExp("%[a-f0-9]{2}", "gi"), i = new RegExp("(%[a-f0-9]{2})+", "gi");

    function o(t, e) {
        try {
            return decodeURIComponent(t.join(""))
        } catch (t) {
        }
        if (1 === t.length) return t;
        e = e || 1;
        var n = t.slice(0, e), r = t.slice(e);
        return Array.prototype.concat.call([], o(n), o(r))
    }

    function s(t) {
        try {
            return decodeURIComponent(t)
        } catch (i) {
            for (var e = t.match(r), n = 1; n < e.length; n++) e = (t = o(e, n).join("")).match(r);
            return t
        }
    }

    t.exports = function (t) {
        if ("string" != typeof t) throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + typeof t + "`");
        try {
            return t = t.replace(/\+/g, " "), decodeURIComponent(t)
        } catch (e) {
            return function (t) {
                for (var e = {"%FE%FF": "��", "%FF%FE": "��"}, n = i.exec(t); n;) {
                    try {
                        e[n[0]] = decodeURIComponent(n[0])
                    } catch (t) {
                        var r = s(n[0]);
                        r !== n[0] && (e[n[0]] = r)
                    }
                    n = i.exec(t)
                }
                e["%C2"] = "�";
                for (var o = Object.keys(e), a = 0; a < o.length; a++) {
                    var c = o[a];
                    t = t.replace(new RegExp(c, "g"), e[c])
                }
                return t
            }(t)
        }
    }
}, function (t, e, n) {
    "use strict";
    t.exports = (t, e) => {
        if ("string" != typeof t || "string" != typeof e) throw new TypeError("Expected the arguments to be of type `string`");
        if ("" === e) return [t];
        const n = t.indexOf(e);
        return -1 === n ? [t] : [t.slice(0, n), t.slice(n + e.length)]
    }
}, function (t, e, n) {
    t.exports = l;
    var r = n(27), i = n(10), o = n(11), s = n(32), a = n(6), c = n(3);

    function l() {
        s.apply(this, arguments)
    }

    function u() {
        throw new c.AlgoliaSearchError("Not implemented in this environment.\nIf you feel this is a mistake, write to support@algolia.com")
    }

    a(l, s), l.prototype.deleteIndex = function (t, e) {
        return this._jsonRequest({
            method: "DELETE",
            url: "/1/indexes/" + encodeURIComponent(t),
            hostType: "write",
            callback: e
        })
    }, l.prototype.moveIndex = function (t, e, n) {
        var r = {operation: "move", destination: e};
        return this._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(t) + "/operation",
            body: r,
            hostType: "write",
            callback: n
        })
    }, l.prototype.copyIndex = function (t, e, n, r) {
        var i = {operation: "copy", destination: e}, o = r;
        if ("function" == typeof n) o = n; else if (Array.isArray(n) && n.length > 0) i.scope = n; else if (void 0 !== n) throw new Error("the scope given to `copyIndex` was not an array with settings, synonyms or rules");
        return this._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(t) + "/operation",
            body: i,
            hostType: "write",
            callback: o
        })
    }, l.prototype.getLogs = function (t, e, r) {
        var i = n(2), o = {};
        return "object" == typeof t ? (o = i(t), r = e) : 0 === arguments.length || "function" == typeof t ? r = t : 1 === arguments.length || "function" == typeof e ? (r = e, o.offset = t) : (o.offset = t, o.length = e), void 0 === o.offset && (o.offset = 0), void 0 === o.length && (o.length = 10), this._jsonRequest({
            method: "GET",
            url: "/1/logs?" + this._getSearchParams(o, ""),
            hostType: "read",
            callback: r
        })
    }, l.prototype.listIndexes = function (t, e) {
        var n = "";
        return void 0 === t || "function" == typeof t ? e = t : n = "?page=" + t, this._jsonRequest({
            method: "GET",
            url: "/1/indexes" + n,
            hostType: "read",
            callback: e
        })
    }, l.prototype.initIndex = function (t) {
        return new r(this, t)
    }, l.prototype.initAnalytics = function (t) {
        return n(36)(this.applicationID, this.apiKey, t)
    }, l.prototype.listUserKeys = i(function (t) {
        return this.listApiKeys(t)
    }, o("client.listUserKeys()", "client.listApiKeys()")), l.prototype.listApiKeys = function (t) {
        return this._jsonRequest({method: "GET", url: "/1/keys", hostType: "read", callback: t})
    }, l.prototype.getUserKeyACL = i(function (t, e) {
        return this.getApiKey(t, e)
    }, o("client.getUserKeyACL()", "client.getApiKey()")), l.prototype.getApiKey = function (t, e) {
        return this._jsonRequest({method: "GET", url: "/1/keys/" + t, hostType: "read", callback: e})
    }, l.prototype.deleteUserKey = i(function (t, e) {
        return this.deleteApiKey(t, e)
    }, o("client.deleteUserKey()", "client.deleteApiKey()")), l.prototype.deleteApiKey = function (t, e) {
        return this._jsonRequest({method: "DELETE", url: "/1/keys/" + t, hostType: "write", callback: e})
    }, l.prototype.restoreApiKey = function (t, e) {
        return this._jsonRequest({method: "POST", url: "/1/keys/" + t + "/restore", hostType: "write", callback: e})
    }, l.prototype.addUserKey = i(function (t, e, n) {
        return this.addApiKey(t, e, n)
    }, o("client.addUserKey()", "client.addApiKey()")), l.prototype.addApiKey = function (t, e, r) {
        var i = n(1), o = "Usage: client.addApiKey(arrayOfAcls[, params, callback])";
        if (!i(t)) throw new Error(o);
        1 !== arguments.length && "function" != typeof e || (r = e, e = null);
        var s = {acl: t};
        return e && (s.validity = e.validity, s.maxQueriesPerIPPerHour = e.maxQueriesPerIPPerHour, s.maxHitsPerQuery = e.maxHitsPerQuery, s.indexes = e.indexes, s.description = e.description, e.queryParameters && (s.queryParameters = this._getSearchParams(e.queryParameters, "")), s.referers = e.referers), this._jsonRequest({
            method: "POST",
            url: "/1/keys",
            body: s,
            hostType: "write",
            callback: r
        })
    }, l.prototype.addUserKeyWithValidity = i(function (t, e, n) {
        return this.addApiKey(t, e, n)
    }, o("client.addUserKeyWithValidity()", "client.addApiKey()")), l.prototype.updateUserKey = i(function (t, e, n, r) {
        return this.updateApiKey(t, e, n, r)
    }, o("client.updateUserKey()", "client.updateApiKey()")), l.prototype.updateApiKey = function (t, e, r, i) {
        var o = n(1), s = "Usage: client.updateApiKey(key, arrayOfAcls[, params, callback])";
        if (!o(e)) throw new Error(s);
        2 !== arguments.length && "function" != typeof r || (i = r, r = null);
        var a = {acl: e};
        return r && (a.validity = r.validity, a.maxQueriesPerIPPerHour = r.maxQueriesPerIPPerHour, a.maxHitsPerQuery = r.maxHitsPerQuery, a.indexes = r.indexes, a.description = r.description, r.queryParameters && (a.queryParameters = this._getSearchParams(r.queryParameters, "")), a.referers = r.referers), this._jsonRequest({
            method: "PUT",
            url: "/1/keys/" + t,
            body: a,
            hostType: "write",
            callback: i
        })
    }, l.prototype.startQueriesBatch = i(function () {
        this._batch = []
    }, o("client.startQueriesBatch()", "client.search()")), l.prototype.addQueryInBatch = i(function (t, e, n) {
        this._batch.push({indexName: t, query: e, params: n})
    }, o("client.addQueryInBatch()", "client.search()")), l.prototype.sendQueriesBatch = i(function (t) {
        return this.search(this._batch, t)
    }, o("client.sendQueriesBatch()", "client.search()")), l.prototype.batch = function (t, e) {
        if (!n(1)(t)) throw new Error("Usage: client.batch(operations[, callback])");
        return this._jsonRequest({
            method: "POST",
            url: "/1/indexes/*/batch",
            body: {requests: t},
            hostType: "write",
            callback: e
        })
    }, l.prototype.assignUserID = function (t, e) {
        if (!t.userID || !t.cluster) throw new c.AlgoliaSearchError("You have to provide both a userID and cluster", t);
        return this._jsonRequest({
            method: "POST",
            url: "/1/clusters/mapping",
            hostType: "write",
            body: {cluster: t.cluster},
            callback: e,
            headers: {"x-algolia-user-id": t.userID}
        })
    }, l.prototype.getTopUserID = function (t) {
        return this._jsonRequest({method: "GET", url: "/1/clusters/mapping/top", hostType: "read", callback: t})
    }, l.prototype.getUserID = function (t, e) {
        if (!t.userID) throw new c.AlgoliaSearchError("You have to provide a userID", {debugData: t});
        return this._jsonRequest({method: "GET", url: "/1/clusters/mapping/" + t.userID, hostType: "read", callback: e})
    }, l.prototype.listClusters = function (t) {
        return this._jsonRequest({method: "GET", url: "/1/clusters", hostType: "read", callback: t})
    }, l.prototype.listUserIDs = function (t, e) {
        return this._jsonRequest({method: "GET", url: "/1/clusters/mapping", body: t, hostType: "read", callback: e})
    }, l.prototype.removeUserID = function (t, e) {
        if (!t.userID) throw new c.AlgoliaSearchError("You have to provide a userID", {debugData: t});
        return this._jsonRequest({
            method: "DELETE",
            url: "/1/clusters/mapping",
            hostType: "write",
            callback: e,
            headers: {"x-algolia-user-id": t.userID}
        })
    }, l.prototype.searchUserIDs = function (t, e) {
        return this._jsonRequest({
            method: "POST",
            url: "/1/clusters/mapping/search",
            body: t,
            hostType: "read",
            callback: e
        })
    }, l.prototype.setPersonalizationStrategy = function (t, e) {
        return this._jsonRequest({
            method: "POST",
            url: "/1/recommendation/personalization/strategy",
            body: t,
            hostType: "write",
            callback: e
        })
    }, l.prototype.getPersonalizationStrategy = function (t) {
        return this._jsonRequest({
            method: "GET",
            url: "/1/recommendation/personalization/strategy",
            hostType: "read",
            callback: t
        })
    }, l.prototype.destroy = u, l.prototype.enableRateLimitForward = u, l.prototype.disableRateLimitForward = u, l.prototype.useSecuredAPIKey = u, l.prototype.disableSecuredAPIKey = u, l.prototype.generateSecuredApiKey = u
}, function (t, e, n) {
    var r = n(6), i = n(14), o = n(10), s = n(11), a = n(19), c = n(3), l = o(function () {
    }, s("forwardToSlaves", "forwardToReplicas"));

    function u() {
        i.apply(this, arguments)
    }

    function h(t, e, n) {
        return function n(r, i) {
            var o = {page: r || 0, hitsPerPage: e || 100}, s = i || [];
            return t(o).then(function (t) {
                var e = t.hits, r = t.nbHits, i = e.map(function (t) {
                    return delete t._highlightResult, t
                }), a = s.concat(i);
                return a.length < r ? n(o.page + 1, a) : a
            })
        }().then(function (t) {
            if ("function" != typeof n) return t;
            n(t)
        })
    }

    t.exports = u, r(u, i), u.prototype.addObject = function (t, e, n) {
        var r = this;
        return 1 !== arguments.length && "function" != typeof e || (n = e, e = void 0), this.as._jsonRequest({
            method: void 0 !== e ? "PUT" : "POST",
            url: "/1/indexes/" + encodeURIComponent(r.indexName) + (void 0 !== e ? "/" + encodeURIComponent(e) : ""),
            body: t,
            hostType: "write",
            callback: n
        })
    }, u.prototype.addObjects = function (t, e) {
        if (!n(1)(t)) throw new Error("Usage: index.addObjects(arrayOfObjects[, callback])");
        for (var r = {requests: []}, i = 0; i < t.length; ++i) {
            var o = {action: "addObject", body: t[i]};
            r.requests.push(o)
        }
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/batch",
            body: r,
            hostType: "write",
            callback: e
        })
    }, u.prototype.partialUpdateObject = function (t, e, n) {
        1 !== arguments.length && "function" != typeof e || (n = e, e = void 0);
        var r = this,
            i = "/1/indexes/" + encodeURIComponent(r.indexName) + "/" + encodeURIComponent(t.objectID) + "/partial";
        return !1 === e && (i += "?createIfNotExists=false"), this.as._jsonRequest({
            method: "POST",
            url: i,
            body: t,
            hostType: "write",
            callback: n
        })
    }, u.prototype.partialUpdateObjects = function (t, e, r) {
        1 !== arguments.length && "function" != typeof e || (r = e, e = !0);
        var i = n(1), o = "Usage: index.partialUpdateObjects(arrayOfObjects[, callback])";
        if (!i(t)) throw new Error(o);
        for (var s = this, a = {requests: []}, c = 0; c < t.length; ++c) {
            var l = {
                action: !0 === e ? "partialUpdateObject" : "partialUpdateObjectNoCreate",
                objectID: t[c].objectID,
                body: t[c]
            };
            a.requests.push(l)
        }
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(s.indexName) + "/batch",
            body: a,
            hostType: "write",
            callback: r
        })
    }, u.prototype.saveObject = function (t, e) {
        return this.as._jsonRequest({
            method: "PUT",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/" + encodeURIComponent(t.objectID),
            body: t,
            hostType: "write",
            callback: e
        })
    }, u.prototype.saveObjects = function (t, e) {
        if (!n(1)(t)) throw new Error("Usage: index.saveObjects(arrayOfObjects[, callback])");
        for (var r = {requests: []}, i = 0; i < t.length; ++i) {
            var o = {action: "updateObject", objectID: t[i].objectID, body: t[i]};
            r.requests.push(o)
        }
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/batch",
            body: r,
            hostType: "write",
            callback: e
        })
    }, u.prototype.deleteObject = function (t, e) {
        if ("function" == typeof t || "string" != typeof t && "number" != typeof t) {
            var n = new c.AlgoliaSearchError(t && "function" != typeof t ? "ObjectID must be a string" : "Cannot delete an object without an objectID");
            return "function" == typeof (e = t) ? e(n) : this.as._promise.reject(n)
        }
        return this.as._jsonRequest({
            method: "DELETE",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/" + encodeURIComponent(t),
            hostType: "write",
            callback: e
        })
    }, u.prototype.deleteObjects = function (t, e) {
        var r = n(1), i = n(5);
        if (!r(t)) throw new Error("Usage: index.deleteObjects(arrayOfObjectIDs[, callback])");
        var o = {
            requests: i(t, function (t) {
                return {action: "deleteObject", objectID: t, body: {objectID: t}}
            })
        };
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/batch",
            body: o,
            hostType: "write",
            callback: e
        })
    }, u.prototype.deleteByQuery = o(function (t, e, r) {
        var i = n(2), o = n(5), s = this, c = s.as;
        1 === arguments.length || "function" == typeof e ? (r = e, e = {}) : e = i(e), e.attributesToRetrieve = "objectID", e.hitsPerPage = 1e3, e.distinct = !1, this.clearCache();
        var l = this.search(t, e).then(u);

        function u(t) {
            if (0 === t.nbHits) return t;
            var e = o(t.hits, function (t) {
                return t.objectID
            });
            return s.deleteObjects(e).then(h).then(f)
        }

        function h(t) {
            return s.waitTask(t.taskID)
        }

        function f() {
            return s.deleteByQuery(t, e)
        }

        if (!r) return l;

        function p() {
            a(function () {
                r(null)
            }, c._setTimeout || setTimeout)
        }

        function d(t) {
            a(function () {
                r(t)
            }, c._setTimeout || setTimeout)
        }

        l.then(p, d)
    }, s("index.deleteByQuery()", "index.deleteBy()")), u.prototype.deleteBy = function (t, e) {
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/deleteByQuery",
            body: {params: this.as._getSearchParams(t, "")},
            hostType: "write",
            callback: e
        })
    }, u.prototype.browseAll = function (t, e) {
        "object" == typeof t && (e = t, t = void 0);
        var r = n(16), i = new (n(30)), o = this.as, s = this, a = o._getSearchParams(r({}, e || {}, {query: t}), "");

        function c(t) {
            var e;
            i._stopped || (e = void 0 !== t ? {cursor: t} : {params: a}, o._jsonRequest({
                method: "POST",
                url: "/1/indexes/" + encodeURIComponent(s.indexName) + "/browse",
                hostType: "read",
                body: e,
                callback: l
            }))
        }

        function l(t, e) {
            i._stopped || (t ? i._error(t) : (i._result(e), void 0 !== e.cursor ? c(e.cursor) : i._end()))
        }

        return c(), i
    }, u.prototype.ttAdapter = o(function (t) {
        var e = this;
        return function (n, r, i) {
            var o;
            o = "function" == typeof i ? i : r, e.search(n, t, function (t, e) {
                o(t || e.hits)
            })
        }
    }, "ttAdapter is not necessary anymore and will be removed in the next version,\nhave a look at autocomplete.js (https://github.com/algolia/autocomplete.js)"), u.prototype.waitTask = function (t, e) {
        var n = 100, r = 5e3, i = 0, o = this, s = o.as, c = function e() {
            return s._jsonRequest({
                method: "GET",
                hostType: "read",
                url: "/1/indexes/" + encodeURIComponent(o.indexName) + "/task/" + t
            }).then(function (t) {
                var o = n * ++i * i;
                return o > r && (o = r), "published" !== t.status ? s._promise.delay(o).then(e) : t
            })
        }();
        if (!e) return c;
        c.then(function (t) {
            a(function () {
                e(null, t)
            }, s._setTimeout || setTimeout)
        }, function (t) {
            a(function () {
                e(t)
            }, s._setTimeout || setTimeout)
        })
    }, u.prototype.clearIndex = function (t) {
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/clear",
            hostType: "write",
            callback: t
        })
    }, u.prototype.getSettings = function (t, e) {
        1 === arguments.length && "function" == typeof t && (e = t, t = {}), t = t || {};
        var n = encodeURIComponent(this.indexName);
        return this.as._jsonRequest({
            method: "GET",
            url: "/1/indexes/" + n + "/settings?getVersion=2" + (t.advanced ? "&advanced=" + t.advanced : ""),
            hostType: "read",
            callback: e
        })
    }, u.prototype.searchSynonyms = function (t, e) {
        return "function" == typeof t ? (e = t, t = {}) : void 0 === t && (t = {}), this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/synonyms/search",
            body: t,
            hostType: "read",
            callback: e
        })
    }, u.prototype.exportSynonyms = function (t, e) {
        return h(this.searchSynonyms.bind(this), t, e)
    }, u.prototype.saveSynonym = function (t, e, n) {
        "function" == typeof e ? (n = e, e = {}) : void 0 === e && (e = {}), void 0 !== e.forwardToSlaves && l();
        var r = e.forwardToSlaves || e.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "PUT",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/synonyms/" + encodeURIComponent(t.objectID) + "?forwardToReplicas=" + r,
            body: t,
            hostType: "write",
            callback: n
        })
    }, u.prototype.getSynonym = function (t, e) {
        return this.as._jsonRequest({
            method: "GET",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/synonyms/" + encodeURIComponent(t),
            hostType: "read",
            callback: e
        })
    }, u.prototype.deleteSynonym = function (t, e, n) {
        "function" == typeof e ? (n = e, e = {}) : void 0 === e && (e = {}), void 0 !== e.forwardToSlaves && l();
        var r = e.forwardToSlaves || e.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "DELETE",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/synonyms/" + encodeURIComponent(t) + "?forwardToReplicas=" + r,
            hostType: "write",
            callback: n
        })
    }, u.prototype.clearSynonyms = function (t, e) {
        "function" == typeof t ? (e = t, t = {}) : void 0 === t && (t = {}), void 0 !== t.forwardToSlaves && l();
        var n = t.forwardToSlaves || t.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/synonyms/clear?forwardToReplicas=" + n,
            hostType: "write",
            callback: e
        })
    }, u.prototype.batchSynonyms = function (t, e, n) {
        "function" == typeof e ? (n = e, e = {}) : void 0 === e && (e = {}), void 0 !== e.forwardToSlaves && l();
        var r = e.forwardToSlaves || e.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/synonyms/batch?forwardToReplicas=" + r + "&replaceExistingSynonyms=" + (e.replaceExistingSynonyms ? "true" : "false"),
            hostType: "write",
            body: t,
            callback: n
        })
    }, u.prototype.searchRules = function (t, e) {
        return "function" == typeof t ? (e = t, t = {}) : void 0 === t && (t = {}), this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/rules/search",
            body: t,
            hostType: "read",
            callback: e
        })
    }, u.prototype.exportRules = function (t, e) {
        return h(this.searchRules.bind(this), t, e)
    }, u.prototype.saveRule = function (t, e, n) {
        if ("function" == typeof e ? (n = e, e = {}) : void 0 === e && (e = {}), !t.objectID) throw new c.AlgoliaSearchError("Missing or empty objectID field for rule");
        var r = !0 === e.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "PUT",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/rules/" + encodeURIComponent(t.objectID) + "?forwardToReplicas=" + r,
            body: t,
            hostType: "write",
            callback: n
        })
    }, u.prototype.getRule = function (t, e) {
        return this.as._jsonRequest({
            method: "GET",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/rules/" + encodeURIComponent(t),
            hostType: "read",
            callback: e
        })
    }, u.prototype.deleteRule = function (t, e, n) {
        "function" == typeof e ? (n = e, e = {}) : void 0 === e && (e = {});
        var r = !0 === e.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "DELETE",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/rules/" + encodeURIComponent(t) + "?forwardToReplicas=" + r,
            hostType: "write",
            callback: n
        })
    }, u.prototype.clearRules = function (t, e) {
        "function" == typeof t ? (e = t, t = {}) : void 0 === t && (t = {});
        var n = !0 === t.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/rules/clear?forwardToReplicas=" + n,
            hostType: "write",
            callback: e
        })
    }, u.prototype.batchRules = function (t, e, n) {
        "function" == typeof e ? (n = e, e = {}) : void 0 === e && (e = {});
        var r = !0 === e.forwardToReplicas ? "true" : "false";
        return this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/rules/batch?forwardToReplicas=" + r + "&clearExistingRules=" + (!0 === e.clearExistingRules ? "true" : "false"),
            hostType: "write",
            body: t,
            callback: n
        })
    }, u.prototype.setSettings = function (t, e, n) {
        1 !== arguments.length && "function" != typeof e || (n = e, e = {}), void 0 !== e.forwardToSlaves && l();
        var r = e.forwardToSlaves || e.forwardToReplicas ? "true" : "false", i = this;
        return this.as._jsonRequest({
            method: "PUT",
            url: "/1/indexes/" + encodeURIComponent(i.indexName) + "/settings?forwardToReplicas=" + r,
            hostType: "write",
            body: t,
            callback: n
        })
    }, u.prototype.listUserKeys = o(function (t) {
        return this.listApiKeys(t)
    }, s("index.listUserKeys()", "client.listApiKeys()")), u.prototype.listApiKeys = o(function (t) {
        return this.as._jsonRequest({
            method: "GET",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/keys",
            hostType: "read",
            callback: t
        })
    }, s("index.listApiKeys()", "client.listApiKeys()")), u.prototype.getUserKeyACL = o(function (t, e) {
        return this.getApiKey(t, e)
    }, s("index.getUserKeyACL()", "client.getApiKey()")), u.prototype.getApiKey = o(function (t, e) {
        return this.as._jsonRequest({
            method: "GET",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/keys/" + t,
            hostType: "read",
            callback: e
        })
    }, s("index.getApiKey()", "client.getApiKey()")), u.prototype.deleteUserKey = o(function (t, e) {
        return this.deleteApiKey(t, e)
    }, s("index.deleteUserKey()", "client.deleteApiKey()")), u.prototype.deleteApiKey = o(function (t, e) {
        return this.as._jsonRequest({
            method: "DELETE",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/keys/" + t,
            hostType: "write",
            callback: e
        })
    }, s("index.deleteApiKey()", "client.deleteApiKey()")), u.prototype.addUserKey = o(function (t, e, n) {
        return this.addApiKey(t, e, n)
    }, s("index.addUserKey()", "client.addApiKey()")), u.prototype.addApiKey = o(function (t, e, r) {
        var i = n(1), o = "Usage: index.addApiKey(arrayOfAcls[, params, callback])";
        if (!i(t)) throw new Error(o);
        1 !== arguments.length && "function" != typeof e || (r = e, e = null);
        var s = {acl: t};
        return e && (s.validity = e.validity, s.maxQueriesPerIPPerHour = e.maxQueriesPerIPPerHour, s.maxHitsPerQuery = e.maxHitsPerQuery, s.description = e.description, e.queryParameters && (s.queryParameters = this.as._getSearchParams(e.queryParameters, "")), s.referers = e.referers), this.as._jsonRequest({
            method: "POST",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/keys",
            body: s,
            hostType: "write",
            callback: r
        })
    }, s("index.addApiKey()", "client.addApiKey()")), u.prototype.addUserKeyWithValidity = o(function (t, e, n) {
        return this.addApiKey(t, e, n)
    }, s("index.addUserKeyWithValidity()", "client.addApiKey()")), u.prototype.updateUserKey = o(function (t, e, n, r) {
        return this.updateApiKey(t, e, n, r)
    }, s("index.updateUserKey()", "client.updateApiKey()")), u.prototype.updateApiKey = o(function (t, e, r, i) {
        var o = n(1), s = "Usage: index.updateApiKey(key, arrayOfAcls[, params, callback])";
        if (!o(e)) throw new Error(s);
        2 !== arguments.length && "function" != typeof r || (i = r, r = null);
        var a = {acl: e};
        return r && (a.validity = r.validity, a.maxQueriesPerIPPerHour = r.maxQueriesPerIPPerHour, a.maxHitsPerQuery = r.maxHitsPerQuery, a.description = r.description, r.queryParameters && (a.queryParameters = this.as._getSearchParams(r.queryParameters, "")), a.referers = r.referers), this.as._jsonRequest({
            method: "PUT",
            url: "/1/indexes/" + encodeURIComponent(this.indexName) + "/keys/" + t,
            body: a,
            hostType: "write",
            callback: i
        })
    }, s("index.updateApiKey()", "client.updateApiKey()"))
}, function (t, e, n) {
    "use strict";
    var r = Array.prototype.slice, i = n(18), o = Object.keys, s = o ? function (t) {
        return o(t)
    } : n(29), a = Object.keys;
    s.shim = function () {
        Object.keys ? function () {
            var t = Object.keys(arguments);
            return t && t.length === arguments.length
        }(1, 2) || (Object.keys = function (t) {
            return i(t) ? a(r.call(t)) : a(t)
        }) : Object.keys = s;
        return Object.keys || s
    }, t.exports = s
}, function (t, e, n) {
    "use strict";
    var r;
    if (!Object.keys) {
        var i = Object.prototype.hasOwnProperty, o = Object.prototype.toString, s = n(18),
            a = Object.prototype.propertyIsEnumerable, c = !a.call({toString: null}, "toString"),
            l = a.call(function () {
            }, "prototype"),
            u = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
            h = function (t) {
                var e = t.constructor;
                return e && e.prototype === t
            }, f = {
                $applicationCache: !0,
                $console: !0,
                $external: !0,
                $frame: !0,
                $frameElement: !0,
                $frames: !0,
                $innerHeight: !0,
                $innerWidth: !0,
                $onmozfullscreenchange: !0,
                $onmozfullscreenerror: !0,
                $outerHeight: !0,
                $outerWidth: !0,
                $pageXOffset: !0,
                $pageYOffset: !0,
                $parent: !0,
                $scrollLeft: !0,
                $scrollTop: !0,
                $scrollX: !0,
                $scrollY: !0,
                $self: !0,
                $webkitIndexedDB: !0,
                $webkitStorageInfo: !0,
                $window: !0
            }, p = function () {
                if ("undefined" == typeof window) return !1;
                for (var t in window) try {
                    if (!f["$" + t] && i.call(window, t) && null !== window[t] && "object" == typeof window[t]) try {
                        h(window[t])
                    } catch (t) {
                        return !0
                    }
                } catch (t) {
                    return !0
                }
                return !1
            }();
        r = function (t) {
            var e = null !== t && "object" == typeof t, n = "[object Function]" === o.call(t), r = s(t),
                a = e && "[object String]" === o.call(t), f = [];
            if (!e && !n && !r) throw new TypeError("Object.keys called on a non-object");
            var d = l && n;
            if (a && t.length > 0 && !i.call(t, 0)) for (var y = 0; y < t.length; ++y) f.push(String(y));
            if (r && t.length > 0) for (var m = 0; m < t.length; ++m) f.push(String(m)); else for (var v in t) d && "prototype" === v || !i.call(t, v) || f.push(String(v));
            if (c) for (var g = function (t) {
                if ("undefined" == typeof window || !p) return h(t);
                try {
                    return h(t)
                } catch (t) {
                    return !1
                }
            }(t), x = 0; x < u.length; ++x) g && "constructor" === u[x] || !i.call(t, u[x]) || f.push(u[x]);
            return f
        }
    }
    t.exports = r
}, function (t, e, n) {
    "use strict";

    function r() {
    }

    t.exports = r, n(6)(r, n(31).EventEmitter), r.prototype.stop = function () {
        this._stopped = !0, this._clean()
    }, r.prototype._end = function () {
        this.emit("end"), this._clean()
    }, r.prototype._error = function (t) {
        this.emit("error", t), this._clean()
    }, r.prototype._result = function (t) {
        this.emit("result", t)
    }, r.prototype._clean = function () {
        this.removeAllListeners("stop"), this.removeAllListeners("end"), this.removeAllListeners("error"), this.removeAllListeners("result")
    }
}, function (t, e, n) {
    "use strict";
    var r, i = "object" == typeof Reflect ? Reflect : null,
        o = i && "function" == typeof i.apply ? i.apply : function (t, e, n) {
            return Function.prototype.apply.call(t, e, n)
        };
    r = i && "function" == typeof i.ownKeys ? i.ownKeys : Object.getOwnPropertySymbols ? function (t) {
        return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))
    } : function (t) {
        return Object.getOwnPropertyNames(t)
    };
    var s = Number.isNaN || function (t) {
        return t != t
    };

    function a() {
        a.init.call(this)
    }

    t.exports = a, a.EventEmitter = a, a.prototype._events = void 0, a.prototype._eventsCount = 0, a.prototype._maxListeners = void 0;
    var c = 10;

    function l(t) {
        return void 0 === t._maxListeners ? a.defaultMaxListeners : t._maxListeners
    }

    function u(t, e, n, r) {
        var i, o, s, a;
        if ("function" != typeof n) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof n);
        if (void 0 === (o = t._events) ? (o = t._events = Object.create(null), t._eventsCount = 0) : (void 0 !== o.newListener && (t.emit("newListener", e, n.listener ? n.listener : n), o = t._events), s = o[e]), void 0 === s) s = o[e] = n, ++t._eventsCount; else if ("function" == typeof s ? s = o[e] = r ? [n, s] : [s, n] : r ? s.unshift(n) : s.push(n), (i = l(t)) > 0 && s.length > i && !s.warned) {
            s.warned = !0;
            var c = new Error("Possible EventEmitter memory leak detected. " + s.length + " " + String(e) + " listeners added. Use emitter.setMaxListeners() to increase limit");
            c.name = "MaxListenersExceededWarning", c.emitter = t, c.type = e, c.count = s.length, a = c, console && console.warn && console.warn(a)
        }
        return t
    }

    function h(t, e, n) {
        var r = {fired: !1, wrapFn: void 0, target: t, type: e, listener: n}, i = function () {
            for (var t = [], e = 0; e < arguments.length; e++) t.push(arguments[e]);
            this.fired || (this.target.removeListener(this.type, this.wrapFn), this.fired = !0, o(this.listener, this.target, t))
        }.bind(r);
        return i.listener = n, r.wrapFn = i, i
    }

    function f(t, e, n) {
        var r = t._events;
        if (void 0 === r) return [];
        var i = r[e];
        return void 0 === i ? [] : "function" == typeof i ? n ? [i.listener || i] : [i] : n ? function (t) {
            for (var e = new Array(t.length), n = 0; n < e.length; ++n) e[n] = t[n].listener || t[n];
            return e
        }(i) : d(i, i.length)
    }

    function p(t) {
        var e = this._events;
        if (void 0 !== e) {
            var n = e[t];
            if ("function" == typeof n) return 1;
            if (void 0 !== n) return n.length
        }
        return 0
    }

    function d(t, e) {
        for (var n = new Array(e), r = 0; r < e; ++r) n[r] = t[r];
        return n
    }

    Object.defineProperty(a, "defaultMaxListeners", {
        enumerable: !0, get: function () {
            return c
        }, set: function (t) {
            if ("number" != typeof t || t < 0 || s(t)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + t + ".");
            c = t
        }
    }), a.init = function () {
        void 0 !== this._events && this._events !== Object.getPrototypeOf(this)._events || (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
    }, a.prototype.setMaxListeners = function (t) {
        if ("number" != typeof t || t < 0 || s(t)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + t + ".");
        return this._maxListeners = t, this
    }, a.prototype.getMaxListeners = function () {
        return l(this)
    }, a.prototype.emit = function (t) {
        for (var e = [], n = 1; n < arguments.length; n++) e.push(arguments[n]);
        var r = "error" === t, i = this._events;
        if (void 0 !== i) r = r && void 0 === i.error; else if (!r) return !1;
        if (r) {
            var s;
            if (e.length > 0 && (s = e[0]), s instanceof Error) throw s;
            var a = new Error("Unhandled error." + (s ? " (" + s.message + ")" : ""));
            throw a.context = s, a
        }
        var c = i[t];
        if (void 0 === c) return !1;
        if ("function" == typeof c) o(c, this, e); else {
            var l = c.length, u = d(c, l);
            for (n = 0; n < l; ++n) o(u[n], this, e)
        }
        return !0
    }, a.prototype.addListener = function (t, e) {
        return u(this, t, e, !1)
    }, a.prototype.on = a.prototype.addListener, a.prototype.prependListener = function (t, e) {
        return u(this, t, e, !0)
    }, a.prototype.once = function (t, e) {
        if ("function" != typeof e) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e);
        return this.on(t, h(this, t, e)), this
    }, a.prototype.prependOnceListener = function (t, e) {
        if ("function" != typeof e) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e);
        return this.prependListener(t, h(this, t, e)), this
    }, a.prototype.removeListener = function (t, e) {
        var n, r, i, o, s;
        if ("function" != typeof e) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e);
        if (void 0 === (r = this._events)) return this;
        if (void 0 === (n = r[t])) return this;
        if (n === e || n.listener === e) 0 == --this._eventsCount ? this._events = Object.create(null) : (delete r[t], r.removeListener && this.emit("removeListener", t, n.listener || e)); else if ("function" != typeof n) {
            for (i = -1, o = n.length - 1; o >= 0; o--) if (n[o] === e || n[o].listener === e) {
                s = n[o].listener, i = o;
                break
            }
            if (i < 0) return this;
            0 === i ? n.shift() : function (t, e) {
                for (; e + 1 < t.length; e++) t[e] = t[e + 1];
                t.pop()
            }(n, i), 1 === n.length && (r[t] = n[0]), void 0 !== r.removeListener && this.emit("removeListener", t, s || e)
        }
        return this
    }, a.prototype.off = a.prototype.removeListener, a.prototype.removeAllListeners = function (t) {
        var e, n, r;
        if (void 0 === (n = this._events)) return this;
        if (void 0 === n.removeListener) return 0 === arguments.length ? (this._events = Object.create(null), this._eventsCount = 0) : void 0 !== n[t] && (0 == --this._eventsCount ? this._events = Object.create(null) : delete n[t]), this;
        if (0 === arguments.length) {
            var i, o = Object.keys(n);
            for (r = 0; r < o.length; ++r) "removeListener" !== (i = o[r]) && this.removeAllListeners(i);
            return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
        }
        if ("function" == typeof (e = n[t])) this.removeListener(t, e); else if (void 0 !== e) for (r = e.length - 1; r >= 0; r--) this.removeListener(t, e[r]);
        return this
    }, a.prototype.listeners = function (t) {
        return f(this, t, !0)
    }, a.prototype.rawListeners = function (t) {
        return f(this, t, !1)
    }, a.listenerCount = function (t, e) {
        return "function" == typeof t.listenerCount ? t.listenerCount(e) : p.call(t, e)
    }, a.prototype.listenerCount = p, a.prototype.eventNames = function () {
        return this._eventsCount > 0 ? r(this._events) : []
    }
}, function (t, e, n) {
    (function (e) {
        t.exports = c;
        var r = n(3), i = n(19), o = n(14), s = n(33),
            a = e.env.RESET_APP_DATA_TIMER && parseInt(e.env.RESET_APP_DATA_TIMER, 10) || 12e4;

        function c(t, e, i) {
            var o = n(9)("algoliasearch"), s = n(2), a = n(1), c = n(5),
                u = "Usage: algoliasearch(applicationID, apiKey, opts)";
            if (!0 !== i._allowEmptyCredentials && !t) throw new r.AlgoliaSearchError("Please provide an application ID. " + u);
            if (!0 !== i._allowEmptyCredentials && !e) throw new r.AlgoliaSearchError("Please provide an API key. " + u);
            this.applicationID = t, this.apiKey = e, this.hosts = {
                read: [],
                write: []
            }, i = i || {}, this._timeouts = i.timeouts || {
                connect: 1e3,
                read: 2e3,
                write: 3e4
            }, i.timeout && (this._timeouts.connect = this._timeouts.read = this._timeouts.write = i.timeout);
            var h = i.protocol || "https:";
            if (/:$/.test(h) || (h += ":"), "http:" !== h && "https:" !== h) throw new r.AlgoliaSearchError("protocol must be `http:` or `https:` (was `" + i.protocol + "`)");
            if (this._checkAppIdData(), i.hosts) a(i.hosts) ? (this.hosts.read = s(i.hosts), this.hosts.write = s(i.hosts)) : (this.hosts.read = s(i.hosts.read), this.hosts.write = s(i.hosts.write)); else {
                var f = c(this._shuffleResult, function (e) {
                    return t + "-" + e + ".algolianet.com"
                }), p = (!1 === i.dsn ? "" : "-dsn") + ".algolia.net";
                this.hosts.read = [this.applicationID + p].concat(f), this.hosts.write = [this.applicationID + ".algolia.net"].concat(f)
            }
            this.hosts.read = c(this.hosts.read, l(h)), this.hosts.write = c(this.hosts.write, l(h)), this.extraHeaders = {}, this.cache = i._cache || {}, this._ua = i._ua, this._useCache = !(void 0 !== i._useCache && !i._cache) || i._useCache, this._useRequestCache = this._useCache && i._useRequestCache, this._useFallback = void 0 === i.useFallback || i.useFallback, this._setTimeout = i._setTimeout, o("init done, %j", this)
        }

        function l(t) {
            return function (e) {
                return t + "//" + e.toLowerCase()
            }
        }

        function u(t) {
            if (void 0 === Array.prototype.toJSON) return JSON.stringify(t);
            var e = Array.prototype.toJSON;
            delete Array.prototype.toJSON;
            var n = JSON.stringify(t);
            return Array.prototype.toJSON = e, n
        }

        function h(t) {
            var e = {};
            for (var n in t) {
                var r;
                if (Object.prototype.hasOwnProperty.call(t, n)) r = "x-algolia-api-key" === n || "x-algolia-application-id" === n ? "**hidden for security purposes**" : t[n], e[n] = r
            }
            return e
        }

        c.prototype.initIndex = function (t) {
            return new o(this, t)
        }, c.prototype.setExtraHeader = function (t, e) {
            this.extraHeaders[t.toLowerCase()] = e
        }, c.prototype.getExtraHeader = function (t) {
            return this.extraHeaders[t.toLowerCase()]
        }, c.prototype.unsetExtraHeader = function (t) {
            delete this.extraHeaders[t.toLowerCase()]
        }, c.prototype.addAlgoliaAgent = function (t) {
            var e = "; " + t;
            -1 === this._ua.indexOf(e) && (this._ua += e)
        }, c.prototype._jsonRequest = function (t) {
            this._checkAppIdData();
            var e, o, s, a = n(9)("algoliasearch:" + t.url), c = t.additionalUA || "", l = t.cache, f = this, p = 0,
                d = !1, y = f._useFallback && f._request.fallback && t.fallback;
            this.apiKey.length > 500 && void 0 !== t.body && (void 0 !== t.body.params || void 0 !== t.body.requests) ? (t.body.apiKey = this.apiKey, s = this._computeRequestHeaders({
                additionalUA: c,
                withApiKey: !1,
                headers: t.headers
            })) : s = this._computeRequestHeaders({
                additionalUA: c,
                headers: t.headers
            }), void 0 !== t.body && (e = u(t.body)), a("request start");
            var m = [];

            function v(t, e, n) {
                return f._useCache && t && e && void 0 !== e[n]
            }

            function g(e, n) {
                if (v(f._useRequestCache, l, o) && e.catch(function () {
                    delete l[o]
                }), "function" != typeof t.callback) return e.then(n);
                e.then(function (e) {
                    i(function () {
                        t.callback(null, n(e))
                    }, f._setTimeout || setTimeout)
                }, function (e) {
                    i(function () {
                        t.callback(e)
                    }, f._setTimeout || setTimeout)
                })
            }

            if (f._useCache && f._useRequestCache && (o = t.url), f._useCache && f._useRequestCache && e && (o += "_body_" + e), v(f._useRequestCache, l, o)) {
                a("serving request from cache");
                var x = l[o];
                return g("function" != typeof x.then ? f._promise.resolve({responseText: x}) : x, function (t) {
                    return JSON.parse(t.responseText)
                })
            }
            var b = function n(i, g) {
                f._checkAppIdData();
                var x = new Date;
                if (f._useCache && !f._useRequestCache && (o = t.url), f._useCache && !f._useRequestCache && e && (o += "_body_" + g.body), v(!f._useRequestCache, l, o)) {
                    a("serving response from cache");
                    var b = l[o];
                    return f._promise.resolve({body: JSON.parse(b), responseText: b})
                }
                if (p >= f.hosts[t.hostType].length) return !y || d ? (a("could not get any response"), f._promise.reject(new r.AlgoliaSearchError("Cannot connect to the AlgoliaSearch API. Send an email to support@algolia.com to report and resolve the issue. Application id was: " + f.applicationID, {debugData: m}))) : (a("switching to fallback"), p = 0, g.method = t.fallback.method, g.url = t.fallback.url, g.jsonBody = t.fallback.body, g.jsonBody && (g.body = u(g.jsonBody)), s = f._computeRequestHeaders({
                    additionalUA: c,
                    headers: t.headers
                }), g.timeouts = f._getTimeoutsForRequest(t.hostType), f._setHostIndexByType(0, t.hostType), d = !0, n(f._request.fallback, g));
                var w = f._getHostByType(t.hostType), A = w + g.url, q = {
                    body: g.body,
                    jsonBody: g.jsonBody,
                    method: g.method,
                    headers: s,
                    timeouts: g.timeouts,
                    debug: a,
                    forceAuthHeaders: g.forceAuthHeaders
                };
                return a("method: %s, url: %s, headers: %j, timeouts: %d", q.method, A, q.headers, q.timeouts), i === f._request.fallback && a("using fallback"), i.call(f, A, q).then(function (t) {
                    var n = t && t.body && t.body.message && t.body.status || t.statusCode || t && t.body && 200;
                    a("received response: statusCode: %s, computed statusCode: %d, headers: %j", t.statusCode, n, t.headers);
                    var i = 2 === Math.floor(n / 100), c = new Date;
                    if (m.push({
                        currentHost: w,
                        headers: h(s),
                        content: e || null,
                        contentLength: void 0 !== e ? e.length : null,
                        method: g.method,
                        timeouts: g.timeouts,
                        url: g.url,
                        startTime: x,
                        endTime: c,
                        duration: c - x,
                        statusCode: n
                    }), i) return f._useCache && !f._useRequestCache && l && (l[o] = t.responseText), {
                        responseText: t.responseText,
                        body: t.body
                    };
                    if (4 !== Math.floor(n / 100)) return p += 1, L();
                    a("unrecoverable error");
                    var u = new r.AlgoliaSearchError(t.body && t.body.message, {debugData: m, statusCode: n});
                    return f._promise.reject(u)
                }, function (o) {
                    a("error: %s, stack: %s", o.message, o.stack);
                    var c = new Date;
                    return m.push({
                        currentHost: w,
                        headers: h(s),
                        content: e || null,
                        contentLength: void 0 !== e ? e.length : null,
                        method: g.method,
                        timeouts: g.timeouts,
                        url: g.url,
                        startTime: x,
                        endTime: c,
                        duration: c - x
                    }), o instanceof r.AlgoliaSearchError || (o = new r.Unknown(o && o.message, o)), p += 1, o instanceof r.Unknown || o instanceof r.UnparsableJSON || p >= f.hosts[t.hostType].length && (d || !y) ? (o.debugData = m, f._promise.reject(o)) : o instanceof r.RequestTimeout ? (a("retrying request with higher timeout"), f._incrementHostIndex(t.hostType), f._incrementTimeoutMultipler(), g.timeouts = f._getTimeoutsForRequest(t.hostType), n(i, g)) : L()
                });

                function L() {
                    return a("retrying request"), f._incrementHostIndex(t.hostType), n(i, g)
                }
            }(f._request, {
                url: t.url,
                method: t.method,
                body: e,
                jsonBody: t.body,
                timeouts: f._getTimeoutsForRequest(t.hostType),
                forceAuthHeaders: t.forceAuthHeaders
            });
            return f._useCache && f._useRequestCache && l && (l[o] = b), g(b, function (t) {
                return t.body
            })
        }, c.prototype._getSearchParams = function (t, e) {
            if (null == t) return e;
            for (var n in t) null !== n && void 0 !== t[n] && t.hasOwnProperty(n) && (e += "" === e ? "" : "&", e += n + "=" + encodeURIComponent("[object Array]" === Object.prototype.toString.call(t[n]) ? u(t[n]) : t[n]));
            return e
        }, c.prototype._computeRequestHeaders = function (t) {
            var e = n(4), r = {
                "x-algolia-agent": t.additionalUA ? this._ua + "; " + t.additionalUA : this._ua,
                "x-algolia-application-id": this.applicationID
            };
            return !1 !== t.withApiKey && (r["x-algolia-api-key"] = this.apiKey), this.userToken && (r["x-algolia-usertoken"] = this.userToken), this.securityTags && (r["x-algolia-tagfilters"] = this.securityTags), e(this.extraHeaders, function (t, e) {
                r[e] = t
            }), t.headers && e(t.headers, function (t, e) {
                r[e] = t
            }), r
        }, c.prototype.search = function (t, e, r) {
            var i = n(1), o = n(5);
            if (!i(t)) throw new Error("Usage: client.search(arrayOfQueries[, callback])");
            "function" == typeof e ? (r = e, e = {}) : void 0 === e && (e = {});
            var s = this, a = {
                requests: o(t, function (t) {
                    var e = "";
                    return void 0 !== t.query && (e += "query=" + encodeURIComponent(t.query)), {
                        indexName: t.indexName,
                        params: s._getSearchParams(t.params, e)
                    }
                })
            }, c = o(a.requests, function (t, e) {
                return e + "=" + encodeURIComponent("/1/indexes/" + encodeURIComponent(t.indexName) + "?" + t.params)
            }).join("&");
            return void 0 !== e.strategy && (a.strategy = e.strategy), this._jsonRequest({
                cache: this.cache,
                method: "POST",
                url: "/1/indexes/*/queries",
                body: a,
                hostType: "read",
                fallback: {method: "GET", url: "/1/indexes/*", body: {params: c}},
                callback: r
            })
        }, c.prototype.searchForFacetValues = function (t) {
            var e = n(1), r = n(5),
                i = "Usage: client.searchForFacetValues([{indexName, params: {facetName, facetQuery, ...params}}, ...queries])";
            if (!e(t)) throw new Error(i);
            var o = this;
            return o._promise.all(r(t, function (t) {
                if (!t || void 0 === t.indexName || void 0 === t.params.facetName || void 0 === t.params.facetQuery) throw new Error(i);
                var e = n(2), r = n(17), s = t.indexName, a = t.params, c = a.facetName, l = r(e(a), function (t) {
                    return "facetName" === t
                }), u = o._getSearchParams(l, "");
                return o._jsonRequest({
                    cache: o.cache,
                    method: "POST",
                    url: "/1/indexes/" + encodeURIComponent(s) + "/facets/" + encodeURIComponent(c) + "/query",
                    hostType: "read",
                    body: {params: u}
                })
            }))
        }, c.prototype.setSecurityTags = function (t) {
            if ("[object Array]" === Object.prototype.toString.call(t)) {
                for (var e = [], n = 0; n < t.length; ++n) if ("[object Array]" === Object.prototype.toString.call(t[n])) {
                    for (var r = [], i = 0; i < t[n].length; ++i) r.push(t[n][i]);
                    e.push("(" + r.join(",") + ")")
                } else e.push(t[n]);
                t = e.join(",")
            }
            this.securityTags = t
        }, c.prototype.setUserToken = function (t) {
            this.userToken = t
        }, c.prototype.clearCache = function () {
            this.cache = {}
        }, c.prototype.setRequestTimeout = function (t) {
            t && (this._timeouts.connect = this._timeouts.read = this._timeouts.write = t)
        }, c.prototype.setTimeouts = function (t) {
            this._timeouts = t
        }, c.prototype.getTimeouts = function () {
            return this._timeouts
        }, c.prototype._getAppIdData = function () {
            var t = s.get(this.applicationID);
            return null !== t && this._cacheAppIdData(t), t
        }, c.prototype._setAppIdData = function (t) {
            return t.lastChange = (new Date).getTime(), this._cacheAppIdData(t), s.set(this.applicationID, t)
        }, c.prototype._checkAppIdData = function () {
            var t = this._getAppIdData(), e = (new Date).getTime();
            return null === t || e - t.lastChange > a ? this._resetInitialAppIdData(t) : t
        }, c.prototype._resetInitialAppIdData = function (t) {
            var e = t || {};
            return e.hostIndexes = {
                read: 0,
                write: 0
            }, e.timeoutMultiplier = 1, e.shuffleResult = e.shuffleResult || function (t) {
                var e, n, r = t.length;
                for (; 0 !== r;) n = Math.floor(Math.random() * r), e = t[r -= 1], t[r] = t[n], t[n] = e;
                return t
            }([1, 2, 3]), this._setAppIdData(e)
        }, c.prototype._cacheAppIdData = function (t) {
            this._hostIndexes = t.hostIndexes, this._timeoutMultiplier = t.timeoutMultiplier, this._shuffleResult = t.shuffleResult
        }, c.prototype._partialAppIdDataUpdate = function (t) {
            var e = n(4), r = this._getAppIdData();
            return e(t, function (t, e) {
                r[e] = t
            }), this._setAppIdData(r)
        }, c.prototype._getHostByType = function (t) {
            return this.hosts[t][this._getHostIndexByType(t)]
        }, c.prototype._getTimeoutMultiplier = function () {
            return this._timeoutMultiplier
        }, c.prototype._getHostIndexByType = function (t) {
            return this._hostIndexes[t]
        }, c.prototype._setHostIndexByType = function (t, e) {
            var r = n(2)(this._hostIndexes);
            return r[e] = t, this._partialAppIdDataUpdate({hostIndexes: r}), t
        }, c.prototype._incrementHostIndex = function (t) {
            return this._setHostIndexByType((this._getHostIndexByType(t) + 1) % this.hosts[t].length, t)
        }, c.prototype._incrementTimeoutMultipler = function () {
            var t = Math.max(this._timeoutMultiplier + 1, 4);
            return this._partialAppIdDataUpdate({timeoutMultiplier: t})
        }, c.prototype._getTimeoutsForRequest = function (t) {
            return {
                connect: this._timeouts.connect * this._timeoutMultiplier,
                complete: this._timeouts[t] * this._timeoutMultiplier
            }
        }
    }).call(this, n(12))
}, function (t, e, n) {
    (function (e) {
        var r, i = n(9)("algoliasearch:src/hostIndexState.js"), o = "algoliasearch-client-js", s = {
            state: {}, set: function (t, e) {
                return this.state[t] = e, this.state[t]
            }, get: function (t) {
                return this.state[t] || null
            }
        }, a = {
            set: function (t, n) {
                s.set(t, n);
                try {
                    var r = JSON.parse(e.localStorage[o]);
                    return r[t] = n, e.localStorage[o] = JSON.stringify(r), r[t]
                } catch (e) {
                    return c(t, e)
                }
            }, get: function (t) {
                try {
                    return JSON.parse(e.localStorage[o])[t] || null
                } catch (e) {
                    return c(t, e)
                }
            }
        };

        function c(t, n) {
            return i("localStorage failed with", n), function () {
                try {
                    e.localStorage.removeItem(o)
                } catch (t) {
                }
            }(), (r = s).get(t)
        }

        function l(t, e) {
            return 1 === arguments.length ? r.get(t) : r.set(t, e)
        }

        function u() {
            try {
                return "localStorage" in e && null !== e.localStorage && (e.localStorage[o] || e.localStorage.setItem(o, JSON.stringify({})), !0)
            } catch (t) {
                return !1
            }
        }

        r = u() ? a : s, t.exports = {get: l, set: l, supportsLocalStorage: u}
    }).call(this, n(8))
}, function (t, e, n) {
    var r;

    function i(t) {
        function n() {
            if (n.enabled) {
                var t = n, i = +new Date, o = i - (r || i);
                t.diff = o, t.prev = r, t.curr = i, r = i;
                for (var s = new Array(arguments.length), a = 0; a < s.length; a++) s[a] = arguments[a];
                s[0] = e.coerce(s[0]), "string" != typeof s[0] && s.unshift("%O");
                var c = 0;
                s[0] = s[0].replace(/%([a-zA-Z%])/g, function (n, r) {
                    if ("%%" === n) return n;
                    c++;
                    var i = e.formatters[r];
                    if ("function" == typeof i) {
                        var o = s[c];
                        n = i.call(t, o), s.splice(c, 1), c--
                    }
                    return n
                }), e.formatArgs.call(t, s), (n.log || e.log || console.log.bind(console)).apply(t, s)
            }
        }

        return n.namespace = t, n.enabled = e.enabled(t), n.useColors = e.useColors(), n.color = function (t) {
            var n, r = 0;
            for (n in t) r = (r << 5) - r + t.charCodeAt(n), r |= 0;
            return e.colors[Math.abs(r) % e.colors.length]
        }(t), "function" == typeof e.init && e.init(n), n
    }

    (e = t.exports = i.debug = i.default = i).coerce = function (t) {
        return t instanceof Error ? t.stack || t.message : t
    }, e.disable = function () {
        e.enable("")
    }, e.enable = function (t) {
        e.save(t), e.names = [], e.skips = [];
        for (var n = ("string" == typeof t ? t : "").split(/[\s,]+/), r = n.length, i = 0; i < r; i++) n[i] && ("-" === (t = n[i].replace(/\*/g, ".*?"))[0] ? e.skips.push(new RegExp("^" + t.substr(1) + "$")) : e.names.push(new RegExp("^" + t + "$")))
    }, e.enabled = function (t) {
        var n, r;
        for (n = 0, r = e.skips.length; n < r; n++) if (e.skips[n].test(t)) return !1;
        for (n = 0, r = e.names.length; n < r; n++) if (e.names[n].test(t)) return !0;
        return !1
    }, e.humanize = n(35), e.names = [], e.skips = [], e.formatters = {}
}, function (t, e) {
    var n = 1e3, r = 60 * n, i = 60 * r, o = 24 * i, s = 365.25 * o;

    function a(t, e, n) {
        if (!(t < e)) return t < 1.5 * e ? Math.floor(t / e) + " " + n : Math.ceil(t / e) + " " + n + "s"
    }

    t.exports = function (t, e) {
        e = e || {};
        var c, l = typeof t;
        if ("string" === l && t.length > 0) return function (t) {
            if ((t = String(t)).length > 100) return;
            var e = /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(t);
            if (!e) return;
            var a = parseFloat(e[1]);
            switch ((e[2] || "ms").toLowerCase()) {
                case"years":
                case"year":
                case"yrs":
                case"yr":
                case"y":
                    return a * s;
                case"days":
                case"day":
                case"d":
                    return a * o;
                case"hours":
                case"hour":
                case"hrs":
                case"hr":
                case"h":
                    return a * i;
                case"minutes":
                case"minute":
                case"mins":
                case"min":
                case"m":
                    return a * r;
                case"seconds":
                case"second":
                case"secs":
                case"sec":
                case"s":
                    return a * n;
                case"milliseconds":
                case"millisecond":
                case"msecs":
                case"msec":
                case"ms":
                    return a;
                default:
                    return
            }
        }(t);
        if ("number" === l && !1 === isNaN(t)) return e.long ? a(c = t, o, "day") || a(c, i, "hour") || a(c, r, "minute") || a(c, n, "second") || c + " ms" : function (t) {
            if (t >= o) return Math.round(t / o) + "d";
            if (t >= i) return Math.round(t / i) + "h";
            if (t >= r) return Math.round(t / r) + "m";
            if (t >= n) return Math.round(t / n) + "s";
            return t + "ms"
        }(t);
        throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(t))
    }
}, function (t, e, n) {
    t.exports = function (t, e, n) {
        var i = {};
        return (n = n || {}).hosts = n.hosts || ["analytics.algolia.com", "analytics.algolia.com", "analytics.algolia.com", "analytics.algolia.com"], n.protocol = n.protocol || "https:", i.as = r(t, e, n), i.getABTests = function (t, e) {
            var n = n || {}, r = n.offset || 0, i = n.limit || 10;
            return this.as._jsonRequest({
                method: "GET",
                url: "/2/abtests?offset=" + encodeURIComponent(r) + "&limit=" + encodeURIComponent(i),
                hostType: "read",
                forceAuthHeaders: !0,
                callback: e
            })
        }, i.getABTest = function (t, e) {
            return this.as._jsonRequest({
                method: "GET",
                url: "/2/abtests/" + encodeURIComponent(t),
                hostType: "read",
                forceAuthHeaders: !0,
                callback: e
            })
        }, i.addABTest = function (t, e) {
            return this.as._jsonRequest({
                method: "POST",
                url: "/2/abtests",
                body: t,
                hostType: "read",
                forceAuthHeaders: !0,
                callback: e
            })
        }, i.stopABTest = function (t, e) {
            return this.as._jsonRequest({
                method: "POST",
                url: "/2/abtests/" + encodeURIComponent(t) + "/stop",
                hostType: "read",
                forceAuthHeaders: !0,
                callback: e
            })
        }, i.deleteABTest = function (t, e) {
            return this.as._jsonRequest({
                method: "DELETE",
                url: "/2/abtests/" + encodeURIComponent(t),
                hostType: "write",
                forceAuthHeaders: !0,
                callback: e
            })
        }, i.waitTask = function (t, e, n) {
            return this.as.initIndex(t).waitTask(e, n)
        }, i
    };
    var r = n(13)
}, function (t, e, n) {
    "use strict";
    var r = n(38), i = r.Promise || n(39).Promise;
    t.exports = function (t, e) {
        var o = n(6), s = n(3), a = n(40), c = n(41), l = n(42);

        function u(t, e, r) {
            return (r = n(2)(r || {}))._ua = r._ua || u.ua, new f(t, e, r)
        }

        e = e || "", u.version = n(45), u.ua = "Algolia for JavaScript (" + u.version + "); " + e, u.initPlaces = l(u), r.__algolia = {
            debug: n(9),
            algoliasearch: u
        };
        var h = {hasXMLHttpRequest: "XMLHttpRequest" in r, hasXDomainRequest: "XDomainRequest" in r};

        function f() {
            t.apply(this, arguments)
        }

        return h.hasXMLHttpRequest && (h.cors = "withCredentials" in new XMLHttpRequest), o(f, t), f.prototype._request = function (t, e) {
            return new i(function (n, r) {
                if (h.cors || h.hasXDomainRequest) {
                    t = a(t, e.headers);
                    var i, o, c = e.body, l = h.cors ? new XMLHttpRequest : new XDomainRequest, u = !1;
                    i = setTimeout(f, e.timeouts.connect), l.onprogress = function () {
                        u || p()
                    }, "onreadystatechange" in l && (l.onreadystatechange = function () {
                        !u && l.readyState > 1 && p()
                    }), l.onload = function () {
                        if (o) return;
                        var t;
                        clearTimeout(i);
                        try {
                            t = {
                                body: JSON.parse(l.responseText),
                                responseText: l.responseText,
                                statusCode: l.status,
                                headers: l.getAllResponseHeaders && l.getAllResponseHeaders() || {}
                            }
                        } catch (e) {
                            t = new s.UnparsableJSON({more: l.responseText})
                        }
                        t instanceof s.UnparsableJSON ? r(t) : n(t)
                    }, l.onerror = function (t) {
                        if (o) return;
                        clearTimeout(i), r(new s.Network({more: t}))
                    }, l instanceof XMLHttpRequest ? (l.open(e.method, t, !0), e.forceAuthHeaders && (l.setRequestHeader("x-algolia-application-id", e.headers["x-algolia-application-id"]), l.setRequestHeader("x-algolia-api-key", e.headers["x-algolia-api-key"]))) : l.open(e.method, t), h.cors && (c && ("POST" === e.method ? l.setRequestHeader("content-type", "application/x-www-form-urlencoded") : l.setRequestHeader("content-type", "application/json")), l.setRequestHeader("accept", "application/json")), c ? l.send(c) : l.send()
                } else r(new s.Network("CORS not supported"));

                function f() {
                    o = !0, l.abort(), r(new s.RequestTimeout)
                }

                function p() {
                    u = !0, clearTimeout(i), i = setTimeout(f, e.timeouts.complete)
                }
            })
        }, f.prototype._request.fallback = function (t, e) {
            return t = a(t, e.headers), new i(function (n, r) {
                c(t, e, function (t, e) {
                    t ? r(t) : n(e)
                })
            })
        }, f.prototype._promise = {
            reject: function (t) {
                return i.reject(t)
            }, resolve: function (t) {
                return i.resolve(t)
            }, delay: function (t) {
                return new i(function (e) {
                    setTimeout(e, t)
                })
            }, all: function (t) {
                return i.all(t)
            }
        }, u
    }
}, function (t, e, n) {
    (function (e) {
        var n;
        n = "undefined" != typeof window ? window : void 0 !== e ? e : "undefined" != typeof self ? self : {}, t.exports = n
    }).call(this, n(8))
}, function (t, e, n) {
    (function (e, n) {
        /*!
 * @overview es6-promise - a tiny implementation of Promises/A+.
 * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
 * @license   Licensed under MIT license
 *            See https://raw.githubusercontent.com/stefanpenner/es6-promise/master/LICENSE
 * @version   v4.2.8+1e68dce6
 */
        var r;
        r = function () {
            "use strict";

            function t(t) {
                return "function" == typeof t
            }

            var r = Array.isArray ? Array.isArray : function (t) {
                    return "[object Array]" === Object.prototype.toString.call(t)
                }, i = 0, o = void 0, s = void 0, a = function (t, e) {
                    d[i] = t, d[i + 1] = e, 2 === (i += 2) && (s ? s(y) : b())
                }, c = "undefined" != typeof window ? window : void 0, l = c || {},
                u = l.MutationObserver || l.WebKitMutationObserver,
                h = "undefined" == typeof self && void 0 !== e && "[object process]" === {}.toString.call(e),
                f = "undefined" != typeof Uint8ClampedArray && "undefined" != typeof importScripts && "undefined" != typeof MessageChannel;

            function p() {
                var t = setTimeout;
                return function () {
                    return t(y, 1)
                }
            }

            var d = new Array(1e3);

            function y() {
                for (var t = 0; t < i; t += 2) {
                    (0, d[t])(d[t + 1]), d[t] = void 0, d[t + 1] = void 0
                }
                i = 0
            }

            var m, v, g, x, b = void 0;

            function w(t, e) {
                var n = this, r = new this.constructor(L);
                void 0 === r[q] && P(r);
                var i = n._state;
                if (i) {
                    var o = arguments[i - 1];
                    a(function () {
                        return B(i, r, o, n._result)
                    })
                } else F(n, r, t, e);
                return r
            }

            function A(t) {
                if (t && "object" == typeof t && t.constructor === this) return t;
                var e = new this(L);
                return U(e, t), e
            }

            h ? b = function () {
                return e.nextTick(y)
            } : u ? (v = 0, g = new u(y), x = document.createTextNode(""), g.observe(x, {characterData: !0}), b = function () {
                x.data = v = ++v % 2
            }) : f ? ((m = new MessageChannel).port1.onmessage = y, b = function () {
                return m.port2.postMessage(0)
            }) : b = void 0 === c ? function () {
                try {
                    var t = Function("return this")().require("vertx");
                    return void 0 !== (o = t.runOnLoop || t.runOnContext) ? function () {
                        o(y)
                    } : p()
                } catch (t) {
                    return p()
                }
            }() : p();
            var q = Math.random().toString(36).substring(2);

            function L() {
            }

            var E = void 0, S = 1, C = 2;

            function V(e, n, r) {
                n.constructor === e.constructor && r === w && n.constructor.resolve === A ? function (t, e) {
                    e._state === S ? k(t, e._result) : e._state === C ? I(t, e._result) : F(e, void 0, function (e) {
                        return U(t, e)
                    }, function (e) {
                        return I(t, e)
                    })
                }(e, n) : void 0 === r ? k(e, n) : t(r) ? function (t, e, n) {
                    a(function (t) {
                        var r = !1, i = function (t, e, n, r) {
                            try {
                                t.call(e, n, r)
                            } catch (t) {
                                return t
                            }
                        }(n, e, function (n) {
                            r || (r = !0, e !== n ? U(t, n) : k(t, n))
                        }, function (e) {
                            r || (r = !0, I(t, e))
                        }, t._label);
                        !r && i && (r = !0, I(t, i))
                    }, t)
                }(e, n, r) : k(e, n)
            }

            function U(t, e) {
                if (t === e) I(t, new TypeError("You cannot resolve a promise with itself")); else if (i = typeof (r = e), null === r || "object" !== i && "function" !== i) k(t, e); else {
                    var n = void 0;
                    try {
                        n = e.then
                    } catch (e) {
                        return void I(t, e)
                    }
                    V(t, e, n)
                }
                var r, i
            }

            function j(t) {
                t._onerror && t._onerror(t._result), R(t)
            }

            function k(t, e) {
                t._state === E && (t._result = e, t._state = S, 0 !== t._subscribers.length && a(R, t))
            }

            function I(t, e) {
                t._state === E && (t._state = C, t._result = e, a(j, t))
            }

            function F(t, e, n, r) {
                var i = t._subscribers, o = i.length;
                t._onerror = null, i[o] = e, i[o + S] = n, i[o + C] = r, 0 === o && t._state && a(R, t)
            }

            function R(t) {
                var e = t._subscribers, n = t._state;
                if (0 !== e.length) {
                    for (var r = void 0, i = void 0, o = t._result, s = 0; s < e.length; s += 3) r = e[s], i = e[s + n], r ? B(n, r, i, o) : i(o);
                    t._subscribers.length = 0
                }
            }

            function B(e, n, r, i) {
                var o = t(r), s = void 0, a = void 0, c = !0;
                if (o) {
                    try {
                        s = r(i)
                    } catch (t) {
                        c = !1, a = t
                    }
                    if (n === s) return void I(n, new TypeError("A promises callback cannot return that same promise."))
                } else s = i;
                n._state !== E || (o && c ? U(n, s) : !1 === c ? I(n, a) : e === S ? k(n, s) : e === C && I(n, s))
            }

            var W = 0;

            function P(t) {
                t[q] = W++, t._state = void 0, t._result = void 0, t._subscribers = []
            }

            var T = function () {
                function t(t, e) {
                    this._instanceConstructor = t, this.promise = new t(L), this.promise[q] || P(this.promise), r(e) ? (this.length = e.length, this._remaining = e.length, this._result = new Array(this.length), 0 === this.length ? k(this.promise, this._result) : (this.length = this.length || 0, this._enumerate(e), 0 === this._remaining && k(this.promise, this._result))) : I(this.promise, new Error("Array Methods must be provided an Array"))
                }

                return t.prototype._enumerate = function (t) {
                    for (var e = 0; this._state === E && e < t.length; e++) this._eachEntry(t[e], e)
                }, t.prototype._eachEntry = function (t, e) {
                    var n = this._instanceConstructor, r = n.resolve;
                    if (r === A) {
                        var i = void 0, o = void 0, s = !1;
                        try {
                            i = t.then
                        } catch (t) {
                            s = !0, o = t
                        }
                        if (i === w && t._state !== E) this._settledAt(t._state, e, t._result); else if ("function" != typeof i) this._remaining--, this._result[e] = t; else if (n === Y) {
                            var a = new n(L);
                            s ? I(a, o) : V(a, t, i), this._willSettleAt(a, e)
                        } else this._willSettleAt(new n(function (e) {
                            return e(t)
                        }), e)
                    } else this._willSettleAt(r(t), e)
                }, t.prototype._settledAt = function (t, e, n) {
                    var r = this.promise;
                    r._state === E && (this._remaining--, t === C ? I(r, n) : this._result[e] = n), 0 === this._remaining && k(r, this._result)
                }, t.prototype._willSettleAt = function (t, e) {
                    var n = this;
                    F(t, void 0, function (t) {
                        return n._settledAt(S, e, t)
                    }, function (t) {
                        return n._settledAt(C, e, t)
                    })
                }, t
            }(), Y = function () {
                function e(t) {
                    this[q] = W++, this._result = this._state = void 0, this._subscribers = [], L !== t && ("function" != typeof t && function () {
                        throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")
                    }(), this instanceof e ? function (t, e) {
                        try {
                            e(function (e) {
                                U(t, e)
                            }, function (e) {
                                I(t, e)
                            })
                        } catch (e) {
                            I(t, e)
                        }
                    }(this, t) : function () {
                        throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")
                    }())
                }

                return e.prototype.catch = function (t) {
                    return this.then(null, t)
                }, e.prototype.finally = function (e) {
                    var n = this.constructor;
                    return t(e) ? this.then(function (t) {
                        return n.resolve(e()).then(function () {
                            return t
                        })
                    }, function (t) {
                        return n.resolve(e()).then(function () {
                            throw t
                        })
                    }) : this.then(e, e)
                }, e
            }();
            return Y.prototype.then = w, Y.all = function (t) {
                return new T(this, t).promise
            }, Y.race = function (t) {
                var e = this;
                return r(t) ? new e(function (n, r) {
                    for (var i = t.length, o = 0; o < i; o++) e.resolve(t[o]).then(n, r)
                }) : new e(function (t, e) {
                    return e(new TypeError("You must pass an array to race."))
                })
            }, Y.resolve = A, Y.reject = function (t) {
                var e = new this(L);
                return I(e, t), e
            }, Y._setScheduler = function (t) {
                s = t
            }, Y._setAsap = function (t) {
                a = t
            }, Y._asap = a, Y.polyfill = function () {
                var t = void 0;
                if (void 0 !== n) t = n; else if ("undefined" != typeof self) t = self; else try {
                    t = Function("return this")()
                } catch (t) {
                    throw new Error("polyfill failed because global object is unavailable in this environment")
                }
                var e = t.Promise;
                if (e) {
                    var r = null;
                    try {
                        r = Object.prototype.toString.call(e.resolve())
                    } catch (t) {
                    }
                    if ("[object Promise]" === r && !e.cast) return
                }
                t.Promise = Y
            }, Y.Promise = Y, Y
        }, t.exports = r()
    }).call(this, n(12), n(8))
}, function (t, e, n) {
    "use strict";
    t.exports = function (t, e) {
        /\?/.test(t) ? t += "&" : t += "?";
        return t + r(e)
    };
    var r = n(20)
}, function (t, e, n) {
    "use strict";
    t.exports = function (t, e, n) {
        if ("GET" !== e.method) return void n(new Error("Method " + e.method + " " + t + " is not supported by JSONP."));
        e.debug("JSONP: start");
        var o = !1, s = !1;
        i += 1;
        var a = document.getElementsByTagName("head")[0], c = document.createElement("script"), l = "algoliaJSONP_" + i,
            u = !1;
        window[l] = function (t) {
            !function () {
                try {
                    delete window[l], delete window[l + "_loaded"]
                } catch (t) {
                    window[l] = window[l + "_loaded"] = void 0
                }
            }(), s ? e.debug("JSONP: Late answer, ignoring") : (o = !0, p(), n(null, {
                body: t,
                responseText: JSON.stringify(t)
            }))
        }, t += "&callback=" + l, e.jsonBody && e.jsonBody.params && (t += "&" + e.jsonBody.params);
        var h = setTimeout(function () {
            e.debug("JSONP: Script timeout"), s = !0, p(), n(new r.RequestTimeout)
        }, e.timeouts.complete);

        function f() {
            e.debug("JSONP: success"), u || s || (u = !0, o || (e.debug("JSONP: Fail. Script loaded but did not call the callback"), p(), n(new r.JSONPScriptFail)))
        }

        function p() {
            clearTimeout(h), c.onload = null, c.onreadystatechange = null, c.onerror = null, a.removeChild(c)
        }

        c.onreadystatechange = function () {
            "loaded" !== this.readyState && "complete" !== this.readyState || f()
        }, c.onload = f, c.onerror = function () {
            if (e.debug("JSONP: Script error"), u || s) return;
            p(), n(new r.JSONPScriptError)
        }, c.async = !0, c.defer = !0, c.src = t, a.appendChild(c)
    };
    var r = n(3), i = 0
}, function (t, e, n) {
    t.exports = function (t) {
        return function (e, o, s) {
            var a = n(2);
            (s = s && a(s) || {}).hosts = s.hosts || ["places-dsn.algolia.net", "places-1.algolianet.com", "places-2.algolianet.com", "places-3.algolianet.com"], 0 !== arguments.length && "object" != typeof e && void 0 !== e || (e = "", o = "", s._allowEmptyCredentials = !0);
            var c = t(e, o, s), l = c.initIndex("places");
            return l.search = i("query", "/1/places/query"), l.reverse = function (t, e) {
                var n = r.encode(t);
                return this.as._jsonRequest({
                    method: "GET",
                    url: "/1/places/reverse?" + n,
                    hostType: "read",
                    callback: e
                })
            }, l.getObject = function (t, e) {
                return this.as._jsonRequest({
                    method: "GET",
                    url: "/1/places/" + encodeURIComponent(t),
                    hostType: "read",
                    callback: e
                })
            }, l
        }
    };
    var r = n(43), i = n(15)
}, function (t, e, n) {
    "use strict";
    e.decode = e.parse = n(44), e.encode = e.stringify = n(20)
}, function (t, e, n) {
    "use strict";

    function r(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }

    t.exports = function (t, e, n, o) {
        e = e || "&", n = n || "=";
        var s = {};
        if ("string" != typeof t || 0 === t.length) return s;
        var a = /\+/g;
        t = t.split(e);
        var c = 1e3;
        o && "number" == typeof o.maxKeys && (c = o.maxKeys);
        var l = t.length;
        c > 0 && l > c && (l = c);
        for (var u = 0; u < l; ++u) {
            var h, f, p, d, y = t[u].replace(a, "%20"), m = y.indexOf(n);
            m >= 0 ? (h = y.substr(0, m), f = y.substr(m + 1)) : (h = y, f = ""), p = decodeURIComponent(h), d = decodeURIComponent(f), r(s, p) ? i(s[p]) ? s[p].push(d) : s[p] = [s[p], d] : s[p] = d
        }
        return s
    };
    var i = Array.isArray || function (t) {
        return "[object Array]" === Object.prototype.toString.call(t)
    }
}, function (t, e, n) {
    "use strict";
    t.exports = "3.33.0"
}, function (t, e, n) {
    t.exports = n.p + "../css/zoom-image.css"
}, , function (t, e, n) {
    "use strict";
    n.r(e);
    var r = Array.isArray, i = n(21), o = "object" == typeof self && self && self.Object === Object && self,
        s = i.a || o || Function("return this")(), a = s.Symbol, c = Object.prototype, l = c.hasOwnProperty,
        u = c.toString, h = a ? a.toStringTag : void 0;
    var f = function (t) {
        var e = l.call(t, h), n = t[h];
        try {
            t[h] = void 0;
            var r = !0
        } catch (t) {
        }
        var i = u.call(t);
        return r && (e ? t[h] = n : delete t[h]), i
    }, p = Object.prototype.toString;
    var d = function (t) {
        return p.call(t)
    }, y = "[object Null]", m = "[object Undefined]", v = a ? a.toStringTag : void 0;
    var g = function (t) {
        return null == t ? void 0 === t ? m : y : v && v in Object(t) ? f(t) : d(t)
    };
    var x = function (t) {
        return null != t && "object" == typeof t
    }, b = "[object Symbol]";
    var w = function (t) {
        return "symbol" == typeof t || x(t) && g(t) == b
    }, A = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, q = /^\w*$/;
    var L = function (t, e) {
        if (r(t)) return !1;
        var n = typeof t;
        return !("number" != n && "symbol" != n && "boolean" != n && null != t && !w(t)) || q.test(t) || !A.test(t) || null != e && t in Object(e)
    };
    var E = function (t) {
        var e = typeof t;
        return null != t && ("object" == e || "function" == e)
    }, S = "[object AsyncFunction]", C = "[object Function]", V = "[object GeneratorFunction]", U = "[object Proxy]";
    var j, k = function (t) {
            if (!E(t)) return !1;
            var e = g(t);
            return e == C || e == V || e == S || e == U
        }, I = s["__core-js_shared__"],
        F = (j = /[^.]+$/.exec(I && I.keys && I.keys.IE_PROTO || "")) ? "Symbol(src)_1." + j : "";
    var R = function (t) {
        return !!F && F in t
    }, B = Function.prototype.toString;
    var W = function (t) {
            if (null != t) {
                try {
                    return B.call(t)
                } catch (t) {
                }
                try {
                    return t + ""
                } catch (t) {
                }
            }
            return ""
        }, P = /^\[object .+?Constructor\]$/, T = Function.prototype, Y = Object.prototype, G = T.toString,
        X = Y.hasOwnProperty,
        O = RegExp("^" + G.call(X).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
    var J = function (t) {
        return !(!E(t) || R(t)) && (k(t) ? O : P).test(W(t))
    };
    var K = function (t, e) {
        return null == t ? void 0 : t[e]
    };
    var M = function (t, e) {
        var n = K(t, e);
        return J(n) ? n : void 0
    }, N = M(Object, "create");
    var Z = function () {
        this.__data__ = N ? N(null) : {}, this.size = 0
    };
    var Q = function (t) {
        var e = this.has(t) && delete this.__data__[t];
        return this.size -= e ? 1 : 0, e
    }, z = "__lodash_hash_undefined__", D = Object.prototype.hasOwnProperty;
    var H = function (t) {
        var e = this.__data__;
        if (N) {
            var n = e[t];
            return n === z ? void 0 : n
        }
        return D.call(e, t) ? e[t] : void 0
    }, _ = Object.prototype.hasOwnProperty;
    var $ = function (t) {
        var e = this.__data__;
        return N ? void 0 !== e[t] : _.call(e, t)
    }, tt = "__lodash_hash_undefined__";
    var et = function (t, e) {
        var n = this.__data__;
        return this.size += this.has(t) ? 0 : 1, n[t] = N && void 0 === e ? tt : e, this
    };

    function nt(t) {
        var e = -1, n = null == t ? 0 : t.length;
        for (this.clear(); ++e < n;) {
            var r = t[e];
            this.set(r[0], r[1])
        }
    }

    nt.prototype.clear = Z, nt.prototype.delete = Q, nt.prototype.get = H, nt.prototype.has = $, nt.prototype.set = et;
    var rt = nt;
    var it = function () {
        this.__data__ = [], this.size = 0
    };
    var ot = function (t, e) {
        return t === e || t != t && e != e
    };
    var st = function (t, e) {
        for (var n = t.length; n--;) if (ot(t[n][0], e)) return n;
        return -1
    }, at = Array.prototype.splice;
    var ct = function (t) {
        var e = this.__data__, n = st(e, t);
        return !(n < 0 || (n == e.length - 1 ? e.pop() : at.call(e, n, 1), --this.size, 0))
    };
    var lt = function (t) {
        var e = this.__data__, n = st(e, t);
        return n < 0 ? void 0 : e[n][1]
    };
    var ut = function (t) {
        return st(this.__data__, t) > -1
    };
    var ht = function (t, e) {
        var n = this.__data__, r = st(n, t);
        return r < 0 ? (++this.size, n.push([t, e])) : n[r][1] = e, this
    };

    function ft(t) {
        var e = -1, n = null == t ? 0 : t.length;
        for (this.clear(); ++e < n;) {
            var r = t[e];
            this.set(r[0], r[1])
        }
    }

    ft.prototype.clear = it, ft.prototype.delete = ct, ft.prototype.get = lt, ft.prototype.has = ut, ft.prototype.set = ht;
    var pt = ft, dt = M(s, "Map");
    var yt = function () {
        this.size = 0, this.__data__ = {hash: new rt, map: new (dt || pt), string: new rt}
    };
    var mt = function (t) {
        var e = typeof t;
        return "string" == e || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== t : null === t
    };
    var vt = function (t, e) {
        var n = t.__data__;
        return mt(e) ? n["string" == typeof e ? "string" : "hash"] : n.map
    };
    var gt = function (t) {
        var e = vt(this, t).delete(t);
        return this.size -= e ? 1 : 0, e
    };
    var xt = function (t) {
        return vt(this, t).get(t)
    };
    var bt = function (t) {
        return vt(this, t).has(t)
    };
    var wt = function (t, e) {
        var n = vt(this, t), r = n.size;
        return n.set(t, e), this.size += n.size == r ? 0 : 1, this
    };

    function At(t) {
        var e = -1, n = null == t ? 0 : t.length;
        for (this.clear(); ++e < n;) {
            var r = t[e];
            this.set(r[0], r[1])
        }
    }

    At.prototype.clear = yt, At.prototype.delete = gt, At.prototype.get = xt, At.prototype.has = bt, At.prototype.set = wt;
    var qt = At, Lt = "Expected a function";

    function Et(t, e) {
        if ("function" != typeof t || null != e && "function" != typeof e) throw new TypeError(Lt);
        var n = function () {
            var r = arguments, i = e ? e.apply(this, r) : r[0], o = n.cache;
            if (o.has(i)) return o.get(i);
            var s = t.apply(this, r);
            return n.cache = o.set(i, s) || o, s
        };
        return n.cache = new (Et.Cache || qt), n
    }

    Et.Cache = qt;
    var St = Et, Ct = 500;
    var Vt = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
        Ut = /\\(\\)?/g, jt = function (t) {
            var e = St(t, function (t) {
                return n.size === Ct && n.clear(), t
            }), n = e.cache;
            return e
        }(function (t) {
            var e = [];
            return 46 === t.charCodeAt(0) && e.push(""), t.replace(Vt, function (t, n, r, i) {
                e.push(r ? i.replace(Ut, "$1") : n || t)
            }), e
        });
    var kt = function (t, e) {
        for (var n = -1, r = null == t ? 0 : t.length, i = Array(r); ++n < r;) i[n] = e(t[n], n, t);
        return i
    }, It = 1 / 0, Ft = a ? a.prototype : void 0, Rt = Ft ? Ft.toString : void 0;
    var Bt = function t(e) {
        if ("string" == typeof e) return e;
        if (r(e)) return kt(e, t) + "";
        if (w(e)) return Rt ? Rt.call(e) : "";
        var n = e + "";
        return "0" == n && 1 / e == -It ? "-0" : n
    };
    var Wt = function (t) {
        return null == t ? "" : Bt(t)
    };
    var Pt = function (t, e) {
        return r(t) ? t : L(t, e) ? [t] : jt(Wt(t))
    }, Tt = 1 / 0;
    var Yt = function (t) {
        if ("string" == typeof t || w(t)) return t;
        var e = t + "";
        return "0" == e && 1 / t == -Tt ? "-0" : e
    };
    var Gt = function (t, e) {
        for (var n = 0, r = (e = Pt(e, t)).length; null != t && n < r;) t = t[Yt(e[n++])];
        return n && n == r ? t : void 0
    };
    var Xt = function (t, e, n) {
        var r = null == t ? void 0 : Gt(t, e);
        return void 0 === r ? n : r
    }, Ot = {
        expand: "Expand",
        collapse: "Collapse",
        noSearchResults: "No search results found",
        from: "From",
        projects: "Project",
        guides: "Guide",
        blog: "Blog",
        activities: "Activity"
    }, Jt = {
        expand: "全部展开",
        collapse: "收起",
        noSearchResults: "暂无搜索结果",
        from: "来自",
        projects: "项目",
        guides: "指南",
        blog: "博客",
        activities: "活动"
    };

    function Kt(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
        }
    }

    function Mt(t) {
        var e = window.SITE_LANGUAGE;
        return Xt("zh" === e ? Jt : Ot, t, "")
    }

    var Nt = document.querySelector.bind(document), Zt = document.querySelectorAll.bind(document), Qt = function () {
        function t() {
            !function (t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
            }(this, t);
            var e = document.createElement("div");
            e.setAttribute("class", "js-overlay"), document.body.appendChild(e), this._overlayDOM = e, this._isShow = !1
        }

        var e, n, r;
        return e = t, r = [{
            key: "create", value: function () {
                return new t
            }
        }], (n = [{
            key: "isShow", value: function () {
                return this._isShow
            }
        }, {
            key: "show", value: function () {
                this._overlayDOM.classList.add("-show"), this._isShow = !0, document.body.classList.add("-noscroll")
            }
        }, {
            key: "hide", value: function () {
                this._overlayDOM.classList.remove("-show"), this._isShow = !1, document.body.classList.remove("-noscroll")
            }
        }, {
            key: "addClickEvent", value: function (t) {
                this._overlayDOM.addEventListener("click", t, {once: !0})
            }
        }, {
            key: "destroy", value: function () {
                document.body.classList.remove("-noscroll"), this._overlayDOM.remove()
            }
        }]) && Kt(e.prototype, n), r && Kt(e, r), t
    }();
    var zt = function () {
        !function () {
            if (Nt(".ss-aside-tags")) {
                var t = Nt(".ss-aside-tags .card-extra");
                t.innerHTML = Mt("expand");
                var e = !1;
                t.addEventListener("click", function () {
                    e = !e, this.innerHTML = Mt(e ? "expand" : "collapse");
                    var t = [].slice.call(Zt(".ss-aside-tags .tag"), 10);
                    e ? t.forEach(function (t) {
                        t.style.display = "none"
                    }) : t.forEach(function (t) {
                        t.style.display = "inline-block"
                    })
                }), t.click()
            }
        }(), function () {
            if (Nt("#js-code")) {
                var t = Zt("#js-code .button"), e = t[0], n = t[1], r = Nt("#js-code .input"),
                    i = Nt("#js-code .addon"), o = r.value.trim();
                e.addEventListener("click", function () {
                    e.classList.add("-selected"), n.classList.remove("-selected"), r.value = "".concat(o, ".git")
                }), n.addEventListener("click", function () {
                    e.classList.remove("-selected"), n.classList.add("-selected"), r.value = "".concat(o.replace("https:", "git@github.com:"), ".git")
                });
                var s = null;
                i.addEventListener("click", function () {
                    s && window.clearTimeout(s), r.focus(), r.select();
                    try {
                        document.execCommand("copy")
                    } catch (t) {
                    }
                    r.blur(), i.classList.add("-copyed"), s = window.setTimeout(function () {
                        i.classList.remove("-copyed")
                    }, 3e3)
                }), e.click()
            }
        }()
    }, Dt = 2, Ht = -98;

    function _t(t) {
        var e = function (e) {
                return e === Ht ? "" : t(e)
            }, n = Zt(".ss-pagination")[0], r = n.dataset, i = parseInt(r.total), o = parseInt(r.current), s = [],
            a = Math.max(1, o - Dt), c = Math.min(i, o + Dt);
        if (c - a != 2 * Dt) {
            var l = 2 * Dt - (c - o), u = 2 * Dt - (o - a);
            a = Math.max(1, o - l), c = Math.min(i, o + u)
        }
        for (var h = a; h <= c; h++) s.push(h);
        var f = s[0], p = s[s.length - 1];
        f > 2 && s.unshift(Ht), f > 1 && s.unshift(1), p < i - 1 && s.push(Ht), p < i && s.push(i), n.innerHTML = '\n  <ul class="list">\n    '.concat(s.map(function (t) {
            var n = "" === e(t) ? "" : ' href="'.concat(e(t), '"');
            return "<a".concat(n, '>\n        <li class="item ').concat(t === o ? "-active" : "", '">\n          ').concat(t === Ht ? "..." : t, "\n        </li>\n      </a>")
        }).join(""), "\n  </ul>\n  ")
    }

    var $t = n(7), te = n.n($t), ee = n(13), ne = n.n(ee);

    function re(t, e) {
        var n = Object.keys(t);
        return Object.getOwnPropertySymbols && n.push.apply(n, Object.getOwnPropertySymbols(t)), e && (n = n.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), n
    }

    function ie(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? re(n, !0).forEach(function (e) {
                oe(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : re(n).forEach(function (e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function oe(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    var se = n(0), ae = n.n(se),
        ce = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 3261.69 2858.9"><defs><style>.cls-1,.cls-10,.cls-15,.cls-17,.cls-2,.cls-20,.cls-21,.cls-22,.cls-23,.cls-25,.cls-27,.cls-28,.cls-3,.cls-30,.cls-33,.cls-4,.cls-6,.cls-7,.cls-9{opacity:0.27;}.cls-1,.cls-10,.cls-11,.cls-14,.cls-15,.cls-16,.cls-17,.cls-18,.cls-19,.cls-2,.cls-20,.cls-21,.cls-22,.cls-23,.cls-24,.cls-25,.cls-26,.cls-27,.cls-28,.cls-29,.cls-3,.cls-30,.cls-31,.cls-33,.cls-36,.cls-37,.cls-38,.cls-4,.cls-6,.cls-7,.cls-8,.cls-9{isolation:isolate;}.cls-1{fill:url(#未命名的渐变_17);}.cls-2{fill:url(#未命名的渐变_16);}.cls-3{fill:url(#未命名的渐变_15);}.cls-4{fill:url(#未命名的渐变_4);}.cls-5{fill:#fff;}.cls-6{fill:url(#未命名的渐变_14);}.cls-7{fill:url(#未命名的渐变_4-2);}.cls-8{opacity:0.33;fill:url(#未命名的渐变_13);}.cls-9{fill:url(#未命名的渐变_12);}.cls-10{fill:url(#未命名的渐变_11);}.cls-11,.cls-36{opacity:0.66;}.cls-11{fill:url(#未命名的渐变_7);}.cls-12{fill:url(#未命名的渐变_10);}.cls-13{fill:url(#未命名的渐变_9);}.cls-14,.cls-31{opacity:0.25;}.cls-14{fill:url(#未命名的渐变_8);}.cls-15{fill:url(#未命名的渐变_4-3);}.cls-16{opacity:0.18;fill:url(#未命名的渐变_4-4);}.cls-17{fill:url(#未命名的渐变_4-5);}.cls-18{opacity:0.39;fill:url(#未命名的渐变_6);}.cls-19{opacity:0.31;fill:url(#未命名的渐变_6-2);}.cls-20{fill:url(#未命名的渐变_5);}.cls-21{fill:url(#未命名的渐变_4-6);}.cls-22{fill:url(#未命名的渐变_5-2);}.cls-23{fill:url(#未命名的渐变_7-2);}.cls-24,.cls-26,.cls-29{opacity:0.45;}.cls-24{fill:url(#未命名的渐变_7-3);}.cls-25{fill:url(#未命名的渐变_4-7);}.cls-26{fill:url(#未命名的渐变_2);}.cls-27{fill:url(#未命名的渐变_3);}.cls-28{fill:url(#未命名的渐变_4-8);}.cls-29{fill:url(#未命名的渐变_2-2);}.cls-30{fill:url(#未命名的渐变_3-2);}.cls-31{fill:url(#未命名的渐变_7-4);}.cls-32{fill:url(#未命名的渐变_22);}.cls-33{fill:url(#未命名的渐变_10-2);}.cls-34{fill:url(#未命名的渐变_21);}.cls-35{fill:url(#未命名的渐变_20);}.cls-36{fill:url(#未命名的渐变_7-5);}.cls-37{opacity:0.54;fill:url(#未命名的渐变_19);}.cls-38{opacity:0.24;fill:url(#未命名的渐变_18);}</style><linearGradient id="未命名的渐变_17" x1="1986.59" y1="128.71" x2="2604.64" y2="128.71" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#abc5e7"/><stop offset="0.25" stop-color="#a9c4e7" stop-opacity="0.99"/><stop offset="0.41" stop-color="#a3c2e8" stop-opacity="0.95"/><stop offset="0.54" stop-color="#99bee9" stop-opacity="0.89"/><stop offset="0.66" stop-color="#8bb8ea" stop-opacity="0.79"/><stop offset="0.77" stop-color="#79b1ec" stop-opacity="0.68"/><stop offset="0.87" stop-color="#62a8ee" stop-opacity="0.53"/><stop offset="0.97" stop-color="#489ef0" stop-opacity="0.36"/><stop offset="1" stop-color="#3f9af1" stop-opacity="0.3"/></linearGradient><linearGradient id="未命名的渐变_16" x1="1986.59" y1="128.71" x2="2604.98" y2="128.71" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#7ffdff" stop-opacity="0.87"/><stop offset="0.02" stop-color="#7cf7fc" stop-opacity="0.78"/><stop offset="0.07" stop-color="#76edf8" stop-opacity="0.61"/><stop offset="0.12" stop-color="#71e3f4" stop-opacity="0.47"/><stop offset="0.17" stop-color="#6cdbf0" stop-opacity="0.34"/><stop offset="0.23" stop-color="#68d4ed" stop-opacity="0.23"/><stop offset="0.3" stop-color="#65ceeb" stop-opacity="0.15"/><stop offset="0.38" stop-color="#63cae9" stop-opacity="0.08"/><stop offset="0.48" stop-color="#61c7e8" stop-opacity="0.03"/><stop offset="0.62" stop-color="#60c5e7" stop-opacity="0.01"/><stop offset="1" stop-color="#60c5e7" stop-opacity="0"/></linearGradient><linearGradient id="未命名的渐变_15" x1="1232" y1="-253.59" x2="2008.6" y2="-253.59" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#abc5e7"/><stop offset="0.31" stop-color="#aec7e8"/><stop offset="0.51" stop-color="#b6cdea"/><stop offset="0.67" stop-color="#c5d7ee"/><stop offset="0.82" stop-color="#dae5f4"/><stop offset="0.95" stop-color="#f4f8fc"/><stop offset="1" stop-color="#fff"/></linearGradient><linearGradient id="未命名的渐变_4" x1="2131.74" y1="544.49" x2="1412.13" y2="-600.58" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#63a1e7" stop-opacity="0.8"/><stop offset="0.64" stop-color="#2078e8" stop-opacity="0.94"/><stop offset="1" stop-color="#0064e9"/></linearGradient><linearGradient id="未命名的渐变_14" x1="2583.7" y1="355.44" x2="1924.34" y2="-536.85" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#75cbff" stop-opacity="0.7"/><stop offset="1" stop-color="#5064e9" stop-opacity="0.2"/></linearGradient><linearGradient id="未命名的渐变_4-2" x1="2469.9" y1="426.63" x2="1892.07" y2="-330.98" xlink:href="#未命名的渐变_4"/><linearGradient id="未命名的渐变_13" x1="1738.41" y1="-483.91" x2="2094.4" y2="-362.62" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0064e9"/><stop offset="0" stop-color="#0064e9" stop-opacity="0.3"/><stop offset="1" stop-color="#0064e9"/></linearGradient><linearGradient id="未命名的渐变_12" x1="2583.7" y1="355.44" x2="1924.34" y2="-536.85" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#abc5e7"/><stop offset="0.29" stop-color="#a8c3e6"/><stop offset="0.47" stop-color="#a0bce2"/><stop offset="0.62" stop-color="#91afdc"/><stop offset="0.74" stop-color="#7fa0d4"/><stop offset="0.81" stop-color="#7296cf"/><stop offset="0.94" stop-color="#517bc0"/><stop offset="1" stop-color="#3e6bb8"/></linearGradient><linearGradient id="未命名的渐变_11" x1="1839.09" y1="86.81" x2="1612.78" y2="556.01" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0064e9" stop-opacity="0"/><stop offset="0.81" stop-color="#9cc5e7"/><stop offset="1" stop-color="#9cc5e7" stop-opacity="0"/></linearGradient><linearGradient id="未命名的渐变_7" x1="2245.63" y1="1322.01" x2="1791.31" y2="-361.9" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#9cc5e7" stop-opacity="0.3"/><stop offset="0.25" stop-color="#9ac3e7" stop-opacity="0.31"/><stop offset="0.41" stop-color="#91bee7" stop-opacity="0.35"/><stop offset="0.54" stop-color="#83b6e7" stop-opacity="0.41"/><stop offset="0.66" stop-color="#70a9e8" stop-opacity="0.5"/><stop offset="0.76" stop-color="#5699e8" stop-opacity="0.61"/><stop offset="0.87" stop-color="#3686e8" stop-opacity="0.76"/><stop offset="0.96" stop-color="#126fe9" stop-opacity="0.92"/><stop offset="1" stop-color="#0064e9"/></linearGradient><linearGradient id="未命名的渐变_10" x1="1805.17" y1="106.32" x2="1578.35" y2="562.96" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff" stop-opacity="0.2"/><stop offset="0.18" stop-color="#ddeafc" stop-opacity="0.28"/><stop offset="0.53" stop-color="#85b5f4" stop-opacity="0.49"/><stop offset="1" stop-color="#0064e9" stop-opacity="0.8"/></linearGradient><linearGradient id="未命名的渐变_9" x1="2068.51" y1="1385.64" x2="1744.38" y2="184.24" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#9cc5e7" stop-opacity="0.1"/><stop offset="0.23" stop-color="#9ac4e7" stop-opacity="0.11"/><stop offset="0.37" stop-color="#94c0e7" stop-opacity="0.15"/><stop offset="0.5" stop-color="#89b9e7" stop-opacity="0.21"/><stop offset="0.6" stop-color="#79afe7" stop-opacity="0.3"/><stop offset="0.7" stop-color="#65a3e8" stop-opacity="0.42"/><stop offset="0.8" stop-color="#4d94e8" stop-opacity="0.56"/><stop offset="0.89" stop-color="#3082e8" stop-opacity="0.73"/><stop offset="0.97" stop-color="#0f6de9" stop-opacity="0.92"/><stop offset="1" stop-color="#0064e9"/></linearGradient><linearGradient id="未命名的渐变_8" x1="2625.74" y1="921.4" x2="1539.01" y2="895.91" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset="0.37" stop-color="#fff" stop-opacity="0.01"/><stop offset="0.51" stop-color="#fff" stop-opacity="0.03"/><stop offset="0.6" stop-color="#fff" stop-opacity="0.08"/><stop offset="0.68" stop-color="#fff" stop-opacity="0.15"/><stop offset="0.75" stop-color="#fff" stop-opacity="0.23"/><stop offset="0.8" stop-color="#fff" stop-opacity="0.34"/><stop offset="0.86" stop-color="#fff" stop-opacity="0.47"/><stop offset="0.91" stop-color="#fff" stop-opacity="0.61"/><stop offset="0.95" stop-color="#fff" stop-opacity="0.78"/><stop offset="0.99" stop-color="#fff" stop-opacity="0.96"/><stop offset="1" stop-color="#fff"/></linearGradient><linearGradient id="未命名的渐变_4-3" x1="834.01" y1="308.52" x2="1363.43" y2="308.52" xlink:href="#未命名的渐变_4"/><linearGradient id="未命名的渐变_4-4" x1="791" y1="227.93" x2="1255.02" y2="227.93" xlink:href="#未命名的渐变_4"/><linearGradient id="未命名的渐变_4-5" x1="791" y1="698.1" x2="952.46" y2="698.1" xlink:href="#未命名的渐变_4"/><linearGradient id="未命名的渐变_6" x1="685.36" y1="789.76" x2="1544.72" y2="293.6" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#83c5e7" stop-opacity="0.6"/><stop offset="1" stop-color="#0064e9"/></linearGradient><linearGradient id="未命名的渐变_6-2" x1="1896.79" y1="243.87" x2="1645.87" y2="243.87" xlink:href="#未命名的渐变_6"/><linearGradient id="未命名的渐变_5" x1="1112.68" y1="59.08" x2="1252.77" y2="-183.56" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#83c5e7" stop-opacity="0.6"/><stop offset="0.47" stop-color="#80c3e7" stop-opacity="0.6"/><stop offset="0.64" stop-color="#75bae7" stop-opacity="0.6"/><stop offset="0.76" stop-color="#61ace8" stop-opacity="0.6"/><stop offset="0.86" stop-color="#4597e8" stop-opacity="0.6"/><stop offset="0.94" stop-color="#217ce9" stop-opacity="0.6"/><stop offset="1" stop-color="#0064e9" stop-opacity="0.6"/></linearGradient><linearGradient id="未命名的渐变_4-6" x1="1508.21" y1="-17.99" x2="1735.41" y2="-411.52" xlink:href="#未命名的渐变_4"/><linearGradient id="未命名的渐变_5-2" x1="2124.32" y1="-375.1" x2="1985.83" y2="-375.1" xlink:href="#未命名的渐变_5"/><linearGradient id="未命名的渐变_7-2" x1="321.7" y1="338.95" x2="2172.53" y2="-203.96" xlink:href="#未命名的渐变_7"/><linearGradient id="未命名的渐变_7-3" x1="2099.37" y1="30.35" x2="562.29" y2="30.35" gradientTransform="matrix(1, 0, 0, -1, 0.05, 1957.39)" xlink:href="#未命名的渐变_7"/><linearGradient id="未命名的渐变_4-7" x1="1217.03" y1="1166.5" x2="860.74" y2="699.36" xlink:href="#未命名的渐变_4"/><linearGradient id="未命名的渐变_2" x1="1083.31" y1="518.79" x2="818.43" y2="777.14" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#9cc5e7" stop-opacity="0.1"/><stop offset="0.12" stop-color="#8fbde7" stop-opacity="0.17"/><stop offset="0.35" stop-color="#6ea9e8" stop-opacity="0.36"/><stop offset="0.68" stop-color="#3988e8" stop-opacity="0.67"/><stop offset="1" stop-color="#0064e9"/></linearGradient><linearGradient id="未命名的渐变_3" x1="1166.59" y1="1344.37" x2="1170.22" y2="278.59" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#abc5e7"/><stop offset="0.29" stop-color="#a8c3e6"/><stop offset="0.47" stop-color="#a0bce2"/><stop offset="0.62" stop-color="#91b0dc"/><stop offset="0.75" stop-color="#7c9fd3"/><stop offset="0.88" stop-color="#6288c7"/><stop offset="0.99" stop-color="#416eb9"/><stop offset="1" stop-color="#3e6bb8"/></linearGradient><linearGradient id="未命名的渐变_4-8" x1="18273.88" y1="8805.16" x2="17923.19" y2="8345.37" gradientTransform="matrix(-0.53, -0.85, -0.85, 0.53, 18522.8, 11579.79)" xlink:href="#未命名的渐变_4"/><linearGradient id="未命名的渐变_2-2" x1="2066.55" y1="992.12" x2="1834.21" y2="1218.72" xlink:href="#未命名的渐变_2"/><linearGradient id="未命名的渐变_3-2" x1="2069.17" y1="1092.67" x2="1027.72" y2="1111.06" xlink:href="#未命名的渐变_3"/><linearGradient id="未命名的渐变_7-4" x1="2389.7" y1="1489.57" x2="1600.64" y2="370.22" xlink:href="#未命名的渐变_7"/><linearGradient id="未命名的渐变_22" x1="1078.28" y1="913.12" x2="863.07" y2="605.11" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#73b1ff" stop-opacity="0.2"/><stop offset="0.2" stop-color="#70afff" stop-opacity="0.21"/><stop offset="0.37" stop-color="#68aafd" stop-opacity="0.26"/><stop offset="0.52" stop-color="#5ba0fb" stop-opacity="0.33"/><stop offset="0.66" stop-color="#4893f7" stop-opacity="0.43"/><stop offset="0.67" stop-color="#4793f7" stop-opacity="0.43"/><stop offset="0.74" stop-color="#3b8bf5" stop-opacity="0.49"/><stop offset="0.89" stop-color="#1b76ee" stop-opacity="0.66"/><stop offset="1" stop-color="#0064e9" stop-opacity="0.8"/></linearGradient><linearGradient id="未命名的渐变_10-2" x1="1882.9" y1="1177.89" x2="1268.41" y2="1229.27" xlink:href="#未命名的渐变_10"/><linearGradient id="未命名的渐变_21" x1="564.28" y1="504.21" x2="1668.09" y2="504.21" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff" stop-opacity="0.2"/><stop offset="0.27" stop-color="#d8e7fc" stop-opacity="0.23"/><stop offset="0.68" stop-color="#6ca5f2" stop-opacity="0.32"/><stop offset="1" stop-color="#0064e9" stop-opacity="0.4"/></linearGradient><linearGradient id="未命名的渐变_20" x1="1668.09" y1="504.21" x2="564.28" y2="504.21" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset="0.22" stop-color="#fdfdff" stop-opacity="0.01"/><stop offset="0.37" stop-color="#f4f5fe" stop-opacity="0.05"/><stop offset="0.5" stop-color="#e7e9fc" stop-opacity="0.12"/><stop offset="0.62" stop-color="#d4d8f9" stop-opacity="0.21"/><stop offset="0.73" stop-color="#bbc1f6" stop-opacity="0.33"/><stop offset="0.83" stop-color="#9ca5f2" stop-opacity="0.47"/><stop offset="0.93" stop-color="#7885ed" stop-opacity="0.65"/><stop offset="1" stop-color="#5868e9" stop-opacity="0.8"/></linearGradient><linearGradient id="未命名的渐变_7-5" x1="828.93" y1="529.02" x2="2199.68" y2="1555.06" xlink:href="#未命名的渐变_7"/><linearGradient id="未命名的渐变_19" x1="794.1" y1="312.34" x2="2345.63" y2="1946" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#7ffdff" stop-opacity="0.87"/><stop offset="0.01" stop-color="#7efcff" stop-opacity="0.85"/><stop offset="0.07" stop-color="#78f0fa" stop-opacity="0.68"/><stop offset="0.13" stop-color="#72e6f5" stop-opacity="0.51"/><stop offset="0.2" stop-color="#6dddf1" stop-opacity="0.38"/><stop offset="0.28" stop-color="#69d6ee" stop-opacity="0.26"/><stop offset="0.36" stop-color="#66d0ec" stop-opacity="0.16"/><stop offset="0.46" stop-color="#63cbe9" stop-opacity="0.09"/><stop offset="0.57" stop-color="#61c7e8" stop-opacity="0.04"/><stop offset="0.71" stop-color="#60c6e7" stop-opacity="0.01"/><stop offset="1" stop-color="#60c5e7" stop-opacity="0"/></linearGradient><linearGradient id="未命名的渐变_18" x1="564" y1="536.97" x2="1659.93" y2="536.97" gradientTransform="matrix(1, 0, 0, -1, 0, 1958)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset="0.1" stop-color="#fff" stop-opacity="0.02"/><stop offset="0.22" stop-color="#fff" stop-opacity="0.09"/><stop offset="0.36" stop-color="#fff" stop-opacity="0.19"/><stop offset="0.51" stop-color="#fff" stop-opacity="0.34"/><stop offset="0.67" stop-color="#fff" stop-opacity="0.52"/><stop offset="0.84" stop-color="#fff" stop-opacity="0.75"/><stop offset="1" stop-color="#fff"/></linearGradient></defs><title>sofa首页-拆解</title><g id="h"><g id="图层_2" data-name="图层 2"><g id="图层_1-2" data-name="图层 1-2"><polygon class="cls-1" points="1986.59 2224.94 2584.49 1386.84 2604.64 1445.33 2008.6 2271.75 1986.59 2224.94"/><polygon class="cls-2" points="1986.59 2224.94 2584.49 1386.84 2604.98 1445.45 2008.6 2271.75 1986.59 2224.94"/><polygon class="cls-3" points="1232 2151.43 1986.05 2224.91 2008.6 2271.75 1253.52 2191.87 1232 2151.43"/><polygon class="cls-4" points="2584.3 1387.16 1986.17 2224.76 1232 2151.43 1831.36 1313 2584.2 1386.94 2584.3 1387.16"/></g></g></g><g id="g"><g id="图层_2-2" data-name="图层 2"><g id="图层_1-2-2" data-name="图层 1-2"><polygon class="cls-5" points="2099.9 2471.64 2686.56 1648.92 2584.62 1386.94 2538.35 1382 1940 2220.27 1940 2220.27 2053.85 2466.68 2099.69 2471.66 2099.76 2471.83 2099.86 2471.68 2099.92 2471.69 2099.9 2471.64"/><polygon class="cls-6" points="1986.33 2224.75 2584.62 1386.94 2686.56 1648.92 2099.76 2471.83 1986.33 2224.75"/><polygon class="cls-7" points="2538.35 1382 2584.62 1386.94 1986.29 2225.07 1940 2220.27 2538.35 1382"/><polygon class="cls-8" points="1940 2220.27 2053.85 2466.68 2099.92 2471.69 1986.24 2225.07 1940 2220.27"/><polygon class="cls-9" points="1986.33 2224.75 2584.62 1386.94 2686.56 1648.92 2099.76 2471.83 1986.33 2224.75"/></g></g></g><g id="f"><g id="图层_2-3" data-name="图层 2"><g id="图层_1-2-3" data-name="图层 1-2"><path class="cls-5" d="M2486,1117.71l-207.23-527.4-.34-.28-40.88-5.94L1610.39,1475H1610l228.23,496,37.34,3.72.15.33Zm-836.56,368-2.07-4.47h0Z"/><polygon class="cls-10" points="1658.19 1466.63 1879.67 1958.81 1872.81 1970.6 1760.45 1725.85 1760.38 1725.69 1648.01 1480.94 1658.19 1466.63"/><polygon class="cls-11" points="2278.77 590.31 2486.01 1117.71 1875.72 1975.08 1761.13 1728.95 1761.06 1728.8 1647.3 1481 2278.77 590.31"/><polygon class="cls-12" points="1610 1474.97 1647.37 1481.2 1875.6 1974.76 1838.23 1971.03 1610 1474.97"/><polygon class="cls-13" points="2237.55 584.08 2278.43 590.03 1647.37 1481.24 1610.21 1475.29 2237.55 584.08"/><polygon class="cls-14" points="2271.74 601.18 2281.21 623.27 1657.48 1503.03 1648.01 1480.94 2271.74 601.18"/></g></g></g><g id="e"><g id="图层_2-4" data-name="图层 2"><g id="图层_1-2-4" data-name="图层 1-2"><polygon class="cls-15" points="834.01 1344.85 951.33 1179.46 1363.43 1966.5 1254.19 2119.5 834.01 1344.85"/><polygon class="cls-16" points="834.84 1344.85 791 1340.63 1216.46 2115.14 1255.02 2119.5 834.84 1344.85"/><polygon class="cls-17" points="952.46 1179.49 905.02 1175 791 1340.63 835.26 1344.81 952.46 1179.49"/></g></g></g><g id="d"><g id="图层_2-5" data-name="图层 2"><g id="图层_1-2-5" data-name="图层 1-2"><polygon class="cls-5" points="2010.55 2194.14 1255.96 2121.63 1144.17 1909.3 1872.79 1977.53 1896.79 1945.22 1668.08 1450.73 1668.08 1450.73 586.72 1351 562 1381.91 562.34 1382.02 562.34 1382.02 562.34 1382.02 562.37 1382.07 562.31 1382.07 986.89 2123.67 1134.43 2381.39 1134.45 2381.39 1134.46 2381.4 2099.42 2472.05 2124.32 2441.38 2010.55 2194.14"/><polygon class="cls-18" points="586.72 1351 562 1381.91 1645.5 1483.66 1668.08 1450.73 586.72 1351"/><polygon class="cls-19" points="1872.79 1977.53 1896.79 1945.22 1668.08 1450.73 1645.87 1483.31 1872.79 1977.53"/><polygon class="cls-20" points="1255.96 2121.63 1233.74 2152.54 1101.57 1905.33 1144.16 1909.5 1255.96 2121.63"/><polygon class="cls-21" points="1985.88 2224.91 2010.55 2194.14 1255.96 2121.63 1233.74 2152.54 1985.88 2224.91"/><polygon class="cls-22" points="2010.55 2194.14 1985.83 2225.04 2099.42 2472.05 2124.32 2441.38 2010.55 2194.14"/><polygon class="cls-23" points="1645.56 1483.44 1758.92 1730.37 1758.99 1730.52 1872.79 1977.53 1101.48 1905.31 1233.67 2152.69 1985.88 2224.91 2099.42 2472.05 1134.46 2381.4 562.31 1382.07 1645.56 1483.44"/><polygon class="cls-24" points="2099.42 2472.05 1985.88 2224.91 1233.66 2152.69 1102.01 1906.28 1101.48 1905.29 1872.79 1977.53 1872.79 1977.53 1872.79 1977.53 1759 1730.55 1758.93 1730.39 1645.59 1483.46 1388.82 1459.42 562.34 1382.02 562.34 1382.02 562.34 1382.02 849.63 1883.89 849.63 1883.89 1134.43 2381.39 2099.42 2472.05"/></g></g></g><g id="c"><g id="图层_2-6" data-name="图层 2"><g id="图层_1-2-6" data-name="图层 1-2"><polygon class="cls-25" points="1246.52 705 1291.25 705.1 931.62 1213.55 887 1213.76 1246.52 705"/><polygon class="cls-26" points="887 1213.76 1012.54 1448.2 1056.94 1448.2 931.73 1213.36 887 1213.76"/><polygon class="cls-27" points="931.73 1213.36 1291.21 705.01 1404.64 952.09 1057.31 1448.2 931.73 1213.36"/></g></g></g><g id="b"><g id="图层_2-7" data-name="图层 2"><g id="图层_1-2-7" data-name="图层 1-2"><polygon class="cls-28" points="1291 704.73 1314.86 672 1930.84 730.8 1906.95 763.58 1291 704.73"/><polygon class="cls-29" points="1907.38 763.28 2007.03 1011.08 2030.56 978.51 1931.07 730.5 1907.38 763.28"/><polygon class="cls-30" points="1291 704.73 1907.35 763.63 2006.71 1011.08 1404.58 951.7 1291 704.73"/></g></g></g><g id="a"><g id="图层_2-8" data-name="图层 2"><g id="图层_1-2-8" data-name="图层 1-2"><path class="cls-5" d="M2276.45,593.3l-.1.15-.09-.21L1193.29,492,576.93,1361.19l-.57,0-9.57,14.36-2.66,3.75.06.15-.19.28,4,.38-3.74-.35,20.61,47.11,1083.2,101,629-887.45ZM982.29,1213l329.23-458.1,565.75,50.49-327.76,462.54Z"/><polygon class="cls-31" points="2276.45 593.3 2297.07 640.42 1668.09 1527.87 1647.48 1480.75 2276.45 593.3"/><polygon class="cls-32" points="1290.91 704.85 1311.52 754.91 982.29 1213 932.23 1210.06 1290.91 704.85"/><polygon class="cls-33" points="1311.52 754.91 1877.27 805.4 1907.66 762.12 1290.91 704.85 1311.52 754.91"/><polygon class="cls-34" points="564.28 1379.71 1647.48 1480.75 1668.09 1527.87 584.89 1426.82 564.28 1379.71"/><polygon class="cls-35" points="564.28 1379.71 1647.48 1480.75 1668.09 1527.87 590.73 1426.82 564.28 1379.71"/><path class="cls-36" d="M1291,704.78l617,57.68-358.49,505.47-617-57.68L1291,704.78M1193.29,492,564.13,1379.25l.1.22,1083,101.24,629.16-887.25-.09-.22Z"/><path class="cls-37" d="M1291,704.78l617,57.68-358.49,505.47-617-57.68L1291,704.78M1193.29,492,564.13,1379.25l.1.22,1083,101.24,629.16-887.25-.09-.22Z"/><polygon class="cls-38" points="564 1379.68 1647.56 1480.92 1659.93 1462.38 576.36 1361.14 564 1379.68"/></g></g></g></svg>',
        le = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 479 310"><defs><style>.cls-1{opacity:0.36;}</style></defs><title>资源 9</title><g id="图层_2" data-name="图层 2"><g id="图层_1-2" data-name="图层 1"><g class="cls-1"><image width="479" height="310" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAd8AAAE2CAYAAAAgS5gSAAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4Xuy9TZIjR5Kte1TV3IHISCa7ks1is6RaHgdVb8AccgGPm+B6KrkeboJ3AT27zcmtQV25lKZcoRSbTOYPAHc3fQMz838HHL8BROhXggwkgEBEZpFxeNTOUSdVhWEYhmEYl4N3vcAwDMMwjNNi4msYhmEYF8bE1zAMwzAujImvYRiGYVwYE1/DMAzDuDAmvoZhGIZxYUx8DcMwDOPCmPgahmEYxoUx8TUMwzCMC2PiaxiGYRgXxsTXMAzDMC6Mia9hGIZhXBgTX8MwDMO4MCa+hmEYhnFhTHwNwzAM48KY+BqGYRjGhTHxNQzDMIwLY+JrGIZhGBfGxNcwDMMwLoyJr2EYhmFcGBNfwzAMw7gwJr6GYRiGcWFMfA3DMAzjwpj4GoZhGMaFMfE1DMMwjAtj4msYhmEYF8bE1zAMwzAujImvYRiGYVwYE1/DMAzDuDBu1wsM47FARLTrNaqqu15jGIZxLGQ/a4zHTCO4+/5z3ui0CbJhGKfGxNd4lBwuunMhE2XDMA7GxNd4VGwV3X3+Ud85oB5Hda+vYhjGE8XE13gUTIpu+u233/bk9G/pCYzyt7913+hAMQZMkA3DGGLia9w8QXh3iW4S231oCfMJxRgwQTaMp46Jr3HTDIR3juj+53dd6Xz1zQH/EnzbFWQTY8Mw9sDE17hZRoV3SnTbgvsNxu7iu+9avzlEkP82IaAHCLOJsWE8bkx8jZukI7wdtzshut/Uv3QEt0tbfZvfvmoJ8WvswZQYt5kpzCbGhvG4MPE1bo6B8I653RHR/fqH77dK3adffj3xL8N3HV1+NcMVvx578IRiDJggG8YtY+Jr3BTjwnuc6I4xLcSR78Ivc4Q48br/wInFOGGibBjXj4mvcTOMj5pb8lQL75Tofg0A+P2//oM++tNXrX/wv8cUO0W4w3d49cNuMX499YSJsWE8GUx8jZuBqL3zEUPhnSG6AICvMOCj/zeK8f8ApsR4PyEGXn3TE71vu8+/xg7miHGfGeJsYmwYD4+Jr3ETHCa8XwPYLrp9uiKc+L7zmqNFGOgI8evBkxMcIsZTtP6WTIwN4/KY+BpXz1B4W+e8UXi/AfBzLbxfA9hPdPuMi3Cb7wHsL8RAT4wPEeE2pxTkEXS/pZyGYczExNe4arYGrKLwfj1LdL/C6qcfOkPZ5edfKvAf2MZuEQ58+uVhIlULcRTh19Mv3c2ZhXgbJtKGsR8mvsbVMkd4G8f79WzR7TNbhHcIMHAaEX69/aW7eUARbmOCbBjTmPgaV0s9bp4rvHuKbp9ZIvzTV7P+hTlWhF+3xtEHYyJsGFeLia9xlUwGrHYK7/6i2+aUAgwcJ8InEWDARNgwrhATX+Pq2Cq8+AbffDMmvMeJbpvl5x92/ktxcwIMmAgbxhXBu15gGJekuS4veqsjAeAbYC/h/RLrlzmt/5nvJcqrn+72ev0ufv5hTvt2yH9+d9jnTfLtid/vQAggmtVINozHizlf42rYHrAC4ZvU490lvF9i/fLvwx/u/wtYfLKZ/Q/8Lge8j/sFDnfA3/1w2OdNciUOGDAXbDxd3K4XGMbl2Ed4wyFvV3iT6P4do/wVWCOnfUXYOB8EkAmw8RSxsbNxFXTOeQF0k827hPdLrP+Z06jbHeOvwJxR9K7x8++f/8fO92hz6Pj5my8P+7xJrmT8nLARtPEUMfE1HpxdyeZp4f0Stdv968gbXwAT4NNgAmw8NWzsbDwow3PervCiJ7xdtzsmun9p3Z8YPwPB/f6vnHaNn1c/3dGus1/DMIx9MedrPBjjASvUlSL88D19PVt4/4LyF0flL/9o3Rx1xbjHTLds4+fLYO7XeEqY+BoPyETACt8Ar7YIb2fM3IguRmhEeJw5Z7/G5TABNp4KVjUyHoTOOe/rYbIZP4C++q//IOArrP7UE14AQXT/QV/Et/gHduNelqP/sC9+mZd83jV+turRabD0s/EUMOdrXJzBIo1esjmMmwNTwvvnlvACwBfxto0pB3xr7tfGz4Zx+5j4GhdlTsDq616yuRHev+DPvzj682DE/AXWLxwBX8wS4QE3Vj0yDOP2MfE1LsxEwGpEeFOdqBHecdFdv/iRAGD94kdKIjzFtvPfOVyLAJv7NYzbxsTXuBijlwhsJZuHlaIp4e2Kbp/1ix/p8xd7iuxM92tcDhNg4zFjgSvjInSEFwhOKwnvqyC8X+0U3i8wJbhT/PRmPGRl4asJLHxlGBfBnK9xdjoBK6A14twtvKlCtP5t2ukewmMJX50cGz8bxkUw8TUuwFTACtglvF/gC6x/c4R/777j5o1QugF/xhTnGj8/2rNfwzAugomvcVaG57zoBayAvvCmpRlBeH/sCG8juO3HftoqwuVv4wJ8bPjq1FyNAJv7NYyzY+JrnI3JgFU72fz5f1BfeAHgC8Tz3Si8Y6LbZ/Pmp9Hn/73nmnfyQO7XMIyng4mvcRbqc946LjMuvEDo8raF9/PW+e4c0W0z9dpzud9TC7C533HM/RqPDRNf4+R0FmkA3YBVT3hXP/1A65c5pQsgfN463x0T0uItU/GWdzjg4edtc7+jAjzT/RqXwwTYeEyY+BpnYCxgBcI3QL1Eoye85S//CN3cfweAPw8EtHjLVNwz4bPW73eIcJ9DwldzMPdrGMa+mPgaJ2U6YAV8/QOovURjILxIY+bm7LYvugCAz+ItPo8R9hlVA1Y9muTKBNjcr/FYMPE1TsaugBUAdIUXA+FN7zUqun2iCO/jgA9xv3ME+NG6X8MwzoKJr3ESOos0diSbk5iVv7iB8BZvfx6IbvXun1S9++feonLp8NWpuRoBNvdrGCfHxNc4msGVino7mxvhvSPgS+CvQejKvvDeM+GzRnUb0f0UwKeo3vG4CO/pfq16dPuYABu3ju12No6mO25uBaxeDYW3XqLxwtG/Iwrv50DxphHPRmA/7X+pGrn33X9w/2/4JXv+6eAf6PxFNXjs//wfwH1se5/3wvY+G8bJMOdrHMV4wGqYbJ4S3uL+Z0rC23G6n04Lb3pt54HP6l8GnKR6hHnu17gc5n6NW8bE1ziYziKNzjkvgEGyeVx4k2B2RPdToHz7C5V34Tb+1T8dFeDi7c+zfyAfEr6aw6nHz3b2axiPDxNf4yA657yjASt0ks1TwhvcLlNHdN92BXdahMfc8Xz3C+wfvro19/vYBdjcr3GrmPgaBzInYNUIL/6fLzAmvOOi+0nvFhgT4HH3+/jCV4e6X8MwrhMTX2NvRgNW8dq87YBVI7zA5//9I23uh8I7JrrVh197QtOI8FCAx8+Gx8bPp3K/p+JSAmzu1zCuDxNfYy+G57wYBKxWP93FLm/c1/zfjjZvJAarPkP1jGvhDe/aiG4S3vb9hsYFtzln+GqUE7lf43SYABu3homvMZvpc17UAavVn1KXt1kbGUbNoaNbPWNq3G5LdO9+JbwE6ltkKMDHud8ppsJXk+7XwlenfT/DeGKY+Bp7EIX39TBg9VVMNjeVon9Q2RPexu0G0f2XD7/Sv9z9Sp+8BD7pKO/Ljgh3Bfg87ncbjyV8dXKuTIDN/Rq3hImvMYvOOe9IwGqsUvTZhPAm0Q3i+hLle6by/a/0cbyFr9gS4RHG3O+x4atDqkdzBPjRul/DMA7GxNfYSfecdypg1a0UTQrviOj2v97H738l33t81P0Ops3bF3O0ubbw1aU4uQCb+zWMgzDxNbZSn/NOBax6yeZx4SWqPkhwuwPR/UO8dWkeeTk5fu73gQGrHhmGcRuY+Bo7GA9Yff0DaL7w/kqfvByKbrViqha/UbX6jaoVU1+EfWcEPc4x4atLu99rEWBzv4bx8Jj4GpOMnvPGgFVdKZotvEPRxcfxC30cbo0Ip1e2BPiC4au99z7PdL/G5TABNq4dE19jlMlz3h++p6/+6yNa/Sl0ebvC+zNV7/5J5Z1Q+ZaoumP6eJncbl90/yXeWkQRHhtD7+t+xy49eIrq0SRWPTrt+xnGI8fE1xiw65w3VYrw178A+AKfvfm/UXhdWBeJT1DdcUwuD0W3WjFVqzfxxtQX4Wr1GyUBPtT9DsbPe7rfbVj1aIIrE2Bzv8Y1Y+JrjLDrnDdViv5Bn7/4kYA/AfgM9ai5LbyL3wgfJ8ENotv/ao0IRz5Gh7HwVZ9z7H0+xP3OEeBH634Nw5iNia/RoT7nHVmkMRawqpdoPGNqC28TpmoL7sfwaya/nhLAxgG33S/QDl/F50fc79zw1RiXDl+dmqsRYHO/hjELE1+jZlvA6qvPP5oOWHWEl4KLjW43vHMU3cXvhBcAXgB+MRThjiv+OAlwYE71aIxj3e+tVI8Mw7gtTHwNADsCVnsJbxozv6GB6PaJItx+aDh+HnO/+4Wvxjhr9cjCV6d9vyMx92tcIya+RqR9zosQsHoVk81zhXfxG1WLMGbuiu4LVCuiakWjPwT7Atym734PCV9dvHqEee7XuBwmwMa1YeJrTJzz9pLN+Au6Xd4R4V1xcLsLJrxALbjV6vf6B982EW5eM+1+G/YJX03tfbbqUeKxu1/DuDZMfJ84uwNWKdkM8m3hvRsKb3K7fYH1m3eDH8ThNW+b1+x0vyPVo/T8wXuf57vfbZj7neDKBNjcr3FNmPg+YTrnvDsDVj/Sv44KbwhYtd0uEATX50w+Z8Lzj+BzpqEIf4Qpjq4enWHv8yHud44AP1r3axjGJCa+T5TuIo0ZAat7mRDeN+QXXLvdJLofPR8R1hER7jjkgfudUz0K6mvVoy5XI8Dmfg1jFBPfJ8ueAas324UXAJLofoTgfO83RPcjI2eMCXOkLcDzqkc4Ony1j/u16tHtYwJsXAMmvk+QOQGrfrJ57X/lrvBSLbw+f0f3OdP95l1wvhsi4Hn8as8xJsJT7rePVY8a9hVgc7+Gcb2Y+D4xps95Qb9/Dlr9BFq/BJW/dStF1Qephbf47S2nYJXPmT7CR1FMnwN4jip7R1X2jmr9BRBEuCXAM91vn1PsfbbqkWHu13hoTHyfEKPnvHXAqpts/uzjRnjXP//GHy85CK++5Sp/S8Wb9+xrt0tUbYhq0Y2qW637Ivy843h93h4x7+N+x7Dq0Rjmfg3jOjHxfVKkc974g/A/QVPJ5naXNwgvB+GNbhfPP4pONjhd3AfX6zdJKJ+jLcJJgD/q2uEOh4SvHrJ6tO/4+dbc72MXYHO/xkNi4vtE6J7zYnvAqpVsLvQNB+F1nM53/YbpfkNUZeHmN0x+85785j0BQPt+PYpeN473fsL99mnvfp4Xvpra+3ye6tGthK8Odb+GYZwPE98nwPg5bxOwWv+zm2xe/fTfnIT3xYKpWv2hPt/1G6ZnGdXj5Vpk7++hGRHu7+uv2xVhBIcMYDB+ngpf9fZBd8bPAOaHr/arHp01fHUiLiXA5n4N4zyY+D5yps95m4BV+YnrBKzKuz9SdccUhDeMm4PwEj3LiNJ42W+INIu3KLK6eU99EQ50x82duNUh4asR93tt4atRTuR+jdNhAmw8BCa+j56e8NbnvK2A1W+uDlilStHzX95wEF6JwSqiZ9m7esQcRDe52vt4a33VzftagNsj6En3mx9fPWo4T/VoiqnwlVWPJrgy92sYD4GJ7yOmPufdsUijI7wfJAjvoiu86Wy3Hi/jHr4gCrf38RYeT4wLMGoT3A1fdd3v0XufL+h+t/FYwlcn58oEmMz9GhfGxPeRMrpIIwnvn+6ofc7bEV64rvDmSXjf1+PlJLh4BuDZPcLH8HUbEZ6iG76aqh6dde/z7OrR/PDVIdWjOQL8aN2vYTxxTHwfIVOLNDoBq0+C8L6sfuHqXVyiEStFfhEuiHCfE1VrIh/PdZPTxbN7eMdxBP0hOGJ0RTg54Cn3m8bP/erRafc+x+cPrh6Nc23hq0txcgE292s8YUx8HyUzAlYvHL38r1+4eudojbBEY6OO/YKp8MId4d0k0UUU3Q9Ua2ykEWEAz4IDrr+bzXvqngl3BXf25quTVY8+seqRYRgPionvI2P0nHcsYPVGqHruaI18VHiL3z9wpR+4eveBffaektNdFkTLIojyMgv321+/WbIBdAT3Pj1/purRre59nsm1CLC5X8M4DSa+j4it57y9gNUK/83lnZBfMm30XRTe97Xw1mPmnuh2R8vh/lCE71vutzV+HnO/dfiq/dQB1SNcf/VoVIBnul/jcpgAG5fAxPeRsO2ctx2w2uCfHLq8QoVm/GLB5Bd/CMK7eTEQ3mXxoRZdzYi0aG6db6AlyH7zoX6uPX4eut92+OrM1aNjwlc4TfVoEqsenfb9DOMGMPF9NEyf8wJfIp3z/uv9n2OX91N60Vobeb95QYX2hZdIM6YkuoOv2BPhtvv1G6a54auLVI/S84eEr/Z0v9uw6tEEVybAZO7XODMmvo+AwTnvl+1z3niJwJRsfsZU3X1Kz6s3nNZG3kG4Ft6sLbxEwB18sYqCnG6rzg+mWoCfte4neuGrIVdQPTpD+OoQ9ztHgB+t+zWMJ4aJ741Tj5vb57ydKxX9nVblj/zZvVD17HNaV7/xx++JqtUfqNC33BXe57Tc3NOyrhYF0cXdHdStSIskunfoi3B67q4zfh6Grx62ehTUd8z9zg1fjXHp8NWpuRoBNvdrPCFMfG+Yzt7mOmD16TBglS6W8Jbo4/ef0EZ/5yS8VUak2XPy2XPK3624wpqr92vuim5wwMAdtOiLcHM/cXD4Kn3G3OpRS4DnVY9wdPhqH/d7K9UjwzAuj4nvTTNyztu7UtEGC04XSyj0DQfhDdurqoyo0g9c6orzd6v6vFcdUVt0vVtRV2Tv0Bbg+rtpjZ8T7fBVh7Hw1b7Vox6Ponpk4avTvt+RkLlf40yY+N4o4+e8oK96izT+9Z5p7YULfcP3scvrc6alMlf6gX32vBkzuyC8vow3B/IOBCwBLAcinATYu6EgznK/gysfYTx8NdP99rmGvc97V48wz/0al8ME2DgHJr43yPQ5b1qkkQJWWQxYMb1YvKS0RCMJb6nCua5YY5hKCyJfrgjLJVSIFsWaFsWatFjHHz6NCIffN67XRyHe6n4nwlfj1aPp8NV+7neMI6tHn1n1qM1jd7+GcQ5MfG+MOee8TcCKaV0JP6/ecKFvOQjv+1p4l7FCVOmaqw9r9g4URJdoiWV0tEsssURfhJMA1+Pnu/b4OTy2zHrVo5pDqkddDglfnax6BGAf9wvsP35+8u73ygSYzP0aJ8bE9+bQ8KF1zttfpBECVo7X1W9ReB0X/n0UXqmFt3q/5kqZvaNadPOSyLs1eReEtrkfRLgR4ETL/Y444nnVo274ao777XO6vc/nqR7dSvjqatyvYTxyTHxviPqc93X8GM95f/8clK5UtMGCV/hvXuM3Ln9xXOj7KLzClUp9xlu9Z1b3jLwDaXFXi646Ii2bWxg1NyK8BKIAj7hfDN3vvOpRen68ejQrfLVt7zOA+eGr/apHZw1fnYibFWBzv8YjxsT3Ruie86J3wYRuwKq8+yP5JdNHC6Zq9THd5y/IZx+FOpGuuFJmdRSFlyiPQasgtgCWy/rrarnuiHDzMeDLFXXDV6evHh2993nE/V5b+GqUE7lf43SYABunwsT3Bhg/521fMKEJWK39r3WyuVDhEsKFDwGrWniLILzZhw3njigJrEq8FWtSIeqLMBAccDN+Xva1GLdSPWo4T/Voir3dr4WvTvt+hnElmPjeBFvOeXsBq+ruU2oL71I/ROGVWngrXXOmm+B+VxtWIcJiAa2ItGrEbCjCjdIOx8+nqx7tDF89P/He5ytxvxa+ug3I3K9xAkx8r5yd57y/OPK9gJVfMJX4EIT3GTfC64Lw5u6ucbouCK5WG8IifM0xEQa67nfE8mIsfHVI9ahhbvjqsL3PDaeoHs0PX1n1aE/M/RqPEBPfK2ZwzjuySGODBf8hBawqF5PNEgJWaIS30jVX76klvEvSisiXG/KCcCvDx7YII/5GhaIAUy3A+4avDq0enWvv82mrR+OcKnx1a+73sQswmfs1jsTE90oZPedtLdJ4h39wO2BVwoVz3rREA8xVS3i1uKPcEXndsEccOQsIixxabkjLTSNeLRHWajPyQ2Y8fBU4rnq0K3w1e+/zyapHn1j1yDCMk2Pie7X09jb3L5jQC1h9tGAKlSKOgiucY82VrnlR3FGGDXvdsFZBdKvVhrUkyoVosVhgsVgg1Iu6IgwkB9x2v+3w1X7ud1f1qH13zP3ODl9tqx7d6t7nmVyLAJv7NYxpTHyvkPqcN/2w+RKETsBqyZ/dCwXhzepkc+jyxgslYM0VmDNlrhBCVeqW5AUURHdDubQ7vRvKZUNJhOtvZjH6LaLtftv+9yaqR3jc1SPjcpgAG4di4ntlbDvn7Qes+snmtL1qgTB2zhbMWhJ5MFcgrlYbzpQ5lyZklW5BZRfQckOLRetsd4b7xY7q0ay9z+iFr/apHuUPVz0aCDD2qx5Nha+sejTBlblfwzgUE98rYvs57zBgFVZHpkoR18JbFBvJFnGRBpgbt5tElwj5IghpvgDyBdoi3AhwGEF72UQBjiPpPatH7b3P9etb7tdvmBpBPqB6hIerHg3Gz3u63208lvDVybkyASZzv8YBmPheFa1z3t4FE8YCVoU6DpUi5uoZB8er0fG6O/KrILxeC85QhNGzbEgFpBUIyBvRbYlwEuBm5pzHuzH5fKLq0a7w1ZDzVo/Gwld9hu73+PDVIdWjOQL8aN2vYTwCTHyvhME57zffoH3O2wSshAsVvke3UpRt1lIpc6bEXpm9brjSOGaulqRC5DcFa0WkUoRbVcQ+bz6aau643zK53/74+fDq0a7w1aWrRwBmVY/mhq/GuHT46tRcjQCb+zVuHBPfK6AW3rFz3pc5lR/9hdIGq7A68ncu0FSK8juKCWfiUgpRR1StiHNZxpWRIK0WpIxwK8MNeQ7kgFZFI8Aj7jd8zBsjPGB79Whb+Eonw1fx+VNVj1oCfGz1aIxj3e+5wlendr+GYZwGE98Hpg5YTZ3z/uJo879/4rDBSppk830YMYclGsSVEmfLGKxS4gwFexTsN3HczJsosMHpAoj9XlAjwPFcN2/OdxetcfOc8FV773Mjtomh6N5NhK+2V4/Ou/fZqkfbMfc7Dpn7NfbAxPfB2X7O2w1YMRcqXGxWUilzsVlLdcdcbjaSLZnLYiMqRJkWrLIgleB2/ToIsJOCshxwUgRHnES0FuAkVsnixvAVWuNn6Y+nx8NX6d6wejQUxP2rR5EZe5/b7A5fBQ4NX52zejQqwDPdr3E5TICNuZj4PiBj57zNBRO+pGHA6m1INkO42KwlRxReBOHNtOBMmbVakNeCg+guyAmRq5qks1ZEGYCsJbhJgEfHz9ILX6HtfsfDVymU1ShxK3x1qurRZPjqePfbsE/4amrv8/HVo0msenTa9zOMC2Hi+0BMnfP+Hs95V+WP3A9YrVcrWSpzeSecg7mUjWR4Fj5qwSpL8ijYa3K6RLIpWAVU3+rxchThjuPNu+PnFvtUj3y5I3x1NwxfXXX1KD1/8N7n+e53G1Y9muDKBJjM/RozMPF9AAbnvK2A1W//8+9c/uJ6ASvm4nlINhduLQswV0viDMx+QZwpswezR8Fa5uTB7KoYtJIiut2QbkaeoSvCRXS8UVzbYnxQ9Sgt2phXPaofm1096oavHrx6dIa9z4e43zkC/Gjdr2HcICa+D0LvnHdkkUY7YLXO3ku7y1vIRlxRiF8wS1GIRxgveyUWlOwE5EGsFRGyHOCQZk6Bq1qEY8o5Q2/8DGCsftStHs0JX21xvwdXj9Lzl64eBfW16lGXqxFgc7/GjWHie2EG57wjizT6AaulMheblWQbJ0WxkUyfsQezFCxhzEzstWAneRwtE4ERbhUIyBB+X7SENQgwEAW043hRj5+nq0c4S/Vo//DVpapHODp8tY/7terR7WMCbGzDxPeCjO5tHlmkUd79kZ7D8erDO8mzlRSblWSukLS9qioLES7Egzi4XWYBsd+UrEoMDgKcEs3hVvZEOAWnwg8Il8QWI+63FuDzV4+mwlcdrHo0/uew8NVp388wzoiJ74Wo9za//pb657zpSkUvq1947YXvPryV4oXjOwhX+oLzO+FK71lkI1Up4nJijyV7LVjAIVClZS26HiXXwhu3WQFZK1iVHG/R6vimhRvJ/Y6Fr6b3PtdM7H1O9/p7nw+uHt1fonp03N7ni1ePMM/9GpeDzP0aE5j4XozxCyakgJV/I1Q9+5wKfcMFHOerlWzcStxmLeVGpC28VcmSHK9HwarEWuW16LqKyFUFufb6SElCW4YfBpy2WjXjZxfHzwDq8FVyyLvCV7X7ndj7XFePavasHk3sfZ5XPWqPmPdxv2NY9WgMc7+GsR8mvhegc87bW6TRXKmotcHquXChL8L2qru0r/mOu8JbsgcxuCW6nJNoycpE6ZYhiyPl5GQz1CPo5HjRnPG2w1ezq0e9vc+D6tGu8NVY9ShrBaT22Ps8Xj3qckj46iGrR/uOn2/N/T52ASZzv8YIJr5nZnDO27lgQlikkQJWd+/eynq9kny9ksKtpShE3GYjpRQiZSFVWYpXYpZSfEasWnKqFYmWrBVIfXMDAOWSkLUEWFoCnLXHz93wFdC43/nVo/h5/eoRgL2rR2g54cTJqkdd/Hrf8NXU3ufzVI9uJXx1qPs1jKeIie8Z2X3OGxZplHd/pOcfp53NH4erFBUbKWUjZSlBeKUUyRbMUopqyb4qRUAsGhywCkhRMZgITIQMCALsaqHtCnCk437DD8+t1aPe3udrrx7NCl+9QIfO+BnA/PDVftWjs4avTsSlBNjcr/HUMPE9K9vPeUPA6tcQsFLHTbLZSYVn7MpSSimkEhHRBVdVKarEAmLHREl0wUSoiLQC1We6FRGyDCol1QKM1O0Fxt1v/K63VY96e5+PqR4N9z6fvnrUiVsdEr4acb/XFoLqVR4AACAASURBVL4a5UTu1zgdJsBGGxPfMzHnnDcErDIuXjjOV04qFc5cIUWxESeFVIslOxHxSlxJEl4O1+sFMZhIN8TKiOe+JSFzCCIMQhJcHwWYSwpS24yfAWBW9Whi7/Mx1aPhJHp+9Wjn3uczVo8azlM9mmIqfGXVowmuzP0aRhsT3zOw7Zz3HZ7xBv8MVypKASsvHJLNTiq9ZycipbC4UuIZL7eEt2QFsW4qVkbY31xU7KoQrlIf+r1BVx0Q3W0QYABZs9kKQBO+Qtvxxs1XM/Y+H1o96o6f968e1feB/cJXz0+89/mC7ncbjyV8dXKuTIDJ3K8RMfE9C61xc++cN1yp6M+0Rh4CVlkIWJUqXLqNiGykLFlcWUrFhSTh5aqSqipFQVF0MxIEAVZGcLwMclVwt+qJlIPjRRpFx/FzlsR24H7T+Hk6fHWq6tGQYfiq637D87uqRw1zw1eH7X1uOEX1aH746pDq0RwBfrTu1zCuFBPfE0MEGu5tBv22/juHRRrhSkV1wEo/5sI5yZxIWUjo8kopFXNHeEO6uWIBsRRVcMBVRr6oWH1ri1UU4SCfqVYENO7XARnq8BXQcr9nqh4142eqBXjf8NUya7Zj7VM9Otfe59NWj8a5tvDVpTi5AJv7Na4QE98TMn3OC0qLNNb+V36uwp2AVbGRcrMR50SEOQpvJb6shDkJL7FbZOS1ZOUs9nhBcA5w4Ty3vcUq1I7Kwfg5PNcaNZ+4ehQ+dqtHXc5XPdoVvpq99/lk1aNPrHpkGMYoJr4nYvs57z84LdIoNOPV6p2EgNULzpyTUkSciAiHShFXlfiSRbKcPXKWmHD2BYUFGigZPiMtK4YnQh2oQqgYVeHMd2z83A5f9bu/AEbDV9urR8fsfZ7rfsPn7qoete+Oud/Z4att1aNb3fs8k2sRYHO/xmPHxPdkbD/nTYs00garjVuJc2sphCUFrKpKhEsWzXKWjNhXlUhVia8q8VqxIoatmIhRsouOVz0RfON46+9o6/g5Pd5KNXfCV3OrR4mmcrRP9ajtf4fVo3nhq4tWj3D91aNRAZ7pfo3LYQL8tDHxPQGzznmR893iQ7PBauOk3Ii4oogBKxZmFs8UnG/FIiCux8xRdMWDJG2v8iWJByURrgWYS2rOaR0G4+f0+JzqkYSvda7qUbP3uV092nPvM3B49Sh/uOrRQIBxmurRJFY9Ou37GcYRmPgeyc5z3vt4zgvHhb7k5X0KWG2k0MKVwuKkJbxcieckvBScLioWDxKE0JVqa5NVFFcHBzggjaCBIHqNwE6439bmq/A5veoRkss9rnpUv2ZW9ag1fm7tfa5f33K/fsN0VPUID1c9Goyf93S/27Dq0QRXJsBk7vfJYuJ7BKPnvP/1EXXOectwzlu8iAErtwrJZhERYRGtXMWlVFq6tuOtqBJ1xB7hvFe1Crubk+CmRRpcEZyLLrgkuCic3Bo/j4avwv2x8BWAcN1fpPHz8dWj9PtTVY92ha+GnLd6NBa+6jN0v8eHrw5xv3ME+NG6X8O4Ekx8j2J4zvvqT3fdc95K+F4/4fXKSbFxkm2clJuwQMOxhGRzxWHUzCziovCCmP1aRCv2WsXRc8XwqK9YBARhhQ8CXI+Y4/h5NHxVj50nqkd5cr/Arr3PjfvNO+4XOH/1aFf46tLVIwCzqkdzw1djXDp8dWquRoDN/RpXgInvgUyd84YLJrTOed+9lXX2XhZuJYVzsvGFE5ROmKUqKQivVs5zEOCqIlFkwe2SI+WM4B0pKlamILL1FYuIwoTZAb6i/vh5NHyVRSGdqh5VU9Wj+D61+81b1aN4HnyG6tG2vc86Gb6Kz5+qetQS4GOrR2Mc635vpXpkGEaDie8B7DrnDRdMaBZppIBVJpuQbGaWUktHqJwwi2cOZ70uY/aVCKrOea9HxeEKRQL1caNVGgt7IqXoVNvj5ySmnfBVeH17/Hx49Sie9560erQcuN+GXdWjD63Xb6senXfv881Ujyx8ddr3OxIy9/vkMPHdk7Fz3q9657xrv+C7D29l9SGTPHOSNli5Iu5slrC9Spil0soxk/iKhH0lKqFipKjYlxULOxJGvBFJSjT7RoDTGXBn/MwlDcNXc6tH03uf2/eb6lETvmoIrncBTO99HnG97XvnqR5FZux9brM7fBU4NHx18eoR5rlfwzDOg4nv3gzPeVd/uqP1yy+pfPEFpUUaTcBKYsCKpZQ7Ea0caekqrVzFJEF4K2FHrBLcrnfEDLCway3SIFIPggOEiRwA9RXBg9RX4+Pn2v22/6t6TvUIo3ufw+PhvdxE+KpfPVLpha/Qdr/j4asUyjpr9WgyfHW8+23YJ3w1tffZqkcJc7/GY8LEdw8G4+bOOe+P/LL6v7x+Ga5UtF6FUbO8+80VvnCshRMtHddj5kU4660qYZexr1i8J2EQS0kMIlKtWAmkBIIkYQ3JZeWKAGnOd9thKhfdbqv7CyT3e6rq0VT4CtgavtpRPfLljvDV3TB8ddXVo/T8wXuf57vfbZj7neDKBNh4Opj4zqQZN4+d8/6F6gsmVMzrLJOFC+PmenWkVq7UylVrdqSVC8Ib+72VFwWYUbEqBcGtqOnyKgXBJRCooqC4DhLFOIktHOrx8yB8daHq0ba9z4Ft1aO0aGNe9ah+bHb1qBu+evDq0Rn2Ph/ifucI8KN1v1cGmft9Mpj4ziAIr2455/2J1/7XeM77Lmywck4yYRE4x750FbMIkxAqJxVLEN4qXK+XK2GEiycoqhC0IkSXC4IImoUaQYDVlwQXhsvN+LklQCPhq3NXjwbhqxbd6lES8jR+Tp9/yN7nfapH6fnx6tGc8NVh1aOgvlY96nI1Amzu13gATHxnMX7O+w7POhdMCOe8MWC1ERFfupBsFsfKjtS7JmRVhZAVk6hmrORFQewBTgEr5STA0eFyFX9IOIQz4DKc96bxMwBlojp8lV57gerR6N7nyeoRzlI92j98dfze53nVIxwdvtrH/Vr16LYhc79PAhPfHWw7502LND4sf5e7VS7rlZPCrcRp4dLqSNHSsVaO1LsK7ILwsngiYZeSzWAPMINYPJESkfqQbBau6pFxEOAguhAgCGsaPwf3i/gw4JBee+7q0WDvM4CHqB5Nha86WPVo/M9h4avTvp9h7MDEdwudc16gGTf/BCo/iue8yEPAKl/JwonIu9KVIsJaOtHKEcQxs1QI57xJeMmHqxUpiMlvROAZjLBMo6pYUXE4Z3UIItz64aAx+eyb8fP28NWB1aNsd/VodO9zPha+Wkzufa6Ztff5BNWjueGrme63zyn2Plv16GlD5n4fPSa+W2md834J+roeN/+DP/nfP9WLNNbZShbOyVo3rpR7YRUncI6UHWvlKmXHlEsjvCRK8UIKsV6k5Eg1pJxB6Xy3Cl1eAdRXYRTtEV0vAEE9fq7DV2n+PBa+2rd6VG2vHu0KXyXR3hW+qt3vIXuf51SPTrT3eT/3O4ZVj8Yw92s8RUx8J6C0PrJ1zvszfuB0zrv61PFzFV59yCRfZ3GDFYsgOl6tXKXiqnjWy/CuUu+o9E7JCwNhhaT3AnKkVcXKIFUhVVD4H4VxsjaiWp//JvebhLiuF1WU3G/9h4nhq5NWjzqPHVE96u19HlSPdoWvxqpHWSsgdYK9z20OCV89ZPVo3/HzrblfE2DjVjHxHWHWOe/vv8sqfydhkUbYYCW+dKziShVXIbhegncMdp7Sgiov5Em896JKrCzEqFjIhTNeqkgJpBqDVEmAuSL1RM5FtRUAGoW45X7D+LkR4nb46lTVo2H4atr9zq8exc/rV48A7HS/O/c+46i9z93qURe/3jd8NbX3+TzVo1sJXx3qfg3jVjHx7THV5/1t/XduXzAhLNJoVkeyFq5QcWUWAlbsJIydXXS86l1YouFCslkck/fC8CEIjeh8PZGDgxDiIg0AEitGHIJVWo+f44h5Mnzlmj/Ytr3P7eoRp1oR1eGrdvUoCHBk3+pRL3z1kNWj9t0x9zs7fPUCHTrjZwDzw1f7VY/OGr46EZcSYHO/xi1i4jtgvM/bvWDCv8ZFGiLZ5iMpvLgil7DBStkRwiINQuU8ZcLxnJfZSxo5sy8EDFJFuFavB2m5CaGr6HLFI4yg69qQIPrXOH6uaBC+Sq/bUj3qh6/C69Cc76ZKUhw/J/fb7G8+sHpUc1j1qO1/h3ufr6N61GHE/V5b+GqUE7lf43BSudF4vJj4thg75233eZsLJryT3ImsdeM2fhNXR4qjLLndIMBewnkvMYkyifcxbAViJSEFMZQISpS2WSkhuNYknhQFeHT8LOiEr+CgDNpVPQpvPa96BKT3TWfDB1SPJvY+71s9avY+L0cm0Xfzwlfoha/2qR6deu/zBMe43ymmwldWPZrA3K9xZkx8I7vPecMijVW+kjxzsnm7cZmwyKIMwhtdbwhWsfOahDcTX3pHPiabBfFSgcRMINKKOe1vDrHmWoA1XkAhCGtwvY3LbW5t9wsAV1c9mghfnbp61A5f1a+/5r3PF3S/23gs4auTYwJsnBETX/QuE5jOeT/vnfO+FL7LcymyTNZ+4+qAlRdHGTsqfVZWPivJZ6TekTTCy0Si5EWj6yUGMzwrPIOJtPLMviImhFWS6kmpWRmpPgawKIlrHD/33G8Q7V71aOve52H1aDR8Fd8gVI+64SsA11U9ckP3uyt8NWRe9eise59nV4/mh68OqR7NEeBH634fCBs5Pw1MfAGgPuf9W2uRRnPO+/7d73L37q2sVyvJNzFgtRDHKg5llZWlzyrHcYUkOwI5gndevWOqROHYkxfSsMVKKx/Gzl6CsBLi5ioQ++iAk6JyReI9DcbPHfeLMLpG82ndvc8T1SM/rB51wlcD99sNX4XPOW/1qBk/h4/nCF/tWz067d7n+PzB1aNxri18dSlOLsDmfo0z8eTFd845b3uRRuacsBdX+MIVXGWVsgsbMtiRUBBe8SFo5WN7iHxIOQvFzVVCqMJGq7BEQ2Ka2QcxpSCm9SjaSTu3DMD13C+gVBF61aNm7/P+1SMAQBbvT+19nl09ymdVj8LHbvWoy+F7n3UyfBWf36N6tDV8dbLq0SdWPXqCmOt9Ojxp8Z13zvvHZpGGc7Lx4gotHBdVxsqO2Gcgn1HlM/hNRuLDeS+881Q1nV6AAc+qxKw+nPOqZ3giaNUSYCL2VRg7q49iGsfPtfutWuGrtPtZMKt6lFR8ZvWoPX4+ZO9zcL/R8Z507/PQ/TYMRfduInx10erRre59nsm1CLC5X+MWeLLi2znnBcK4efSc950U8UpF4sXJonTMPqNMHNhnpOwY7MiFkXMSXvUkVKlT9gI4ViUmgDldrUhBrD6c81ISYKAZOffSzEk3W+Gr9DEJ7Gj1KH1SSk/7fatHE+GrTvWo54gPrh7hhNWj3jkvjqge1eGr9lMHVI9w/dWjUQGe6X6N4zDX+7R4suKL9jlv2ts8es7rJHciTp0TXzoqqow0BKzazheVz7y0hJe8qEgQXamYEVyuVhTcLhFBGKrxnNcTQREdrY/utzV+HglfJfc7Fr6qq0f+mOrRlr3Pc6pHEr6ea1eZzl492nPvM7C7erSecL+nrh4dE77CaapHk/x11wsC5n4NYx5PUnzHznnT3uZPOue8YZGGxC4vlVVGKo7KOGaufEZKziu5JLyk3kEbAWYQqxIrwAowKF65KCaTIYDW9SIipO1VTJR0tKZ2v4KwfKPtcrvhq8OqR0TJ/eoxe5/REs0UvjqielS/pr/3uTxg7/M1V4/S84eEr/Z0v9uw6tEEZxRgc71PjycnvvW4eeKcN1wwIZ7zOhHRjWNfOM7jEg2uMmLJwJxVxFlFmsFrFoSXnPckSiREJOrDRisAzIQ4Yk5jZjSCK9xMkwFAgoutk9A99ytJVOuRdDd8dXj1CKPhq332PgMI/4mBKLwnqB6l3/erR0GD51WP6sdutXp0hvDVIe53jgA/Wvd7Jkx4nyZPSnyD8PbWR/bPeSvhcMEEJxu/cRsfdjYXRZWVpYQbxREzaQbvMxIKwovQ6SUlCU6XmEmIYqdX4ZmJiBUE8iGdnAQyOd4YwOqOn1P4qorOuB2+mqgeMfUEul09Cu9R/8W0q0dJQLMomK3wVe1+MVE9ypP7BXbtfW7cb95xv8BTrx4F9R1zv3PDV2NcOnx1aq5GgM/ofo2nxZMS30Z4W7WisXNe52TtN0584WThQsCKJSP24ZZGziBHcYWkR9hi5eEdGFyPnOEZJNHtEmkUXNbkgKO4+ijKks5ue8Gr+jE04+caN3C/IXw1VT2Kfxu9vc8d91s1P2Tq8FUWhXSqelRNVY/i+4xWj2L46sLVo4PDV+kz5laPWgI8r3qEo8NX+7jfW6kePVbM9T5dnoz4EiUxaYT3Ve+c927xQdZZJtnva+e0cOKdo6LKUEqGFKwiyUCcEWsG0nDmC3Kk6pTCVYtINexvZsSzXs+qElwuEQHS7GyuRTZ8YF81rnjgftNZ7qmqR0AdvtpWPYpcd/VoOXC/DSN938nqUYt99j5PVY96PIrqkYWvTvN+p3kX40Z5EuI7uExg65x3g3/y27s3cvdhIYW+5Myv49WJnKOyysCSEfmMSsmIONwXdqRZPWpOwkvkxZMXZTBAzErE6cIJ8CFslUbOAIQF8Oic/3bGz7WIdgUaQCt8lX5x9cfZ1aN2+MpXdNTe57p6NL33uX2/qR414auGxe69zyOut33vZNWj+7b7jYyFr2a63z7XsPd57+oR5rlfYzuq5nqfMk9CfNE/521dn/cPuKsvmOB0E4R34WLA6i4km5kzYp/B+wyeM/JxsQaTI2ZHhHDO60PIikFM6jlcLtDHsFUQwkaAwwia1ddON323tZ4ijY+JeCJ8tVf1KL6+dr9p/pzcbzt8Vbvf9n+fz6keYXTvc3g8vJebCF/1q0eD8BXa7nd873MKZR1cPZoIX41Xj7qOtx2+2s/9jnFk9egzqx61uTb3a+Nm49GLLxFG10eGc96M18j5brWSIksbrFwdsKqTzeTDqDk6XxBnBHKVL7Nw3htHzkJhd7M2tSIQk6pn9RTSzm0BViKwIPzfIJhyv53xs2+HryqSQfgqudyR6lHtmoNLVq5ovHqEVvUocPLqUeux2Xufz1E9ypo/4z7hq/HqUZdDwlcnqx4B2Mf9AvuPn839Hoj9rRl45OJL6Zz3WxD+EyPnvMJ3i1zWeS65c8JFmQmagFXhfQ7yGRFn0CIHcTjnBbkKZcbkxCsJEwl5H9ZIMmLICqTwrExRGEHqfeOAIQDHJRtRkNvjZ2mPm9vhq/5jg/AVBuGrxkWjUz0Kn9+434euHjWj6EOqR2nRxp7VI7SccGLU/XbDV3Pcb5/T7X0+T/XoVsJXt+5+bdxsAI9YfAfnvK/GznnfSlik4UR85iR3jjgFrMJZL1RzLTQPzlczgnMVggCn894kuqirRcRMRCAKF1ConSmoVkKqSNVTfflAoBkRA1CuaHv4amrvM9WuODnfqepRO3w1Vj3atff5lNWjYfiq/m561aMk5Gn8nD5/+97n46tH6fnx6tGs8NW2vc8A5oev9qsenTV8dSJuVoD3xMbNRuLRii/Gznn/Z/+cN5N8LSKaOfbxEoFJdP0mB0lWJdH1nFXeZ0F4fQhYeRIlCCBMEKaO6wWTgoh8PWoGGOrRjJ89CBxGzkzx9+3wlUbhnHTB8Y86cL9N+CoZ27HqUXhG6k/uV4/qN26Fr8LrTls9ahxv+hwAmKoeYe/q0TB8dfrq0dF7n0fc77WFr0Y5kfu9WfZxv/NfaTwBHqX4UhjhYnDO+0k65/03vlvlkmcubrASR1xm4Cq6XZ+HUbPPQZxVRFlFPgM4bLICO1JyCnUEYiIvgGcN9d1w1pucbhJgCDSd9/rgYCGAxsBVJ3yVSPradr/qp8NXtfudVz1S3r33+dzVI9e+OMPk3ufjqkfDSfRtVI8azlM9mmJv9/vUw1dzINi42ejw6MR33jnvW1nnYZHGZiluLWVWFFUUXQkhK9W8c9YbR80Edl69IyIhBquSKIiJKVw8gUDqiTWukAzOlgH1VI+aCaHf2w5fQVCHr7ZUjzrBqTbJ/Ur6xdVnvFPVo/B50SWn891B+OrA6lG2u3qUnt+993lG9Wg5dL3D8fPpqkc7w1fPT7z3+Urcr4WvRpjhfk14jT6PSnxnnfPm4Zw307Vz6sJ1eWPAqiTJVH2uyjmgOTSc9ULLnOAcUZl5JkdE4n3pVEmYEWpFFVg9iKpQLQoCSrUDpjRqJtBg/Axg4H61qs+Cpf1LFO051SMAtZOdrh619j6n0fJY+Grf6lFVUjYavkrCuj18lUR7V/iqdr+9vc+pejRkGL46pHrUMDd8ddje54ZTVI/mh6+senRCLveVjBviUYkv5pzzfsgkLNLIHBVlVgesNIptulGWaRncbxBezbySo8o7hTpmYfJeVIkB4iBL0oyV+wJcj5/RjJp9HDEn99uuHqWz3Y773Ra+OrZ6hE71qP4rTXuf964e9cJXaLnfzmNHVI/OsPf50OrRufY+n7Z6NM6pwle35n4vIsBkrtcY59GIb3CWwOQ578t/47s8nfOWjhfhSkVgCWe76qPwci3ARBwunECaQb2j2OclD1Gvokz1BROUQrWoHiXXAuwpiW0YKbdHzYx++EoVNBa+mqweoffYIHwFjFaPeuGrfvVIuZre+7yzejQSvpKp8NW0+91WPTp273PikOrRrvDV7L3PJ6sefWLVI8O4MR6F+Nbj5m8xfc777q2sV/Gc1zu3KaoYsJKM8uR8o/A6yqBl0/H1minIEYmQqlMOe5sZ8UZM9Xlva7ys3gcRJaJ0lksEqme/bfcrLUes8Wy4dbZ7supRfW7cDV8N9z63JHxu9Yij422Fr9rud1f4qu1+T7v3eT/3u6t61L475n5nh6+2VY9ude/zTK5FgM/qfslcrzHNoxBfpHHzzHPecKUilxXJ8XqfQyQHNFfVcN5LVAuvh3dQdV7VKYNJSeqLJ0DDjYRS3LktwEFsOSado9DG0NXA/daPye69z3OqR7V4x1AVdux9RvykqLtj1aN++Cq8bjp8ldxve3/zoI40q3qUaCpH+1SP2v73JqpHeNzVo0fF30YE9mn9DRgHcPPi2xk37zrnXWaOuMyoaBLN4SbhI6eEcxo5awpYOSURUi+kJGhdrSjGpprz3fo+OmGqZuzcCl9Bwnmvj7uf6z/URPUITe6qdr/bqkc+ud+mejQZvsK86lGQ3LHq0Zy9z1vcb733eU71aLG3+232Po9Xj2btfUYvfLVP9Sh/uOrRQICxX/VoKnxl1aPtmOs1tnHT4htcJcK4ecs5b7hgQuZoU2bELtN4vku0CPfhc4BzUY4CrBmgmY+XDCQiIVROiUTVC8Ezg5gpnPOqtgRYqT7rDd8kiDwIYDTi7IkZzZar2AOe3Ps8o3rUmlAHavcbhdaPha+OqR4RJfe7O3wV7s/b+zyneoTJ6tHU3ud0b6p61N77XL++5X79hqkR5AOqR3i46tFg/Lyn+93GYwlfHYy5XuNAblZ8B7Wi+jKBX1L7nHdVrd1GM7fehGSz6ipPASutigVUcoUuQsKZMkBzgDOvUXjhnXp1qghXK+I4XdawVIOj2NbrIwlBUMFo3C+DyTfhqxismq4eSdDcPapHOuF+xVehelSPpMP4ue9+a3FvV4927X0GsDN8Fd/g2L3Pc6tH43ufG/c7ZHv1aFf4ash5q0dj4as+Q/d7fPjqkOrRHAF+dO43vou5XmMXNyu+6JzzfkpffZ4uE/gjrz51nM55nc+dLMXxQlzBLiOSDKI5RHInnENip5c1BxCFlzIicgA5D43Ol0QJ8TKBYCUOAqfB0tYCrJ7AgrpqpKAQrEJMNAua6lEUnkH1qKrdr0ZxPrR6NBq+6rjfJPhonRmHZm947UT1yA+rR53w1a7qUY7GIc+uHuUd9wucv3q0K3x16eoRgFnVo7nhqzEuHb46NYcK8OtdL+gz5noNYyY3Kb4UhA3dc96PeVUu+eM3b+TD779LOud1WsRFGi6e80oOlVwrDa63KheISzU8ae6VMkAzqGbKYZOVB0K4SlU4dXpT0EpBqrFipD66z9b4mYHwHIgljpDbZ7k7qkfA+N5nVoyHrtB7rDGpEYd+9SgIdrd6pP7w6lEGAFm4v//e5777zVvVo3gefIbq0bbwlU6Gr+Lzp6oetQT42OrRGMe633OFr07tfg/lP491v/GzzfUac7g58U1usV0r2nbOyxqvVOSrkGpOlSLhXEkXYI6u12WIwksgpyBHnkRBAlUhBlMMWRExkYLCoDiMlZV86OfGM9pGXKNgskB9FN1+9agOXwX3q74a7H3uV48gwGHVoyZ8tW3v82j1KKn4juoRAKinzvj5kL3Pwf3G896TVo+WA/fbMBTdu4nw1fbq0Xn3Plv1aDtnd79913vQVzOeMjclvtPrI7vnvFKtndxlDhwCVojJZq10odAFSBeo4jlvWiMJzQGNCzU0AyAKdaSIO5xDtQgEgg+dXtJULYp93uhcNSaba/cLINWLuuEr3wpmVfW5sYzsfT5d9Si43vRxa/UofVI63/W7q0dalbv3PtfVo4nw1QHVowUwvfd5xPW27w2rR0NB3L96FJmx97nN7vBV4NDw1TmrR6MCPNP9XgvHul9zvcZcbkp8MeOc94Nu3Nrnbr0us00Rk80+jJohkqvXhZIuODlf5RzgKLyUAeSUSQjqQCSqKqokHKJBpPVFE0LCWckH0UqiqEroh6/q56LjrcNXIDCjdr8UhbkOXyVhHu59Tn8jtZ7Orh5VNLt65OdUjxza7rd2sphTPcLo3ufwePh6rn0VpS3VI5Ve+Apt9zsevkqhrEaJW+GrU1WPJsNXx7vfhn3CV1N7n4+vHk3y110vCNyM+zXXa5yAmxHfIFDAznNezZxT56h0GcfVkUrFQskvpIpj2zmhzwAAIABJREFUZq8L+CoIL1ULIKacvWaaEs5EAoDDuDmc7xLAnESVNIijpqYvEXwQVK7TzN3wVfiD+OB+B+GrILSd82BI6AFrFOdUPYJg1P2m++ypPaEG0HK/Er630eoROu43fF50yel8d1A9wpmrR5hVPQJ64asd1SNf7ghf3Q3DV1ddPUrPH7z3eb773cZjqB7t5X5brzTXa+zDTYjv2PrI8XPeLPR5ucxYwnV54WLAiuK42WPBzKFexJoDkgFVThrSzYA6VRJShISzV1EFA1w7WI6CqURNbQgIgogolLFSlMJXYDTVI03hq/G9z133SxQOeHlH9ag7dt5WPUL9ScDo3uf0Z9m3ejQSvhrufQ73j60eNaPoQ6pHadHGvOpR/djs6lE3fPXg1aMz7H0+xP3OEeCrd78TCWcTXmNfbkJ80Rk3T5/zsnuTkcRzXudzOJ9rmc54sVDShRIH14u4xxlVDlAG0kxZHQGOQKJQ0fD3wyAm9Z5VleGVlZIwxhv5llA24SttP18LNoIQb9n7PF498o2QjlSP2Fe0u3rUD1/1q0fJOVNPoNvVo/Ae9f81I+GrkHSm8eoR9q0ehR+eIXwVHXE/fNWiWz1KQp7Gz+nzz7f3Objf9Pylq0dBfa161OUgAf7brhfAxs3GUVy9+A7GzfU5L+I5r6vPeTc+JJtVqxzqQp1IJFfiBZMuAF4wdAGmHJRCVpSRxgsnKDmFigbXy6QqREwEjWskmRQg+FAxCuGq4GSb388JXwWHS8nldqpHIZi1b/VIFTOqR2jGzzWu5X4Rv4Vt1aP4mpG9z7X7rZofS3X4KotCunf1KL7PtvDVZPUIZ6ke7R++ulT1CEeHr/Zxv4+9evS6/0Db9ba+A3O9xiFctfjWwvstCF+Cvv4BtPrpKwrnvD/Lh9+dvK8+uEwzx0WZkbgM7DL4sK9ZSBeq5RIx4aweYdRM3BFeMDkoOSUIEQmRhsNVYgKUoUxErXEz0Aik+iDAhMadJlFUpeRqUQtvMw4Of0g/dL8zqkeDvc+CLdUjtM5y++53XvVozt7n0epRRE9QPRrsfQbwENWjqfBVB6sejf85bix8ZRjn4mrFd+yc92f8wO/wDw7nvMK5f+/SBRNYsoy8z6Euh5NcyS9AEpLNhAVIgvv1WKhWCyhyADmIYshKHby6UClK1SLPSlxfp1dJW+NmongSTEE4g8MdhK8oia1vFm/EM2LQ4dWjOXufO44XaI2RU/gq/eLqj1PVo/B5u8JXY9UjOkn1SDvj6eR+x8JXi8m9zzUTe5/Tvf7e54OrR/eXqB4dt/f54tUjzHO/V03ruzfXaxzK1Yovdp7ziuSZk3DBhLS9yuVKfqFlqBOFTi8vVHUZ7+dgyqFBdEm1Fl4lCJiYiJmQxs3E8BoqRvDchKcYCl+Pm0Ft9xudFiEGrojq8BVFd5yej2fEzd5nHF49auelUmgqppdPUj3qhK+qWlxHw1e1+23/mDq8etQOX7kj9j7X7ndi73NdParZs3o0sfd5XvWoPWLex/2OYdWjMea631ffjAiqrZI0TsxVim8QH2B4zvtjfX3eD/rBrda/ZetNmUHf56pNwEpVl6JYqmJJiiWAcNZLulDvFyDJCJSByIHVKdQRSEh9a9zsGQhjYEpCGP+Xxs/xO21+H4W4fU6r6ndWj8b3PkeR7oyXZbx6JCHdPHS/vfGzb4evKpJB+CqJ6Ej1qHbNwf0qVzS597muHgWOqh7N3vvcdr+BbXufB9WjXeGrsepR1vwZ99n7PF496nJI+Oohq0f7jp+v3v1+O/F467s212scw9WJL1H8x/tbNJcJrM9530ihf+T31cZld/H6vOmc1/lcquB4JaaamXgB6II8LaAIwsuUQ6scpJkCjlQdEJdppI9eWcGE8K9akFzVegyswT9GEew9ntywIoatolBqd+9zcMvpuUOrR6Cx8JW0Q1edjVe9j4PwFTBZPWqFr6QOXw3db/htK3x1RPVo997nxv3Orx7Fz+tXjwDsXT1Cywkn9qwe3U9Wj7r49b7hq6m9z+epHt1K+GqX+zXXa1yKqxLf7vrIILyvOue8/xbPeXPH6ypjzjJKXd44agbJwiuWqtVStVqCeAHCQonCyBmUEVFINxOFZRpxhSQBTASKyheqRVGAk/fVuMGKooCCwjiZgeBa43iZGehXj5rwlSdun9ceWj2i8b3PyhUdtveZale8q3rUDl+Nud+pvc9zq0dBgCP7Vo9yoB2+uubq0ezw1Qt06IyfAcwPX+1XPTpr+OpE7CvAO/l24vHWVzHXaxzLVYkvdpzzLn5579IFE4izDCufIwujZiFZgGRBqkswlkxYgnhB6sN5ryLscvY+BzSD1wxQR14dMbEqhd3NoHpvMwWxDQKsIKolGAQmcO1ygxdmiq5W22Erf57qUXwtMLH3WaNwTrrg+Fc+cL9N+Mo5YBi+Cu43vFbqTx6rHvXDV+F149Uj9SUl99vsbz6welRb3MOqR23/O9z7fPrqUSdudUj4asT9Xlv4apQTud9T0Xe9rwFzvcbZuBrxJcLEOS/iOa+Tde5ko60LJjjJM3W5ki68lktmLJWxZOKFEi9IqyWIcoBDr5coI+JwxSKCqJIoM0O9EHzc3ew5iLByPJclDfGo+ly3Edwggor24zOqR0nAAdSCqfEH+NbqEUi9J46brXZVjyS9X3K/umXvcxL4TvWIaHLv84zqUZDcedUjIL1vOhs+oHoUw1f9vc/7Vo+a8NVyZBI9v3q0c+/zvu63x+y9zxMc436nmApfXVP1aOvo+duJx1ufYa7XOAVXIb6UhOhbjJzz/izrDwt5X31wIr9lLGW29j4PizQ0V9IFqy6VsfSqSwBLVV1CdQnwQpUXjGoBICeleMUiCiErgpCqIMyK49g5lIViqYioFlYiwLe9bzir1ZB6Dn+K+Fm7qkdJpHVX9Si8LjyXRs0gQGq3vE/1qBOcapPcb+2MHYbhqwtWj7L51aM5e58PrR51x8/7V4/q+8B+4avnJ977fEH3u41bCl+9Bsz1GmflwcV31znvh+XvsswzyfzaOX3hSFzG/CyDl1xIFt7rUgVLVonpZg0fCQslROENZ72AZsqhWkQpXEXMSsoKhFoRlCk53FCWiePgdGN0Q1YtlwvC8PEgrNPVI2qej2fETfXI76gexb+7kepRd+9z/CX2haerRxWl6hGA2sn23a9S1Qlf7dz7PFI9Gg1fxTfQqqSsF74CgLHq0Vj46lTVoyHD8FXX/Ybnd1WPGuZVjw7d+9xwiurR/PDVIdWjOQJ8Svfb59U3UHO9xiV5cPHFjnPeu1UuTjeONlVGXGbkfa7lehFGzcWSJThdBZasWCrFsbNiydAgvJpcLzJSdQoIlISgQloJhbxUECKAAOUgeFHgkqCCCBiGrziNkuvqUXTDChpUj6hdPUKzqEODsM6tHjXhq+Sko5CCGwfbcb/bwlf7VY+6Z8btvc/zq0ej4ava/XbDV+Fzzls9asbP4eMh4atl1mzH2qd6dK69z6etHo1zbeGreXy/9dnXgLle4+w8qPhGgUP3MoHtPm845xXNHC+eO2jYYOXi2kiNXd4gurpU4I4Rks5t4fWk4cIJBAeoIyUBNeNmeM8EYlLldH6b/hdPe4nSdXrT88mJEqhbMdpRPUoCln6viONnT+nawNDt1aNB+Mpj697nyeoReo8NwldAv3oUBLuqx9ndvc9xtMwVza0eARiEr8Jz56sehY/d6lGX81WPdoWvZu99Pln16JMnVz369Muvh8L67cgLAXO9xtl4MPGtx83fojnn/dMdrVzo8zbnvEW2ljKDr3JVlyvrQsnV57yqulTiJSmWCl0qaKHgBUC5KhaA5gTKoOQIcEokSioAsUI5jIc5yigTJwesGupEGgNQSWhj+Co4UaodbEhC+3rvMwMIzja44lQ9SuErphi+iu64c17LmK4etUfNyf0KOuGrs1WPJvY+96tHHRWfWT1qj58P2fvcdr+n3fuMme43fO6u6lH77tmqR7e693kmuwR4O98PHnn1QyOqrwFzvcZFeDDxBVrj5h++j+e8z/jlnzL+sFy2znmdI3GZxj5vcL26VJZwzsuyVO/vwFGA1S+ZdKHAgpgyTxQCVqwOhHCdXlUJCWcwQYMI+5BuVjTd3lpwk8AmBxsEMApuk4Tm6EjTCHisegRmwDdhrHnVI6Lu3ucR91s/NlE9aoev5lSPavGOoSpM731WX1L9SVF0wzgZ86tHU+GrTvUIXUc8u3qUaCpHp6se9ZwurqB6hOuvHo0K8Ez3u4tt7nfU9U7RehdzvcapeRDxDQ4OaNeK1i/ziXNeCRdMcJKrL5YKWYRzXiyVcEfAHTEnAV4w0UJDnCaH15yADKoZKZwqwhYrYlYCK5Th42KNJLUKIqVahCkFp2opBiGJcy3GoM5+5/beZ+3tfY6d4OSukc6La+FNzzUONzhaENAKX0GCCHvU1aP0+tHqEdCEr+ZUj3z6czXVo7HwVXK/6o+pHs3Z+7zF/Ur4epetHu259xk4vHqUP1z1aCDAOE31aJK/7npB4DD3+/3gkTmu14TXOAcXF9/RcXOsFaXr86Y+L0mWIV2bNy7SUNWlqi6JcEekS/XVnSqWRLRQ+KUCC6hfQJH78JPaKalTkBBQu12KC62i4MSLJyjXMqyo+7tUB6g0uF/4QfgqjYZHq0dRpLvhqz2qRyl8ReF1zEB7y1WYO7cFnmh29Yg9tSbUgdr9Shir+7Hw1THVI6LkfvWYvc9oieYJqkf1a2ZVjzC697l+fcv9+g3TUdUjPFz1aDB+3tP9buOc1aM5Z7/4rrn7uv/c7s82jKO4uPhidNwca0W//x6vz7t2LGGRhqrPHWtLdKs7JllCsVSPOyJeEsd6kVKsFUkGoowIDiBHMdmsClGN1+pVZYIyIzo+DWPl4HA9pUNaBAkMwhaFliie1SKd1Wr9XMflgoJ4MUPjGa9GYVVCeO90rjxVPVIQC9CuHtUCG0V/uPcZmF09Qrgow5j7lSSq9Ug6jJ+H1aMk0DOrR2k0vat6FO+Pha8AAPHzd4Wv5laP0u9PVT3aFb4act7q0Vj4qs/Q/R4fvjrE/c4R4P3c7/cjj7XUF2hcb+tdzfUa5+Ki4kuU/rEO42a0xs3v3/0ud3ku+VqEpcpIfFZfqYh0wZkuVLFU5aX3VRDd8BNxiXjlIpDGywVqpqoZFJlqvFygBtcLAmmY3wZ3q8qNyGp0qVS71dr9AkjuN7hYdN1veK8gluAwLg5/4unqEeLe54nqkcbfj1ePovAMqkdV7X41ivOh1aPR8FXH/YLG9j47YHv1yLeqR1kUzFb4atfe53CeG1+zY+9z437zjvsFzl892hW+unT1CMCs6tHc8NUYlw5fbeX/2/Lcd8CrV98oMOJ6DeMCXFR8AQCv0SzTaI2bn3/8r5yvnMjdxrE6x6XLoD5cMAFBeIl1yRzEVrW6U8KSgIUqFgzKoZwjppsJLEoQIg0BK4oLNAAmTSNmEAAiRJGNQjrL/QLouF+iMMkm0KB6FD+n8ziButWjVDUCpeoRYkI6uN84Qm6f5XaCVvOrR6wYD12h91grtBxwGFSP/JHVo1Q3AprwVRaFdKp6VE1Vj+L71O43b1WP4nnwGapH2/Y+62T4Kj5/qupRS4CPrR6Ncaz7fajqUeB7AP2wVXC9r9NvzfUaF+Zi4hvdYeDV94TPQe1x8+rDO1np2m28OGKXgSWDai6EhZIsFBydry6JsSSEywVCaQGiuLtZs3C+qw7wjtKIOW6ODGIbBItSH5fjdwel+t+8tvsN33bP/dLQ/Wo7ZAViTkGqeBYcz1/r6hGAjvttVYomq0fkw38ExOcoiS0Eyf2qrwiCrdUjCHBY9agJX52lehQ5XfUonveetHq0HLjfhl3Vow+t12+rHp137/PNVI9mhq/2puV6O7S+CxNe49xcTHwBNCErfI1XP4HKF47W/le+V8d55iRzTsSLK8oquF4nuQrnEq/RywgVIgUtQPFKRaQ54HOviNfnZYFCQMwK4jAXVSaA0n5mAAh5KwSxA8BgKLQRWSCogCql+8Hdcvg8GnG/SpSea0JUiO7XR5eqzePkG/cbR9Xd6lHX4Xb3PvvmR0UaNQtD4gpJUHxP7LjqUQxfDVxwPUaOuinpF1d/nF09qsNX4fmj9j7X1aOJ8NVk9agJXzUE17sApvc+j7je9r3zVI8iM/Y+t9kdvgocGr66ePUIp3C/3488NuF6DeOCXER864Rz4nPQ+iXos/s/U3X3KRUqXGxWsvGFYy0dZ+yIJANxBuVclXP1WACcMygHEM52kVZGotnXTCqINSEmEBo7S9jyr6gfPJJezHEgzel3wVUCtXCHRz1RS8yh2pz91u43Ps/hcY6CrVF0OTrhVC/quN+khrXocjMMT8Lpo6Ayx2+h536j0wXQ6Gt823nVo4pmVY/i62v3m2yvi7+0w1e1+23/vzOneoTRvc/h8fBebiJ81a8eqfTCV2hEW2U8fJVCWWetHs0IXx3qfhv2CV9N7X1++OrRKP+juVuPnL/7Dq9efaOv62e+DR9a35W5XuMSXER8gXbCGfTqJ9Cq/JFX5c/8vGLOs5VkzokTkVLZofIZsY/iqznU5+Gj5l4RNlYxOQKFMBWRaBjOhosiEMImqvS1///2ziXJjSNb099xDzySSZESVWoZZSprDdQT1pAb4Ca0Honr4RZ6wA1wdouTkrXpWl0rtq5alEhmJhCIcD89OO7xQiAffCQf5V9VCkBEIJDMTOCL//gLiGZfBadmNJTYDyayaGjTaGh+nji1Z6YzdP+d/utUTJQmxr5Hs23Psu5KyDrYniUb09tf+jG94/RryTmXr3V4QSOxH+7jwTp4SUraJmefhx7hOZR+89Cj3Klq2PnKx9iXn2eHHtGn30waeqSu73w1HnrEYOiR8XaHHh3qfAXndr66YOhRbC/ofHW03/nq7Q49GvM6na/e7rzPl0+/5/Em6XeexxcdAD/+qLzm2QuFN+Ga5AtdD+d/PZH6zs8SX3qpf3vhGj1xQb1r/M633nkhVEFjFVSqGOIiIlWMuohOKnW2Dq/k3ssOJyoulYrtAxBAnQqiUVFFopq5IjaoJioSo6LiJKKoalTbj3b/kyRiEbWzOkWTpMXlzhlqN7adtF361u09XJeMo+AcbvAr0CzXbj/k9Nul2dyrGWy75ud4NHW2GgkwnWuaflWtbXiYfnPJ2Q1L0KMOWYPDYK/zVZeis9zT0CMrP/fpd3boUdyf9/ldDT3qS9GvM/QoT7RxuaFH3bZLDz0ad766TPqdct68z0MuNfToHcz7/G7S7/3Ro8+e3Z95Dx5IvQNK6i1cF+9cvtOS8/3792mfV/KXYydx7aSJ3rXqXVTnqrb10bXeO/FOnBcnXlQrEfESoxdVWwYw2gIIXfkX0CxOR1Q0QowiBBOuBFSjQtRIFJEgIiFZN4jlzpgMmkRNVFXFXBJNxFnNav+1fsP2NJwS6YQMIFNZR2zuKzBRz8bolKKBnKT7UrelV+vVnP7tLu3TKN1SgDDq+ZzL1p4+/YJnP/32iXc+/cok/c4MPdL0++4EPe58pTNDj4adr9710KO9zlcDxkOPsshz+Tk//3Xmfb7K0KO8f37o0aU6X03mfb7c0COz75sMPXqXna9eP/0OS86Ddl6YSb2v/RKFwpV55/JNWjSePpbts6cCdvV8a+XkeCeyXogs1Lmo4rw65xDnCE41OCU4JTrEd52U8nk1/18kCBJUNIgSBFqQFkhfdl+gFdFWNQbQVpBWICgSUAmiGiBGFQ2qGm2eSJO5Ro0CUZCouKi4aPVjVXBRFVVRlS45o1FQmzoakpaUCCLSCbqTcWawLyfpOUfnsnT/yOhEPEWjaJ4VKw5EPWiu7fCT9DtNvgwezqXfydCjbkcKv+pkNPSIYfp9h0OP+sSbn8M5Q494J0OPrt756s3nfb7c0CPeWeerOV5n6NH5PJm92/OIR6Mezg/3jkgX24XCtXAN8gUePrT23kR7qxK++oqwdRIWItqIaBBRL6IewYloG5zPw2gSVs51VkZWtQQLraJJrtKANog2wE6xW1QbhB0iO1QaQRpVWkQaVBpRaQRtVaRFpRWRVpBW05coQYSgqkGVYKk6RLFW45S0Tc4gUdMXigoooqqKxiTlLj9nGatTnFNRNMYIuYQ9sG6XnkeE7t6coB0cdCaAaujbflOpGGU//bpJ22+8IP1my3owsU6HHmUq8rzP73ro0d68z8D7GHp0qPPViDL0aHb7ZdPvZ9/c172xvaPJrB6W1Ft471yPfBMPeADcA8ZtSbES6VNG/gD1GgiWGHFRRaOKpMZKApJECztUdkCtUKPUQA1SC24LUoPWiNTEuBOx40SoUXZ2Dm0UbVBtVLQhxpYYWyG2qJqE1YQsIi2SxZzS81DO0crdggZxEiw1E7GQG4VU/mZQ4nYkOasidOlZRHthxwgxAJG8TQ6VroeJuffzDHuZt9/k5/44UgIeHAN0vZjHbb+22EI39Ig0RGmUfvtezFmmrz/0KJ13ZtWj2Xmfh+m3Y3Vw3ueOS837/BaGHl2289XN9zfv81XS71WHHs1yYfrlkql3ipTUW7h2rlW+51Kn26aBaNIRXLS0qUGithq1BTHhojtUanVSi7AFtgJbnNsobETjViRuReNWcBtRtipsVcSOgxrV2p7ntqpSI1ILrkZcbUmZHUi6TaIWbSRqK5EW7HtSBolZpFUsIasSBGnFSSsqQcUFVRdIEhYhqhA19slZIhE06kC8JmMTs2Yx53t5m2jajnk9zFg3TF0c2LNzmNx29KKuprsmEre2376sncvKFbCffsHamvdXPRoe0ne+gn7oETOrHiUG6Xdcnk7PO5h+81XguPNVl35fZ97nyww9es/zPve8jaFHb9756irpd3333kScj4E+9T66IPUW8RbeBx+EfF2rKl5VgqpbaIxoFBeDoq0T1+KkQbXBSa1CLSJbxW3UsRFloxo3CGeqnKnqmQhnmh8LZ0rcqHAm4s4gbgQ2Aht1bFTZqsStCFtRtiZkrRW3VaVGYk1Ukz2yQ9khuuvK2CI7SIlZk5xTGZuorUK6aNBWVFsnaslZpAVpRTWIYG3VIkHFJC3qgogLohLIaTmmLktOrUOYo2t77sQrlqCjQ4mquLxdVRwqEcWl48UrmgYmadouvm+PHv2Wehu3HEbdULqTfbmNt0u/YdTGO59+20H6pSsjs0iS77ZnsQ4Sct6eHXyp9Mt++m3PT78Xdr6aG3q06NPvhzDv89sdejTPVcvPs5yXfp/kkvOQR3BB6i0U3gfvQb5PAag2d9Svb6lvVKVRdbKMvlqEGH3w4lvFt6rSoLEh6k6830qItcBGlY0QNyhnip4KnIKeAqcQT4l6isjJ6EvjmR0jp5rk7NKXwEYnX4huxbmNCNv8BbFGk5hFa1Rq0B1CTYwpJZuMRWTnPDuIDU4bS+xqpepI69BW0mPF5KypjO3EpKxoUEdQNJWxNYi4oDG1M8eud1UUiNEScxRcBBdFhqVuF+NIvJamZSje6BUCWdYoKs4r0dmtQ8XNpYRezBKTvA+Wu2esDFBBn34TC0aM0u/ouEW/uRNt6i7dtf3uS7Y/+M3Sr3HFoUdw4dCjizpfXXre53OGHl1t3ud3M/ToUPn58KIL9yaP92vNl0u9pdxceH9cq3wfp3JQ9bJVfxzV16qnS9WdhNjUMTa7GF3UEIktGhpEdjipcaGOylYdG0uy7hTkFJETUU5U5ATlRJy8AnmlTl6JctJ9iTtB5ETEdV/A6fDL4U5dJ2Q5Q+RsKmSFjQ5kbF9uK2gt3m9BatHUnizUMeoOkRqkT85YCVvV2pqdauOQRp00qtoiScjO0rOLWczWzgySBO1a51xQCOpSad6lxOw0OHEhpsQcsaSMZFG7KLioHus+5VSJqLiggosxlbwlpWdxmHijagvIUN7OJ2m3tMm4NvJaBxK2rBycyX02OrcgrtLhrmGCBVgMzZuGI42Pm0whObw/GPe72Jv1ap9p+t3jqun3NYYeDe/Opd9Ld76aDD16/c5X1z/0aI7695/3j30y7mgF8OjRMPUm8RYKHwj7zXfvgh9/VOvZ/1jWd+/p6bNfWNyK+qL+XVftOgoxukUMGhetysarVg5Rh0QJqFR4RYMJRmQR0QpNPXjEFk9Q8SIxOhERjVGiyzNOOVwXWQbvvagyfidq+rLj7N3dX5vM9jZ2ZjWis6cKaB4qFJOISM9zpM5Rokg6OKoikrtQ2T7LnaCqoOCcVXKd0yiqGtTOhVNiREQVBBGsE7JHCTZ3iHVJ9pZqQ0DEWTuyc6rWAGzyDAFENeItCQO59zUVSgsBG0blxCsSMPGSpJ2kHH0nbEgS1rStbcF5xPnuBy3Rq/j8QwdoEVcpsbGfXawUmm5vQ4Mc+pNdwCKmo5cLCMqwrVf8YvL7W2LXQZZ6xS9Vw05kuVJ77gr7Nu02tohboVqLiFfVphYB1bYWqfK/YY11JxhyRP67itVWXLvW4bZ1I7JdDP4wb0A8OxO3sAN0dybCsdo1Ilj6PekO/4x+Dzc/g938wLS4cuLquP83jKVfv7bX+wL44+xPcTc+V+4Azy39+qPP03O/BH7fP8fp7+KPv+zP/zXw69dMGy/ABLy8FUbfy1//Cs9e7h1K+7yS6k47Onb15feaK2jW3jtOvuPViyZIf6ek3sL75BrkK+aUn4B7D/TJH0/k+zu39dfTSm+vbsdFOI1nq3Xw9cI537RE71gEIXoRBYmqUUNEXBDvG2JcYOv2VOBcFPGi0SEqKiIqIs5G+IgiAkoMKnhH/sBzKiJprmZiSMvrQZbtaBapblu/xSqntl0m5VWR/CKT8qowGdoAMZdw83WAACLWs7mTffpnkObtqtAQQNG0PSLqVZ2NXJKAgiOKKimuooAXRZ2KBJM+ijiv0amiCuJUQmtydE4tiapg29fgAAAYnUlEQVSGYN+3XV54NdkrOK+iqq1rkejVWVmaLikHOkEHa3smy9oka6K3H4Sqpd4WaRtwlVo8rhA/uO8qpSF1ula7n6+P8nYwp/q8cZCWs2+ByjfShvT6S0Zl8k7G7U5Wq6XuDpXQ12vYbsnSjVUt6xbdNrXIYq1ZttpsRRZj6XbbbtBdX8SdE7fMgjym02q6G3dn4pY3FCz9+uZYLf2eiFseq53jtLsftiJ+PS+YsHXi1+m1bgP1F8Afk6OSfWdoj55LtbkzOPdXhNPfxgLG0u/i5leXktzdF5U8u91e6tgpV029RbyF9807l69au6Jp5xHwt/u64qm2VOqPF3qyuhVXeha3Sxd8HZxf+8Y5kOBUdasiVWyjBudpiFQmXfGCOJXWgzjnFqIhOBVEIhJFBR3MBOUqNNh0iqgNwAUPEgXvcFE7LWpKy/bhrQznHQZQCdJfzHumQj34lp7Z3k22MRS7RJMY0faHiF3AODVDOB0ZX0RVTMAWZUkiDSllRsR5E7ZEtZScxawqtsUEXC2UEIjRKy6gTlVClqZXaBC8BueUVhGHuuBB1MYr53KzglSVSTcmoUefjlGl9XaR4rzStgSXhBxVcZWl4UYRr2l7pW26UBkmZUmSFq+pqrBD/EIJDcM/7S717vofW8Per65nuWKYfrUVkUr100+/Xyj88drp18rPg9e+Yvrlr8Al02/PEwu+39ijr+490FEz7xAZ3jn0Ri0Urod3Lt+eh/C3HxUey9/vPtDv65/1edvE28+dbNbHYRnPpJbGBg2tG7yoelaxaUPwC22dq3zYhUqcerx3gJOUp4JEcURnWlERcSnxIt6J2Js/t3PZXMMqqUdtDBLxqAbx5mMx6VbWc9fWVhh8TmdRm8kHm/tjPGgM4ocb5sifSUMLpIidyrOD7Wjo9ucnhL6DE9F+IulgvINoslUVdS6VwVOnKnvkldBC91omZdHGXl8j4DVkaeLRqCpZtABJisGR0nLqtNWmBIxHSHL2WApfqIZYmZirSru061okYunaV0hEGypyJy+JKN5K0ZbwTbwSF4rf0fqFsmtSWm4gLtSMuyCnYBM6SMj7ZtjV4JfY+Lfh7QyfVPrt930BvACs89Xz2QC8n37ny8/Nr04WN+elP+Vy6Xeu5Py43z2XegfiLam38CFwTfIV+EmVnxDuPVCewoqdtlT6Bz5+Js9lu1uF9XJJs6zU+3VEdnG3c8G7GLwufUC8d/hI5VTU+t2KOhyCNWc6DSo4EfCWWF0rgQofWxGHoKDBCZVC9CZZ55JsndCG1KRYobERYgUSBKEf1uLdKA33w10UdVhv3TxSFzvXyL1q8j9EPp/kT+julSLSP0jIQLiTPaq5XD0QdkC9KK2t2SAqGpwzI6YUCiBuqUoLdm2jjhY0JU1vZeZWk4AFaFscVUrsbWrLTR9wOd2m8rG4SmmbTubEBsHaecVXKgt76dap4sBFLNV6VTxIyAm4UpoGkYU27EymYV+84hdqol6kBLyjTeKVamm3+bFfpnOn22p86yp0KCggibfHVSulnSZf+NjSL0DM6Tfvf530ew5XSb8d/2Bvzo9ccj439RYKHxjXIt++9PwQnv6o3IO//++N/u2bexF+4dXmFp8dvWSnUY9OVZubMfq6ilrVXhofmoW4qtn5iHNBcYt659SvRFWdeqQKIuq9lZWdCCH3NfI2LlQ1lZ7bVGUFkta0QVhAhQjOo9l7ar0vVdQSMjZzks2spJigrZdt5QYyDggV2GIG6ccbAZeStvg03nV/0gp1QcQPt1zEOceNq+VYu6lYKTvv0ohPUg4qau3ioOwgVulDUQFrH1YitA68V5+EjFNl4aC1D9zgnKrXTrLECK5SobEOVFER79WebCVlRGmdbZM2SToLNybph9bE6hskLpS4o10ulN0O5yvFK/jUJkwqWe8W3UWMeNVmt+sELNVSGT72S2VHl4xz2q3rGqnGqbdLz4uVErJot6MbWawUtva4AtjQDUfasDeMakhJv4fTb+5s1aXeQcn5EZTUW/houOyn/FtA+vT76BH87Std/+sJfHO/E/AX/KE1UW+eVK65VUWNVXDOOY3O7dzCragdWru2OrL5oKuVLCsR1Vq0FYkeIVgbnXqEFpYeUVVb3yiosFym4SM2LaF6kUXAOmUNJ2AIuzRJfxL4srJbKjQ0sljQdYqOQW3YSxCLlBHUWbLWNGfxIqYJJKjAeYbTIMYF9lhnfh2DaRSnvy3f7TvE8Anp0z4wSNOQpew1DkYAOcSnDl+ttY5qSGnGV6qDcq1IFp7VTb0kaWvERFtZezIRfLShRA2p7TaV7r2qNEmy6Txdsu16KUdaUWVXIT4qVEhQWNrrd+2+npSCQZb2QduGhRJ2iAep7NpCgip+gSXfpRLqQeJVpV6yE9UsXhewc3Zypku9Uploc+rd0v+IXbXe+7B3i7ytF7IbpN5evHMMZPzvln4vSL3jPQ9LJ6vCB821ybdLvz+iPPwB/v6IJ3+D+/96At8cxerOd/qiDXrnX8+1uXk31i9fuNvrL2Wnrxyrz0XjqTvbebmxOBbixsUoItUxu91GtBGJC5EbCrER4Qi0EYntVlq/RqMKCLpQQQVVZGXjhERdLZEVMe4EXYIzeSMLNLXjqu5kpStU0yLrKhJpwCeRyxLVRnBq40gBfJpz2Jm0Q3pi//NIn8/DuYfJ96GbJMLlGZtaCP2vS2MrYS49hWHkHXbTrWxWqMHYWTubPZwOvVVNz01puBOmRvouxqBtTKfw4DUZkNSjyWGN5q3tT33JZJkk22ByjYDfWTrFW1Ns3KUScrST+YVKoybGhKQ2XgChb8NtsiQDSLVUqWy7SVmRZe6AlYTrFakWCgo17EQ1vzNcyMl5qTkWSkipll68lnCTeGdSr2ThbjawMOF22844JwmfMmb6eMink36/A35J96s73yn8nB49TbcXpd6EDO9c6qULhWvh2uQLoDY5g6ADAf/wQHmK3F8hq+ff6subrba3avn65XFs/E7ijSNpT3YSj1bSnrx07uhzdLsWjl5J2NSiu43YVf6pnHGTG6tTId4khjPxAhprK0fjiTuEG54YRXY4VESiU7mBIKLCzsERaLTJ8WOzFdZr8CuaNHmCtrWwVpaNCOxM1KsGtE/NrUcsMZL2p1tdskwzKeHSrErtkjwvcWBp29udQAPtEpZQdYWzljyRhIh0DsxL6gHgepl3LICwFdoFw3bj0Qia0YQWExMsAWE83GpE7i3UbzFxgpm1lzU0qDgl9xSPka6Xcox2ZAXi151YrVGgUnyfuC3NJhlWSxMn5l9f5bS8Q1DtU3+SbQCokdVSaxTqGhFLvVR9266kdmYAWaBsNb2eav4gd60qrNhWW2Sxsqur7dYS71C8G7ufU6/kpHtmqffMXqZPvWfgFjc0y1aWN3Tfu33qzY+zbDmhvz9DrJ241QecfkeYeKcl55x6Hx9KvQPxltRb+NC4Vvl22EWoCfgpcA+ePH0MPND7d7/T7TPkxZ2fpX1eSesrYfEt8fkz+cvxkTQvGuEraE/WEnZ/CvwFlhDbjcAKd7oVbm/Q1mbSkWAfNNyqcZUnbGoRHHHXCDc97JAzPDdahOMNJm7rtOWWIsQaOLZkTG0dtiLsnKXrI6FLyDhL3j7PoNRYGToqIh60qaWRNTSgVS0rt+6mKJS4Rn267ySJPM0M5SXNL7wEGhNsa2ncXjcL2x7bgvWNDZmBtE8YSzBJOn2v4oR+sYFJDu7G5fRCH8+Z3J+31/bkg3dnSbXBk4cF9Xg0xK5jE4DGuvvrlLBQjRHbYM/z1UCqu5RC/VK7IWLU6Xzp+6hhV1X9YxY4WaqnBlkyKim3IOs+vUq1UlqFaihcu18nicpWcXnccqX00l1Dm6W77refAZzhFkdj8aYHVoYeiHdgXmvvNfFae+8crxjOlDVNvfvi/Rz4kzneV/rd52l/d5B6gfnUWyh8wFy7fDXP5SRJwT89FJ7+qPBAuYd0Ev6PF8L9+2yfPZX695+F/wUv01yvbV1ZG+tiTXxZi30YHPGX439KPP4aWoj175KnvWuPnguNNRaZsAHuENs/BeeAFY6tcAq9uLfoWSU2NV+NtvbasoS4ORVufkYMp3LKTT4LEHanwjG41U3i1ubkFUAXZ+KiSdn+yRWx2gjRUbNjHdIQqBs7tOmn/YvB0jcK2mzTlCAWw2K7FVkLO00dpJq6k+uyrUXW6TTq0LaWPu36TvAAUslofmFZMZD8HL6fbnHdC3e45vz+dIxpb2UpuP+DG/7ppQQrffqphz3CQy/ydeW1BvIMYgBUdi5XLRTqdLoF7Ox04pdKNTpjKg0rbPtzi6zS629NmFV63G4G5WRgkWS6AZeuU+QonW8DoLa/1XR9sLake2b3Haos4CxNOdlJtx23/XbSPT1Nx2XpTsVrifdVlu3Jq3NTLy8Z/9KAffFOJ9yAQxNuvCu+A/4rlZxXz0vqLXxaXLt8M1aCFuGn9MYYSvjvj+TJD+kq9tl/y4MvH/DqP54I9wFMyP2Z7nVzvZ7duQG8ShOy38DSwne0/7cW/pq6oS7WxJe/ChzD9oi/HP8mcEI8tnVIw4uLpc2dI5sD1znidisKODyhdQI14jywtcR9ZD9ibbPkatT389i63Ea7Jc3ZmybPFzsX22Pk+GaaZN9SOOLEBLODG8eDdtwGEW/7bthjG1KVadCdl8E0w4wmEdkBlaX+IXkhgVQPtm2xlvz5PfpkczcmCw5MW5NhtAjBGvKf4fA8C0jNqlsGlXJCmP+jlWqVJiTJHdOGw302AL1Mt7ANcXSMiTWL2G5dnVvmV/YTaXPb7YosVkvB9P/MRT5GGaXYBs5yy8DySOEUl/fLDWXRJ1srMZ9CcznpwjGvoJfu8kDiTZ2YpqnXr29pJ98X4Ne3dSjfalByPte/XwG/nbMfbOKN85qtgdXLb7Vv8c1tvQNS6n2cH5+Teot4Cx8q8iH8bVoD5uD7+OmhwI/9478/so/fH37otz19LAAPeNBtevWvJ/3H9P373d2xrGEo7LxE2f4KKt/R3vqvwbZviS+fCcBdoDn+TfLC4f2qLgNpA7lrZr8yjK0WY5PX22T2t/KqMrcBPh+tOhPrE4Fb3cT4o8nywSbjv5nvj5eaG06+b/vzxPzHcEySeXoM/Wo6N2xbt85sYrQCz400QrVJ6XxCnG7fP2R/RZ93jgm46+R08LAk6gPH2fM3/YZRmXi0qZNsf8yNdMzYPpKGDY0TbmZfuBlLu8wm3StLF2bFCybf37N1n0Pf3gu5vbe6eUen4vXHM+XlX2Fadl7euqvwX93j1UsbZnR05zv9Bz/DP2D15U671Ptsknqf5g+PhyX1Fj4a3lvyHTJ8g4zSMJiTH6a2nkGTD9gb7/Fw0x//J73tfhgu1AJf3OtkDfCA/4YvH5is/yNtvN/9B0jCngx3qH83ob0AuHOD9nkWVF6e5tRWZ7mVk8cW+Ja4aZK0a1hBU59IJ73jI5P3i6/gq4Z2KL2j/wFAeDlY1u3OnX7lmTXQJonv0jJ3t9cm8Da3vtZpSblFkviOcCbSt85aG2pslibyANAQQy3DJey0tbI63OQ42K8lto3Y8/ukpYszYekZbQ8DuXccdz+2qegvQ78g0P6i9fOkIUOpY1UW5EikAItlOve4zdpECmcoXVe1M/pU3vZyrbJcGxOlHGe5jjtIdZJtFDiBJfjVsYLCibXa5otSt8zviUFpmWgND13SfYVf37TjOuF+pqxeMKSX7iTtrv9gP/E+51Li3eM39sYFsS9eYyje/dQ7XEjhQOq1+yPxltRb+LD5IJLveeyl4szct/3wYXrr/Tizc4acqGGcqjMjYT8Apum6+0/HtCQO7KVs+J72+S8jUbQvnsncwqZfT5dguwvNy/FaqaPkbeF7sO7qJH3fsaXihgun5+XUwyiFM156LmGd18bbpokcIC5PxUaeDrbt+jQ+2nMTQn26d45u5wGGy+wZ/UXAHufsupBRUJ2vmY7TamYsWxPrdPMJpwfbZ1+d22t5Lt3CfsK1Y8el5X77fNId1pd/v4x0f+vvTBdX6HiD1AuwvrvRknoLnwofvHzP46CYpxw6pJM1XErYQ1nzA8z4ek7YMJB25+rzy+IwWbe0E/dciTzJm7/aBAUJa9vuu4TeTf+ZyhuywJO5v9qXd3fc5k+xpV779V6HIocv+AIbrpIlboxL6kPmhD6m3xm2rw5I2hiti3vY2weJu1MZXzKMObcj04RXBx653XnnGKTXOQ6UkIeYaAH+HInW9u3LFobtun3K/XNGuPAa0gUWp/Pf73CI0TD1Ht1p9R8w7mj1xDpaPeYx3Hugo7beHyniLXxUfNTyvQomariUrOGCZA2XkjVcSdgPug39vX1pjx8cEjckeQ+kDd8D7KVuoF/M/FLy7tu7M9N270MJvDt+My6lDxnLHPps3tOl9CEz7eaX4zaxfnXBBcBb4mUqBU+teAnm2mj3j7k9+cu9QLSTDlTV0ef6/4Dp2N290vJvfQPv60l3nHj5J6xun596eQKfffNKH0/FO0m9qpd9kxcK748Pos33OrjKlbDkUUF77+EfD5/j0J6Ho4bqSbt1ZtJ+PRa2nXloniHP/nsi7l6+r+oXsj+kBLj73b60b6fnvRxI+85t+jLr97wA2me/iCXRcVtp++JWkneaHindxM2JwDfczRNxJJqTVDL++muox/vCdtp2a12Ju77JX0Er9eQYYPcl0BLq6XCnxCSxQxb979Z+noYez/+oD/0CxsxeFAwwOUamJfkxfwz+O6CemDJ1Gu8mwHgOeSIQug1j/NHnyia3Z38+aDL/fXQ7lu1v9pV864+/VI7323PhVxa30tq9z2Z2M5RuEu8/YXX7W+X2L4OjZibVGKbeKZNy86UvsAuF98i/TfJ9l1w5VcP5h75Owob9lD242eOitD1uyian7f2knRmUykdpO3M4dRvf2f5RD/N9/sq37FKv81kOJPMp4XS/9J7T+pA+uWfmpPOhMDfTVM98xygmw4PGXZbHqfbX0b5OtHAJ2U7I0u06Vw0SL5Ny87SH8zT1/tRfFJfUW/hYKPJ9D7yWrDNvW9pXETacK204X9zwJvLO7HdWm+V/fkf7x/kih28BuiFkkErrM9jQMrhI6m+Lvox/Nc4rAV+OcwQLE8n+q7u3vPX1pV7X2nXhkHSt1DwUL3z2zP7qH99D0yTOSb4PSyerwkdLke9HwocrbBjZ+tJJe/8RHJJ35qL0nUkiv/PzOcd93927lMyB9tZ+R7c59vusj9lN2tI/LHqhwuWlOmT1RRLsf+Ytv+wdY8IFZqQLdOLN5ebZ1Fs6WRU+Yop8P1F6WcOVhX3R4SNhw1uR9szDIQ8GvcjTltnjMoclft7QsEPcu0QiP8RF5farYb3aMxdp/gDnPu2fAFRf3J3/K/hProytSjSkn7XKyssw7AwxbOO1LVm8wN/mhxaVcnPhY6PIt9DxRsKGi5/yutKGi8V9zqbfrijuzP6Y7tkHe1xO6DDsHDfHoaFmV6dP+cZ0ysbh/pnpHN8ivWwz+0kX6MTbDyvioHhL6i18jBT5Ft6INxY2XO5p70HcADx9LA9md8xvnWMkcTjg7vOFDleR+lUZXgTMdsd/63SyzZwnXYYdrJiUm0vqLXycFPkWrp23IuzMRU9/E2nDjLgzVxA4jCZfmePBFWQOM0K/LBeK/8ncAVfg4osI4wk2bvf+6DfYDSX6+4O0vYi38GlS5Fv4aHhr0r7sU/fEDVeWd+agxDNvV+aHeXDRAR0PLjog8fiiAw7wIN12KRewpJvujFYqmpaaoZSbCx8zRb6FT5q3Jmy4+tNn5Q2vLfAhF8ocriz0N+UyFwR76+8m5srLQCddoIi38ClR5FsozDCWNlzdvAe46mnepcCnXEroV+HAdKqPGDAnXDgs3VJqLnwaFPkWCm+ZfXHD1a074Q2ffljiU96B1K/EYemWtFv4lCjyLRQ+MN5qqXzIWzxVx4VSv0jmA9lminQL/wYU+RYKnwjvpFT+Fk5xIQf1XaRb+HQp8i0UCu+mVP7aFOkWPn2KfAuFwlthXuBwvsSLaAv/nhT5FgqFQqFwzbiLDigUCoVCofB2KfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGaKfItFAqFQuGa+f9Ilwd8dH/DvwAAAABJRU5ErkJggg=="/></g></g></g></svg>',
        ue = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 340 511"><defs><style>.cls-1{opacity:0.17;}</style></defs><title>资源 10</title><g id="图层_2" data-name="图层 2"><g id="图层_1-2" data-name="图层 1"><g class="cls-1"><image width="340" height="511" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVQAAAH/CAYAAAAISSWYAAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4Xuy923JdVbK121pm72OMKVllKJaBIqh/ExWsiliuS7+AXoLnAZ6Hl/AL+LK4+DexghVFFAu8bWPrNA+jZ+6LPsY8acoHkG0d8iOmNSVka2Kj5szWsmenuyMIgiD448irPiEIgiB4PUJQgyAILokQ1CAIgksiBDUIguCSCEENgiC4JEJQgyAILokQ1CAIgksiBDUIguCSCEENgiC4JEJQgyAILokQ1CAIgksiBDUIguCSCEENgiC4JEJQgyAILokQ1CAIgksiBDUIguCSCEENgiC4JEJQgyAILokQ1CAIgksiBDUIguCSCEENgiC4JEJQgyAILokQ1CAIgksiBDUIguCSCEENgiC4JEJQgyAILokQ1CAIgksiBDUIguCSCEENgiC4JEJQgyAILon0qk8IgpsGCQIAHKjPCHf3l/2cIHgdGP8fBbcFEsTL/ndnCGvwxwhBDW48rxTSbUJYg99JCGpwY3mpkH77LZfPv/5692eFsAZvSAhqcOMgScCxS0y/+fZbAl8DX6998FvgG3y7W1hDVIM3IAQ1uFFcVJXuFNJtLhDW3dIcBOcJQQ1uDCSJrf+fdwnpP7/7jsBXw3vfAQD+8dVXq5+4Q1hDVIPXIQQ1uDFwGIICAHz7Lb9ZE9IqogDw1UpLR75b/rAS1m+Bb75eE9Fo/YPXIAQ1uBGcE9Ovq5JuC+njhw8JAIc4BAA8xEMAwL3DQ98W1m++jSo1eDNCUINrz8vF9Cs8vvdw+e8PcQgcAv9+9IgA8NmDB46H54X1H19V8fwGUaUGr08IanCt2fZNvxnE9Z/ffUd89dVQkdZ69N8Hj1bCiwfD20cANoW1iup3UaUGb0wIanBteR0xPcThmpBWEX02+X4prB+e3R9+gUFYjx74QzzEvceHDgyiGlVq8JrEcpTgWnJOTL/dIaaHo5g+wLPJhM8m37OK6X38A/cB3Mf4sWf/PSHwYPj8w8EmGNKr9UMAoaXBSwhBDa4n68L27bfE1zvE9NEj4sGDtYr0Pj5tGn7a/MAnzQ/8tPmBn/5PQ+A+8I9V5fr3saL9qv6aoyc7Ug8OBMF5QlCDa8euEOpCMf2+VqSjkNaf9CWOfkr1+X8CnzY/8Ph/GgJArVQB4HDwX6NKDV6f8FCDa8XGSaiXiOmzSRXG46bhl8OnH/2UiC+2fsEfgYPPeweA/51/6cD3g6/6CP/36Mg3Aqo1LzXCqWAXUaEG14bqm67e3xZTrFWmAPDpIKZHPyUepZWYnvyciPGdLwahxZc4/p8fCNzHs/8eLYKxSh1Yq1Kj7Q92ERVqcC24MNEHOIrp39fa/E+b2sIfpbQUvpOfE/FX4HMAP/2rfmz/L5878OOyUv3h/wXu/D9z36hSL0j8o0oNtokKNbgebIdQAP753eClbonpcdMQ+HIppic/J56kxM8HMT35RevzvwInP/9Uq9UvAOBL4D+Bc1XqvahSg9cjBDW48nC8sgTY8k2Bxw/BbTH9El/iKP1I4AtsC+nJL1pFdni+ElXg6Kcf+SVQW/9/AMADHC1nWGs49c36lpXo7oItQlCDK82rQygAOC+mtSr9iRtC+hmw8QAAfA78FdioUgee/ff3HM9TjSNU2+v/okoN1glBDa4sGyHUSxP9UUyxFNPP/wp8uCWkZ4+Fq8dj4jPg5Jefq+iuV6lD21+rVOBl4VTYqME6EUoFVxauzZt+A3A70f/7MB61EtO0FNOlkKIK6a5ff3LPHP8G9j/5i/+En7Dff+748cdz4dQjPMLBEE7tWpoS4VQwEhVqcCVZF1MMx0p3iSlwH0sxTZtievb4MZdi+gkwTU+IT+pzYBDa7Sr1C2AVTlXOtf1AhFPBTkJQgyvH+RDqfKI/iumnzQ9cVqYATnQUUyHwyVJID5484T3cw8GT+vyCLw1gFU6NZ/3rR7fa/gingh2EoAZXiot9081EH8CGmH7Y/MITVS6r0i0hBe4Nv2h9/sm5KlW5GU4NaT8A4MHa+f4h7Y9wKthBCGpwtRirvVck+p82zYaY4rPPcPb4MfHJJ+eFdF1PB053VKnr4dR227/OrrY/qtQAiFAquEK8LISqiT74bLIppp//tbb5y6p0KaQA7gHTp083hLMrf17+D7/3kfkvvwDAL5gs7vkqnOp9PDm1Ot9/5v/36IFj2JUa4VSwi6hQgyvBq0Ko9fGoevb+C+AiMb0HTPUpq5h+hPp4GZ9gDKfq+18s2/51aoWMzUv+IpwK1ghBDd47G0L0khBqHNzHF8BJ+okfDmI6TU84fSK8d+/eS4S0Pp/qqmLd1fYDm23/cbPyUcd7qID1y//WiG7v1hOCGrx/dvqmqxBqNR41nIJKaUNMgXs42BLSmf7Gmf7GzeJ0u1K9txyhGvkcFzDOTh0Oaf8ynNpMp6JKvd2EoAbvlQ3fdCuE+vvBmOiP41HnxfTeIKbnhHRg9ttv5wVuK6A6x1/rm6O0Nj71fR2fOlz7tJ3hVHCrCUEN3hsbYjo+XwuhVon+MB61LaZDi39eSP88PCrrAgt8tBFUjQXqxvgUgA0T9f74ZLPtH9moUqPtv9WEoAbvhU3ftIrpP0dRXQuhlol+Svzwly0xfboS0/oLbQrp5vM3Y8NH/WHwUS9o+7eJtv/2EoIavHM2lkVvhVCPsfJNj9dnTX9RnuUqpgeqnD4lZ6pDVVqFdF9+4/iYy7rIblepKy4KptZ547Y/qtRbSwhq8O55jRDquGn4yU/j4P6mmK6q0k0hXf8SH+74sm/Emo8KYNX2P3iNth9Rpd5WQlCDd8qGb7ojhNoQ03YU08c7xXS+IaQfrj0q+1tV6pvzxfLZsu0f2dX2Rzh16wlBDd4ZG0tPtkKovx8cVDH9n3Ux/WUQ03ROTPflN1bp/BDzF8K5POf8RX38ofr0M+Dzc8NTa0unX9L2f7P+U6Ltv5WEoAbvhHNLT7AZQtXE5z6+/E/gpP2Z0+YXnuW8JabCuchQla6EFB8Mv+74do3957u90xXnZ1HHE1OrYGqQ1PvLvn9n249o+289IajBW+d8CPX1sqpbhVCr8Sj89a/4y2efYVtMa1W6LaQfYENJPwB+b5V6bhH1lo/6srQ/wqkACEEN3gUv2SB1LtEfZ02lHiVdF1PgQ6wL6fxIOD96MTx2b+X/Hbr6Sna1/SMRTt1uQlCDtwpfGkIdrEKoLTE9EBlGo6qYLqvSNSHFXWD5WGdZpf5+zh9BHX3U5ZT/7rYfiHDqFhOCGrw1tqqz+vx1xPTJeTHFB9gQ0rvbIor6789/9I/yRX3z5eijDh8ellwf7mr714m2/1YRghq8Fc75pqgh1OOHD3l0kZg+Fk6fCKe6JqYixAe1Kh2FdHIsnB8LJ8MDwPkq9ZJY3ob645aP+hKi7b+9hKAGb4cLQigcHuLBmOjjS5z8nDhdHikVHmyJ6fxIOJcXXBfS7S+1rqWXV6VeuHcKwMpHfa22P6rUW0MIanDpLH3TC0Oo73k8bI+aNsoP8sViim0h/dPWA8D8LVSpy2XTf938+GoiFa/f9iOq1NtCCGpwqawP779OCPVBfnyhmI5VKQDgT8BCyMXx6rH+dc9p6Y6Z1Nfms4v+xSCn91fB1EV88/XXEU7dQkJQg0tjY3j/NUOoOmv6lDP9bSWmIpxorUoXcsxRSHd+0e0q9W0y6Onoo17U9kc4dXsJQQ0ujzcNoUR4oMqZKvcHIZ3LEDQNFSlwAABYyAkXcsLh3fqxi0T20vkCwCqY2mj7B9bb/ouItv/mE4IaXAo7fVOghlAPHmCXmObffpNdYrqQ42VFWoVUeIADAAdYnMiGqL53HjzARUTbf/sIQQ3+MEvf9FwIBf79Efjse3BM9NcH92eqSyFdiWmtSteFdNTPg+GxODlZitTi+PitC9b6mf4lr/BRL2r7o0q92YSgBn+IDd905zq+MdEHp80wHiXC58+fS110siWmB8C6kI6t/kJWInqAAyxV9j2Vq/8Y3m77qOfa/q2Z1OBmE4Ia/G42h/fBb4CXhFA/rcajSO4S04WccHEi7E5GESWBO6iPTdar1DGYejdUB/XJjgH/eg/WJt8AMZN6iwhBDX4/O64xeVkINY5HHb14IUsxlZWYHuAAnZwQB7tE9A42q9T3xK5E6gIfNWZSbx8hqMHvYmcI9RUuDKGePXsmq1nTNTE9Jhci7E5kWZH2pyfsuXq8/JW8A9aG+8ek/2XsbPsjnLoVhKAGb8x6hXVRCPXJT9vjUR9zpsJ8/ELOielQlY5Civ3NCrU/HUV1vUp9bzXqkl0+6uGOz/tm+wMRTt1YQlCDN2LDNz03vD8uika9wmRjPGoQ0z8PYspRTIeqdE1I+7PTpYACAPa3X8UVYVfSv+WjXtT2BzeTENTgzdgKocbh/fUQ6ij9WC/Xk9Ws6TkxPaliWqtSsj8T9menbOWU+/tAK5uiuqpSrw67gqmR7bb/3ExqhFM3khDU4LXZ9E1fHkKd5dWs6b58xLlWMT09PZWzX8+kEy7b+34Q0f39fdRytJak7bJSxdWtUkeGYOrC7VM7iLb/5hGCGrwWu4f3ARwe4m9bYto9fSrTVGdN90V4fHIkkw+rmPYi7JSrqlTIfeyjPyP7s1P2WyJadXQ98T8/QnXV2B6f2nkranAjCUENXsnFw/s1hALuY1NM/8LmqA7uH5+kpZh2IuxI9iKsVek+2rNT9jwl9oDxUUW1SumGwF5BtoOpdV6Z9kc4deMIQQ1ezYXD+2sh1Nr2qObouczvCfNJkoWuxHSsSrG/j/aMg5CO1Sm5s6/fv/rd/jYXpf1AVKk3nRDU4KW8yjf9tGl4lLA2a6qcpzprulDh5C65FFMRtkK2PB3Etbb52Ktfa1mZblWp14aNAf/DjX+1Svu3Z1IjnLpJhKAGF7LLN318r4rp35aJfmLz5GcZV/EdHWfZ/0h4cppkcpc8OzuTpZiecSmky/ZeZCmiwNVv8c9zwZKUwyqp59v+rc/zCKduEiGowU4u8k23Q6gnT57IWR7Ho+5xXwcxlSqmHQ+qmLKK6Sii/VTYTOtS6H56tiGqm8+vOGt6ustH3cU35z4SVepNIQQ12M3a8P43ADZCqPurEOqDnPn8aHvWlDxLo5iSLe/U9l6m7KfCPQANz4g9YG+vamcV1evHRbOo58en1u6bOhdOIbghhKAG51j5ptvD+4/4bAJ++gM2Ev2DT5Qnx0nmfxamU5VNMa3hUy/Cvb09NGOlir21MGosSNf905vA4cpJ3Vrk/83muxt3cQXXlxDUYINN33RXCPUD//fxT1IT/b+waZ7LXD7i3iCmi7vCUUx1eibT2VT6qbDhSjyLTDfFY/RPr2mVuslaMHVY3zx++HDHf1fsSb2JhKAGS3b5prtCqA+b1faouXzEfHIkE/mACxGmU5Hp7Ex0eia9VCFtSBaZsghZhAQmKMK1dH+9Sl1xLSvVHZv8DpfP1tt+4Juttj/CqetPCGqwYodvur2O78mTJ3L2ed0edZRfyL6QdXD/RJKeyrLNH8S0TKdLEd2mTNcq1esSQr0Brz6GuiPyD641IagBgIt802EdH8BVCPU5n//2m8zuCfflzzxJx3J6qoOYHnC9Mq1V6ASFU5ahUm1IFo5COrmRQrrJIQDgHw8fcttHPUfo6bUnBDW4cHh/PAm1//BHqSFUlulfhAd6j/nFCzlJx5JeIqZlWoV0ggma2aoanaxVq2OV2p/dBP/0dUanXtL2I8Kp604I6i1n3bfbHt4fT0KdtEOi/xdh81zlJL2Qk9Mk6fS0bo0axfTOmpiSbIRsZlVU0Q2V6iCszXqVCuDGlqqHr/qECKduEiGot50dy6LXh/ePUuKHXwyJ/vPncpJeSB5OQXXyJ05VZCWme5zrTBpWIUU3QU+yn22L5/bz28GFHX+EUzeGENRbzLLVx5pvCvDvwNpJqLYeK/24Jvp7Us/nn52pTHVI8+/sU2ci89lMGu5xNp/JUki7Dug6LEW1m2BZpa6HUreA75c+6lbbH+HUjSEE9Zay4ZtiK4T6HstE/4PPhc9/Uzl68UJyOpJ0qnJ2diZJz0SnMojpTMbQaRRRI2kkbTYbhHRNVG8RNek/XL7/qlwKQOjpNSYE9RaybCnXl548fMijMYT6tYZQY6Lf5heST5KcnZ7KWTqTNFXRqchMZ7IhpsRSRLuuQ9d16AA0o6iOdLev3X8lEU7dCEJQbyOjb7oMoe5tDO+vh1AHeo/7IjzLp5LOUhVTleqZyj4LSZnPpCeWQppJltmsPgbxbmYznqtSJ7dUWF+r7Q+uIyGot4xt33TXBqnpVgh1cpqkk7vs/nTA9k4d2teZyHw+E5nPxEgu5nMZhXT0TZesP7+1HAIYfNTXIdr+a0kI6i3iQt8Uqw1ST5600j17JsfNczk5TpJPk6RUZ02neibTWa1QG5J58EkzyTzn8mhpmc9Y5oOwAihDy7/e+pdb6KeOfLXjGYBo+28AIai3hIt8078fPOKz78H9Hwff9HPhTD/mHfmIuUmS0mkV05mKDmKq85nMZCY2mTAPc6fogDKr86doByFdE9Vzb28Th+eeLFlv+8/NpEaVeu0IQb0tXOCb1uH9cR1flmUIlY5kcpecTnWoSquYzucz6ScTNpxQFnMZh/gLya4DOgB5PluKanABO+L+b85/KGZSrxkhqLeAV/mmy3V8fxG2x3lI9FXOzlRS2hTTPJlQ53OZL+YyCmme17a/kCzzKgB5Xtv7Mp+FILyUretRttr+tYMXwTUgBPWGs/JNLx7en36hfPYsSfNcZfHRn3mWdfBNRdr9O8s501FMx6p0FFK0a1+wXf6AZZXadUsfNTjE9w8f8uJ51Ej7rzMhqDeYTd90benJ2gapjRAqvZCcjiWlcXD/TGazqZT9PYpQRjHNy0BqTpuDxuExr+JdON+oUm87/370iDvP9A+quroR9aK2P8Kp60II6k3mnG86Lj1ZbZAaQ6h2TPRPVdJUZTYVmQ2t/qaYdiwkjSDaBoVzlnkVULSAjc83ytbgtdnZ9u/+1ODqEYJ6Q9nlm24M7385hlAqbVbZ+/OHHNv8mcrSN12J6YQiIovFXIxgmZMJZNu0aJsWafBO0TYAVlVq8DpsGwDR9l9XQlBvIBf5puPm/TuPO5mq8nm7SvSTHstURaa7xHQyocggpKxCmjmnLUhbzGmLOdEAy0p1g0j7z3O4eror7d+hp9H2Xw9CUG8Yu33TuvTkXz/8IGMI1T1LcqD3uJHo65moTquYzmei87nMVUTGqhSrYX40LdAAaFqM7X27bPPX2v3o/HeyHUyt+6g7ibb/WhCCetPY6ZvW6593hVBjoo/5VHWmorMqpgsRmatIHvzShHE0as6y4PCYswzV6VilAoAxwqg3Z7NU/ebbqEivIyGoN4h13/SrraUnj39dC6E+/phtSpJTWo5HjW2+L+a6EBEZxHSxoMhCZNEvpCyGlXwcxLM5Ny8VXMBLL+zbNUO1q+1HiOxVJwT1hrDtm24P79/7MvH5GEK90Jro6yCmInVwX0S2xTS3HFL9Wqk2qP+kxZxpMSfQoqxVp7t91OA8h6/6hOAaEoJ6A9jpm24M73/JqSq79RAqqaTTKqYzpcxFRIUiKqKLhSy4LqZgIpm4oA0PNIOCNpuvpY1K9fexK5yKtv/aEYJ6E9jhm/790aPV8H77syxDqLSqTKdaxRTzuapQvF+oLiilbZlJLvqFpEFMgQYGcEiiYIsFMVSqY7tvi6hO/wj//G5LQKPtv3akV31CcLW5yDd9Nplw/8cf5cmTJ9JNJnLcNNKm/xCeqiBPNemfBPOZarMnEIqICIRSWlL6hSzYMpHsF4vh16+lqGFOzAFp4MYFxeFosEqhtyrW4I/hCAW9TkSFeo15uW96nzWE+nwthDoeQiitYqoieDFXERGczHWxWIj0ItZWMTU0ddZ0bPcXtVKtojkq5zDIH9XpH2dH2/9t6Om1IgT1mnLON8Wmb3rn8U+yHUJhOtX1RF8Gz1QWlNJ2TG3H1IKyWEjPhRgX1TsdhLRpMLT660dMg9/L9w9fTyy3R1Cj7b+6RMt/Xdmx3/TvB4f81906vP/kC+XdJMTRC8npI/GkAlXx+Uy1EXGhoF/oQpIIKdIvRGQhPZpakS44jEbVL2NYEHOiadx7b4BmvnwptphTYvQ8CKJCvY5c7Jt+vza8X9fx5ZTEp6e6Ph7lc9FZv6jzphyHpSg2iimbuj1qsXqsf31b+qoIz/SS+ecF1Wf8bXU9CEG9ZuzyTVdLT0bfVFhPQomcnapMVeRkPtXTRdLlrKmICCkovUpPMYAivUhfW31bHjEF6kkocPROm6WINms/AjHc/3bY5aNG2381CUG9Rlzkmy6XnnRrvmlKwumJbpyEEhEs5op+oaOYJrbsOVSoRBVSkDkDGUBdgLK6hmOjOg3eKVGlXn1CUK8JJHnON324vvRkfXhfl7eVYj5VzGeKXhWLuYpOVpUpKT0Xktiw73sxNFSC2oPW16XROQ8vYKxStwiBDYIVIajXhdXdQmu+6drSk2F4v81ZcpK1M/p36k2lezXRhyx0bPeNLaWn9H0vSpDlTMZW39jXNL8Ha6U6CGd4pleGaPuvHiGo14Bt33Rj6cnej7IMoRqVfFJDKOSp+nymSHPFQtT7haKXOnPaL7TvRUQWYg2pTW31gQzHWHFm2GgxZCCU9N2xK5gafdRo+682IahXnF2+6cbSk5Q4Ww+hcg2hVA42Zk11PA01iGlqwb6nsFCMpKM+Mho4SF9r5ccqNQiClxOCetVxr3cMff31uaUndx538vxplm4thEKeKudTPV3M9ExF0S8UOlfvVfuO0td+X9hTdBDSMrT8StC4qOKZh6OmQ+sfXB3Wq9Ro+68WIahXmOU3y9df46sdS0+mX5wPoZL+SfRABYu5sl/orBed9b32QkFfR6SUYGEvhaOQVs/U+p611a8Vaa1Soza9KuwanwquFiGoV5S1ymPDN10tPWk3Q6gP1xL9uaru7dVZ067+AKliSumlUETZUJlpBL0HgQTkhCqqgPULjlXqkrBR3xkXDfjvIqrUq0MI6hVkwzfFtm9ah/e7ybPNEGqqqgcq6Oc6zpqiF0XpdaxMKRQfRqOMWPqmSLn6pn1P5OE0chSmV5oIp64mIahXkY150y3fdBjeP26a5Z1QUxXxtcoURQfvtFdhWz1ToTjIWqH2Uvoixn6YO+2ZACBVFR1b/9DUq0e0/VebWI5yxVhv9cd5078/OuC/7t6VT1Liv58+la5tRY5bYZeHECrpPCdpFnN1V5VOxKaqkuoAP4WDX5rpqG2+sid6wNBDcnJHT3hy73syJ48SKAjenKhQrxAv803r8H4rd//yF7Y5S25WIRRyUqioJ122+dJSUGQQU4oUSumLsPQ13V971Io0QfueY5UaXH0i7b96hKBeEV7mmz7+da9u3n/2bLlBaiOEGhL9sc2HiG6KaS+WM7XJdNYxKQM4BlDIeRlGBVefaPuvLtHyXxXWfVOsfNN/jTeW5s/ZHx2JnB2rWNY7RRUpKZIqaQoV7fNE0lmv0F57aQWlaMpgT0oqhWXtGzEB6FOCAZS+BwFHTkgOlAteYhAELycE9Qqw0zcdlkXfedzJ8/0sXasibRJmFajIyXymbVkoXBVWFD5RyEL7TgSliqmQwoLhOhPQSY5/4A5AFwuUlKqS57y+LyC4hhCgxwDAeyVa/vfMLjGtvumO4f2UBHmqTFNlUoWqIqlCRSGL+raICinCcYC/tv1KUgBut/rxN+r1JNr+q0kI6ntk3TcFsLEsen3pSZuzYHqimCblPCkWSbmYK4pWv7SvQjpWpShFRTaFtJRevPT00hNDq798ISlk9boS5ejVIgT1fbLmm341+KbrS0+Ww/vrIVQeKtGkCl3UwX0tCi0qbARSxdQAkkVK6cWHM/s6DvGXtQAqqtQguDTie+k9cbFv2vBO18nznEWbZhlCsai2KSkWrvSFUlWBWqGKq1gxRVPqeBR7EWQ6Mz33lL4nCRgA7XuUlB3uy0AKqlHo3BDCR32/RIX6Hnilb6rKcYNUk+uiaMxnNdFPqlb6hDK2+lRIbfWrmA4r+UqdOZUe3Gjpc503Xa9SY2QqCC6HENR3zCt907aVLqWtEKoKKRbz2u6rKqRXaBVTFFFI0UUpytKL50whVsP7pWwN8QMxwH/9iWDq6hGC+q650De9X33TZ0lwdKTrIVQ5ep44+qZ9bfOTlTSKqTSUUmqyXyvUIkaK1/aPvv2Nl887PR5V6o2BIbTvjRDUd8i5Vv/hw82lJznLcfNcTlOS6XjBXk7LNt9KnyBUFNFFqcl+aSiLwmFUKlEGITWSMjwSgKWoDu1/mOdBcPmEoL4jLvRNUX3T50+fLjfvy3SqzMNJqLEyFVGIqFlJHJ73UhSFKqVukzIWMZIsFMW45xSru6FCRoPgrRKC+g54qW/64+Cbtq3I2bFymjXpXUEaQihVpYi2KgoV5SiqVpTMw2q+IqXUVl8BOgu9FCKtKtO0/CG4DUTb/36Ib7F3wQW+6eNf9+TgoJVukgRdFuwn6WdTZbqrnKsiiVq/SGYlWfHkpSRIUvZFmbPAimJBKZnUBHpJdCtcfisVgFpHaIyk9z0AwNyhmmK05gYwBFPxZ3lFiAr1LfMy3/Tel4lHk2dy3Kicpo9kGUL182T9IllZpHqsdDgJJaKwlZjWEKqIFIhZEU/1zL4s/VLAS+FGlRrcGqJKfffE99hbhAThAL4Fv7q/8k3/9cNq6clkbzW8f9LPtGuyUkUJVYiqlZKSleTmCRAFqUsxLRTNiQ7SSqLOCxUE1F0AWilg0p3Lor3vGQP9QXC5RIX6liA5iOm3xNfY8E3P1peepCTNn1WYpypDCGWlT140WekThQppanU6iCmsHtEXqaJKK6JkHeBPCT54thp/X956okp9t8R33NvidX3TlKSfJkVvyjycglLVxqnFJBktqSSFexVTEXR1xc4AACAASURBVBWH9IOISg96SrBSKKqOvgcTHEiAvvwlBkFwuUSF+hZ4Hd/02dmRvpg2dXh/WMdnZZEool76ZFYSRDQL1UtJSzElhi1SmaVQLJPFiqSksFKGY6YJNenvGX9jBsG7I77fLpna6jvw7bf86v79rXnTL/nvp79U37QksdlUsXdXS98n65G6rNpbSVRRZ/VNvbeERhUQpRUtKVFYpJB0ogqmAo7ClNT7vlDUwSH5tVIICa/0NkPEwpR3RQjqZTOIKb7+GgBw9OjRct502rbStVkkJSntVF0bLf08Me2rz/tkRZMbUoImU2iGqMEVZlrnTimYmxSSCoxzppUeAApSglt86wTBeyFa/ktk2erv8k2Xy6JVOM3Ked4IoThRNS0JWgf33WTZ9pNUMtdWf6hQnaQVEweXQ/wXeaZeSgQTt5wIp94NIaiXxC7f9Ginb3qiyJtn9CFDsm8luZQh2adCapsPK1oIEQ7zpkgsLKKq8AJCa6MxCmdkUUHwfghBvQTWj5Z+A6xGpACepS/5/GmWSdNIey+JNFPlPC1DqDoi1adsktwkJZNkasnNEo0KUgspNFMrwyA/yYQEN1J1GN4vJDAIbDg5wQ6iSn37xHfeZbDmm45XQI++6UHbCtsskv5DyvRMvTdFk9T6RXIvyS0lpyZLlmCiZpaYsoKmPatvOp6I0kKq1hEpqjpQAFMo1G395ZRCaIQQQfCuiQr1D7LLN733/fey9E3T6Jue6Di8b/0iuWkV01SSa/VMk0iiUH1hdUzKqKwPUSS6Ks2KQHVo71/W3MfflUHwrglB/QO8lm96dKQvmsE3Tam2+YOQZi3JTVMySbCS3Erdd8rqoUqikCYGiLEIzURQ7zjRQVTrNv7C8E2D1yHa/rdLCOrv5KKVfB//8IP89riTpW+aksg0KVNSXyyS55Q81aOlbpJcLblYqvtOqW6WIEUFFBrFCKGZ0ChOsFanrFulFIAOUhqKGgTvnRDU38uab7o+InWWEg/2n0rXqrTpP0SmWZlUS58TdF87ETXVlFJJrrU6dZekwlTFlAoThZkaq6h6Wl1lshLSBF2qaMJydCoIXkFUqW+P+Bb8HbzUNz1ohXdakfZYmbPSs3o/T0yqXhapN8vulty1eqfuyQ3JwUFMTQUiRoqwDCJK1uMu7kv/1AsoshY8KeIwTBC8X6JCfUNe7ZsmOc1ZjqZTxTSpLeaJw/C+mmU3TUk1uUhSkwRmTTnrKKY0KkmhQcxYhRWgKiDDDabja3GLgf0guEqEoL4BL/VNu06e5yyTRkWnjeo8D8dKVb30yVWTF0mudd7UzZKbJLgl95KGlXzKRCm+UCNFtC6LdoB1vnSwTMdHEPxOou1/O0TL/yZc4Js+TokHT5+K7u2pNI0CczUO3mnRlJOnflqyJk3JSurds6okd0tiTIAoWQbfNJGAEICttfqOYUzKCHcHpfb3vpxJDYLgfROC+pps+KbfgY/vgfc+3vJNU5Iynar3jUqT1HpNnhepTC2nrKn3kuGW4Z5gmpbHS1lnTsf23pnoQB2FKgVUhflKNKtbqoD20D6c0yC4KkTL/xqQW77pvYc8Otj2TT+Wo2lW5qzyp6SeqpiqlexJkpllN6neqTC5WBKXRNa5UyOFrJ4pWURYby8dx6LcbKNFC/80+KNE23/5RIX6Ctb3m2Jtv+nHd6tvWgbf1KYn6m1WJFNbaGqsTwu3rKpJF5ZNNSWXZI7kjuRuiVR1XyQ6BEaxBEox+rDshFB3K4QAqnDzQmK9vU8Y9vYFQXAFCEF9FZu+Kf573G96zjdt1JKqL1Jy61Nxyzlp6t2yiCQXJuvn2UUGMc1VTKFiNCEpMNBrnw8YgBrvr12yF819EFxlQlBfwq55079NJny8tzcsPRl906zeqHo/T2Z9Sm65pJSK1Qq1FMuyQDaVJAvLzFndLRWjkiaEiVMJAGIktF5IRQPMDYCDw9Z9RyEhoaxBcAUJD/UCzvmma/OmB0+eyFFa902rmKJfJFdNpprUSja3bG7ZRZL5IsOYmKnulmCmTBCS4kYRkCTFWYgyjGft/NOJeakguKpEhbqDC33TYd60nc8lHR2pNo26Z7XFPLn1qWlSWljJAs/unpNK6s2yOLKLJHVL7pJAqzOnBjEzUVUYashEqDsL6Qo3h6q6lR5eClVkY01fEPxRiLhv6jIJQd3FTt/0AR8n8ODpL6J7jdh0qmJ72pfa5nuTa4vvlot7Fm2TuWe4JYgk7y25eALrSj64qYlSVGlmhChgVn3TteBpOLvvkT0FwdUnBHWLXb7pdDLh473Vsuhy1igmUFvM6pLoJqdkJfdumUhZ3LO7ZVdJ0kt2Y1LxBCZFv0jQJDXZNxrqBinFcDbfjOYrz7SiAMruFxwEwZUhPNQ11n1TrPmm/6e5z6MnrTx98UJftMd60ua6jq/pU5tTKlZyrU5Ttrr8JMvon9KSlz6DSeGWqElIiLGu5qvHSwvdQDcjRKCqcG7NmYZ1GgRXnqhQB7Z908Mt3/Rg3krKH4tPTxWtqvc5oTB51pSdqfeUrJ9nhWdTSeaeZeEZmUmpiiGIAikFECFJyDiwX6tROrj0sxQYbjkJguB6EII68krfdDW83w8hlDe1OhWkrD60/EmzuGSXcfGJJ7hV71RVzE3EKBDAaQQMdAEGIXUzUsQFgBcjIC7F6BLBQRBcdUJQ8bq+6bFi0mjfzxOGECqZ5d41YymklumeXTzLMC6lg5iuFka7uLLeWOoABt/UReAgqO5eqqgCCkhUqUFwXbj1Huqb+aaqTKqjb2qmWd2yqGRbzBt3y5CcIKyJvtfroN0t0akkxFVJUETAukGKhMraH0SYpUFwXbnVFerKNwVx/7vX8E3nCTklN6Q0Zy6olSn7RSMumajpPnvPECYZrjQRUEzrJqnl8dICAARsWHRKGVr+QgocpRAbSX8QBFed212hLn1T4KthWfTfJg94lr7kwdNxWfSJak7qi3nypCmVPptpNresKlkW1phKNvXsuYZRECY3JkhSklp8GOJ3E6eJm0n1TwUQBUThZms3l97uP5YguK7c2gr1jX3TJqVifXazrGBeJM1QyfBFFtfqnTqzCpKbJRVJ8KLmFJJ0GB2gYBzcLyQNZqjzpypxXiUIrjm3shRaXmXyGr6pLWbJc0rZSjazbK65uDWqktkvGnfJLsPsKTzXm0slmVMdKqSKo+46FZIwDt4psP3bHztOg+B6czsr1NeZN82nWk5nydsmIenSN2XS3MMzF9ZQJYt7pkv27MmHY6YkFTBFXR5FMdCXEm6gCVwcgEEgXn1TccjazaVxiWkQXDtunaButfr470eP+PGvd+W3eScHf8uin6rY6Yn2zxYJXZPQa0rS5941MyFjYY3AGybJ6PvG1Btxz+wtY5g9BVRgVOoQQgGEGRTiBQAVqx2nO06V1lnUkNMguG7cKkFdu/KBWPNNz/4r8eDFU3l+tKe5afSgaVTudlpO+lTQZ5hlQd9gkRpJUitU75cVqrtliiQ468wpXag1hAJ12di7AwpxM7BOoRbAjIA6rHBM+oMguJ7cGg912zc93PJNT9pW8tmZppzVZrPki0VqsyZLJZtrNtfsyXKBNwJvxJnr3CmTiCSwiumwlk+tuBLKYT0a3UinEQKIYBDSgVvzpxAEN5vbU6G+wjfFWavYo2I2S16aZN5nOHKCZsIawIcHG4NnEVnuPSW5HN4HTIxKITlerEeBQ8Y5U6/tvALwHf1+EATXllshqC/zTdu7LzR1nbq0iuxa+pzM+5w85wWsIbw+6A2gDUWylL6he3Z4llFMSQVcHUq61cP4CsAAN4BicAAEHWYUEbdhiF8Q+VMQ3ARuvKC+3DfN8rxpRKaNHrRJ+4Un8z4XWEaWnOAZrhmlb+C1QjX0jYhkwBsnh9V8VABKCt1cXAg3UAedJB0+aqYCKEOPH61+ENwobvS39Kt9U5V81mhq0nCsVFObNbmlXObWFLfG4PUkFKRxYRZnJiw7maR4RtLqmxJi5uo0oUOEQ7oP1C38Vp/7uncaBMGN4mZXqK/0TY8Ve62WRZ03NSuZnnLKlgHPtSq1htAG4tlGH5WSvXiGWEJPhVLMIeQwJiVjZVpfAqxukUIBIXDIIKxkdPpBcIO4sYK6yzd9/uuv0szn0t69u/RNSz9LtCbZaZ9Ta7lH3xCpIbwB0WDwUAFv6J4Jz1Am9TKMSFHNIYJ6vBRCwJwU9+qZrkahwisNgpvNjWz5L/JNP/+v/+LJ/r6cNY2cTBvVnBR9n5A1mZfspllVs7g3Am3o3ohLfUtmiGSklLx4dmeCe3KaEhSjiVOGf0AaOfT69bUYWH+3Yz1fENxUbpygvso3PWg/2/RNm5Sy99lyygXemGtj8KaoNYQ0pt64MDtKQ7fsxbNwTPWpoIoTQoPQTMZ7oSCAWN0o5QjfNAhuAzdOUJe+KVYr+apv+pMcTJLks2NNbVYMS0+QU7JUcqob9+uxUpVGXBsXb+i15XdndkgGLcE9AVSnCN2VdAFJkMMQvxFeK9IIoYLg9nCjBHXLN122+r89fiztixeauiPVLiv6WWKTk1mfU9LsSbPBGkvalN5bcW+AviWkbpNiXR5dxZTJSDWawl2rgEIcQ6pf794bGI+d3qjf5iAILuDGhFLL7ftrvunj77+Xe3t78rTvxYZ50z2bJ3RNMuuzec4+s0ay1zlTonFFY5AGjsaHQMqtb8iUQEswTwSF9bYnAlUuCQBmcBF3GwL+cclJJFFBcCu4EYK6uspkbUTq8JD/p7nPX5/8LAd3PhOenSonSd2QkDTl2TyXLJm9N1igBb2laKOGBigtII2DGY4sosm9z0RN9QGIk6SNl+kB7g6KOGul6j5MTS1fZET8QXDjuRGCuusK6IvmTYFanUpKWd0aKBpQGxQ0KN6aagMbjpy6NS7M8D7DmQCvF+1BKEP4NIRQThJeSt2+7742YxrtfhDcFq69oK77ptj2TbfmTR2WDSWXqTXeeCNIddbUvVHRBvQGpW8BDEKKTPcMZ031vR4vBUCvt6U6CNCGc/rDldAi4u4eWhoEt4xrLajbvunhLt+0adRO52nSNQlekqHkjJQBNIC3AFrAW0PfoqCFSCPwLGA2WqYzgZ5QbzARcxcAEBBwJwCvhqk43KrIBkFwK7neNdTY6q/Pm96/z6O2lYPPPpPcNMrZLEmTk5U+55SyJ83FvTG3xqBN8UFUi7esYlrP73tphJpAJroq3dTdlag5vkPoDsLGuddhPEqu929pEAS/n2tboW6NSG36pm0rOD5WtK0uzpjQaLIZM2bWaKMNEhovixbwYTQKDXQ4p+/MAmSnDPOmnkCIkcJ6Tr9+fQ57+UTWAqhInoLgNnMtBXUppmsjUuu+6VHXqbat7s1SYkbKlvIilWz9vPGFtcjaOtAmeLts+90bAo0DDegZ5hkUJaDuEDrodNYlUlh6pm4gOaho6GkQ3GqunaC+jm/aNI3afJ7Mptm8yQWLRpEaJq2zpr23oLc2iKnC6+wpSkMiY3UiSg0QCmt7D4Jewyi6w2Dg8h6orVY/xDUIbh3Xz/B7Xd90kZNZzm4pF7emYN4WeFvgrQEthzCKYFPfr8dLAclwSyDV6UqluEMIEwrqRikMd0Mtf/vkOv5OBkFwyVyrCnVrRApHjx7x+Q8/SLPmm5a+TyxtMu+z03OCNBjW8Tm9hWsLlNYlNXBrBaU1oIGjbuInEsAEdwWEXlwow3xU8aG9F3cHKR6noIIgWHJtBHXbNz0E+Hgy4b3Hj+XF3bvadZ2i79NeaZOjz02bc++ejd4QqbGyaBWsnqmOvikbBxsRZieyu2eYJ6oIneJ0Edbh/XoiyuqkFI1jqy8OuiIiqSAIroegbvim34GH98DHH6980ztNIz6fJ7cusc3JZ5bdUtbxLD6tBbQ1lMEz1RbmLQSNW73JlO4ZRCJEUVxRN0bTaVXNvdDgXk9CCeDDRinQYU4stwYGQXBbuRaCev4qk+GcfvuzHHz2mfD0VI3U4nWDlOeci5eGRIPBKxWgBaSFeWeKliINrAxjU55J1DEph1KGk1BOihsAOkgXr5fvDUujHeCqLHUjGEZqENxmrryg7vRN71bftHtxoidtqwd9n9wsu/e50JsEa0BvCbQOtHC0rtq6lVYULc2rj0pmwLPAM4yJQoFA3FzGgVOvZ6Lq8hM6xOkxIxUEwS6udElFnvdNp6Nv+uKFTnMWnc/T6SIn5pzgJSOlutsU3vbwjsU7mHewviO8c3jrlMbJhkADMINMECjck7srCHGaOE1AG+6KGl7G+u/Ylf7dC4LgXXNlK9TVSj4Q93f5pp+Kz39Nbl0ylOzW5Jws063BUJkSbK1Wpp1CWoe1LGgNpaVIQzDDPRugoKsQJFi9UdJhDkeN82EgBiM3lDQIgl1cWUFd900x+Kaz5j6PBt/Ufv3fxPYjLd4nNDnZfNogpwb9ogXYAtpKKR3oHSmtwTrAW1QhHSpTz8Dgm1YDlM7l16cQ7hQHjHCpI/0QCGouFR1/EATrXElB3fZNHwy+6b2uk6cvTrS0rbL5s3Zlkd1LTlNpemqDhbeJqUXy1g2dq7bupVOVFsYW5i2FjQNZ6NnNM0Flvfy5XmHigNSDpXUsypy+XCKN1RWAQRAEW1y53vVi37STFy9e6J38seh8niTPklufkVM2L01ybwTDcdKCDvBanYq0ZugMaL2KaeM+nIoiE4h6N9Rw2Z7U+ScCQ60qBG3wUYG4dC8Iggu5UhXqy33TPPimp8mtSZZKdm+yuTWSU1N6tAloHX1nYOeGTogOQEeiBdgQbLwKbwagBJTu4sPMaT0BVUeiSHqtWH24F2qtx79yfw0FQXAVuFKC+nLfVMV+PU1mi8SuSWaWkVNO7nVRdEJrhk6Azukdqa0TLawsl0jD2UB8uM6ECkLqAr7xy6+mT+uyaC59082XGYP8QRCc58oI6qt900+UTVIzpDanDLdsKA171NNPBZ0TnUE6h3VK72DWAdKS3rihgbBeaUJXONQd5GiW1tfgYL3GBBSvFWmkT0EQvB5Xonl9lW86OWtV52cJZZFpfbZpaZKXRhfeCrxl8c6IjkQHoiPQmVlnIq3DWze0lDoi5Y5kzjpv6q5eJ0zJ4SHu5Lh1P7bvB0HwBrz3CnXTN/2Oh/fu8fHHH8vJ3p5on6U761T3s3ozS7A2JTD3sMa8tvkwdkp0Du8M7MTQuaGjyrCez1oHG7hnAgmk0iEUIdzqRj4OM6Z16BRwo1NIWx0njTo1CIJX8d4F9bxvesBZ0/CjtpXjz1TKr42yn6dJsQzvs8GbRDQgWhR2zkFIUZN9AzoIW5p3jiGMIjPJBPdEUgATd0Io8HFhdJX1GkJRVhGUW/ilQRC8Fu9VUHf7pnflXtfJi5RkcpyWvinMssMaZ24Mi0FM0SnQOcvEXCcCmxDSwdE50FLYwJEBZDdLFBG4C4ZxUndHvdLEAEitUoVRigZB8Lt4byYhVyPyO33T7iitfNOmz55STik1Bm9LX31SwjszVBEFOpfUOqQuRBFvUO+JynCvFap5csdwVr8KqwMEBe5GrLzcIAiCN+b9Vahbrf66b7qcN+0WCdamYswOa6xHq4LWk7bm1gm1c1hnRCc+LEGBdaQ09HrhXm31keCQccdpPQgFd3qN+B2rVD92mwZB8Dt5L4K6s9Xf8E1PE20x+KaaMxZNX9iSaBPQEewc0pmViVA7N5s4pQPqmBTq5XsN4NkdWjdJQehOhwAwiMNJGkCnYLn2ZCchskEQvAbvvOXfOSL14AHvdZ1MB9+0aZJqkxMsZ/fS2MJbhbfCIXQyTGCYgJiY2YQYTkRBWgEbjGv5wAQi0VnnTkGhuxCoS6WqhUqYb6qle6hnEARvzLuvUB3Lo6UYjpae7O2JTibSHR0p+kky7zPbnN2HIKqgZdJWvXRumJhgIoIOLh2UnTu6oSqto1LD4mg6FAaFOFH3Q9fNJ86a63NVlzLS/CAI/iDvtEJdtfoA7j3kgwPw5Nc9+aht5fToSE/m8zRtZklySrA+u1ujC2816VCdakeVDpDODBOYTQjvCG8JaUk2GMQUXqtTEMPik+qh1tGo4Tpo31GdBkEQ/E7eWYW6cdEewAcHB3x+9wf5yycdn754oZPJRMkDRd8noM8Ob6ywhaBjYedeJiqcmHMixASinZdhiJ/oCKszp+ZN3SLlCl+dgnLA64wp7fxCUyICqSAI/ijvTFC3U/3pxx+zT4kvXrzQyXxP9U9ZjfNUTi27oPEerUs9py9EB2pnZhMSEzNMhIN3Wo+atk42gNddp3B1cwWFtZUflkSTBgfrXlOvbi4BN489p0EQ/GHeiaAuq9Mdqf7zvhf86c+ymD1NzZlntk32ft6k3NTTUF46E3TimADSOdgJrXN4B5EWbi0gDeENnBn05HAlKCQAjqZp3blPDpHTuVS/pv9BEAS/l3ciqJvV6Vecfjzh9HEn7TzJnb3/EJs9TvAuLbIlmU0b16YBvPVSOhV2MExc0BE2oXPilNrmm3UgWtAbGBrQE+kKpwxHoIbDT3TU26Drcj4SDq9pPpfObhAEwR/i3QgqsFWd3uUnXyifn6iU6YnSk7ZcJBdk5pRBb8zRqo4D/OhqdVpPSAHo4MNFfM6GjgbEOMCv42hWXRFd7VMIx0K17jPFzjI1CILgd/PWU36uu5MPH3I6mXD6+LFMnyW5k0SaPNWcky5ySrCU3b1xaAORph4jldaBzuAdUXeeQrwlvIXUVN/oGUAmoU6KE0Kints3E/d6Lgq05RRsFKVBEFw2b79CXW/3//Y3zpqGnzRf8HnzXMq0V+0+kjw9SS5tos8zXTLcGje2LmjF0LmwpVnnlJbwlobWwYYczumDyVHvhiJBuMBRd/HT3QEf1vDV6pTkkOi/6sUHQRC8Pm9fUIH1dh9Pfkpc/Fl4Vz6ipSdi85n2SVUWfaJqgjK7l0aBxs1aF20c3hKsLT7ZuKNhvWwvE8gAElBTfa+b+IB6jQlqDEWvFep28LQ2OhUOQBAEf5C32vLvavf79meWJJyfHEnhAYuKaC+qKkqVRGGiS4ZIBlMGvJE6DtUIvIF5A1gDeIYhO6AOKiACdx0O63PwSelrg/v1+fDuW/0vD4LgNvJ2ZWXXxpG//hW9kqbComeShWIiUkTUhEqzhLoMOkM8A6inn8hs8AwiA0wOr1dAwxPhSrh4XcDHuvO0rg2Qeo3Jhe29x7n9IAguibcrqED1T7/7joeHh5g1DT/5RVn0NxYhO95hmc8lCUWsVylFjVQRqjkTvG7ZN2ciPQFMTqgTClCdUILijhpELUWVw32lVSyXijn+14aIBkHwFnj7gjpw9OhRFbHPgLvPhfsiNDmjy4RlsRDPpJFiZmpmSpo6rYomXd2hhCucSocCEDrFAaGMZ54wLkFZVqTuxvo2IqggCN4u70xQN/iwvrEz0jmjjwdBCSrBevwepLFepgcI64Z9AVzcXeguqHH+IKIkIFVWhy5/fTjq/fyHBkFwm7g6OtP39FJqNclCNxJmhDndnW6DOjoG4RzEcvgZo35ybOd9/JhEix8EwTvhSggqszs8OV0dBaCrD87oeD7UKcNQE+GAbY44kQ4H4Lsmn+J8fhAE74Z3JqgHDx5Urfs38Nw+8JN9c3Efyk93OhzeuwkMpTgBc4g5xUCYOw11sNRI2iCp9eFeB/lhVVwNVXh9UNi6WjoIguCt8vYH+7/+uorZQ7D9+Ev/5RP4fvf/uU4PfGrPvG1bk4Wbe29QLeZmIixOKYQVOoqDReDFwf+fvX9Lkus4tnXhMTxizsysCy6ElfRrG/c+smV8gh7RAXSC7aHQHnQCHcCjeMzWocn4L+GIS8TiBSgAVTlnuI/zEHNmZhUKICkSYF3iMytmIlGmTBGsgeEx3D2cUAgIEgExprPVAFQPUFX11FoG1Wg0PjIf1qHu9vXjCYAvgX88Q5Zk8aPSchUpFCUUkZKHhcusiFYoFsgKqGJUEViMLAQKBafkQISAkCCAIUJQzbg2A1A0Aa3wbzQaH54PKqjSTmf/w4dantxX/lNRilCKkMWxxojIuXP3cFkqiVYUKggVIEaI9YsapSiSCqgCsoh0Ek4iWKt+cToG0PYWKQAAOZ0KNBqNxgfiw5f8APAIwH0A//EUudxWF6EfIpR9L/ZVYrST6FJfNIwuYwE5VjHVCGGEVWElbRDUAcgCEqUkTCuj686+qQVVwKTnkurK092gv52pNhqND8AHdagApramRwAe4+nxAy2Gz/Qvd3XjreiKx+Aeubi7h4M2wm2Ex+jgAHAANQTSGsAQ0EBggDAC1aVCcJJOyaf4X6h9VLU71SigCWij0fjwfASHSuCLbem/BPT666LFHQ/7pgQPlh7LrsTpmwKiUByRbYB8oLgm0COip3GNQAdyu10KMrJaU4HTZVFVSevKKQihzVluXUZVWwA2n27nvLXRaDR+DR9cUDWvx5/K/qf/8RSf3b6t7lnoxe0Si2VxlOR9yqWM60LrRwID0K2ZvIui3gydgI5QJ9S5foIJ0wgqqkLWYSnBCBFSFdBa3k+PO4eogdoc0LoBGo3Gb8QHF1QAVbNmH/jkWIvVSv8anuv2cDu6nIMluyNclkbRM7yMtG5wj8HANcEOYEeoA5RZP3eCISFgImjTrP52Geqm0J/8Z33gu85Pm0ttNBq/kg9/hgrUvvuZhw/1t5MTLY+OYnn3brwqJU7Kj+F5LN1YCkoayX4AfSCwJriOiDURa4GnANYC15AGhgaQgwkjhAKgTDY0uG3rn5J/CrKtxLZgqtFo/MZ8HIe6pYrYcXWp3+Uctw4P3b45MealRSpFLKOIbLQBGTlG75LlLGOmIkPMRGSC8z7UWvbbdFJapTPVdX6YbeukrWxOtNFofDA+ikMFAO1K2cOH+tv9+5FL0f74xzhZHfgwFC+leJ+6glJGkgPdBoLrQKzpsVZwDcSatFMBgVIlOQAAIABJREFUawFrAmsIc79qAeDilPyToRr719R/Mq0k1ZKoRqPxW/OxHSqwI6y3P/ssvvn6a95ar6I72HeU0xJjMTGNKCmRGJgtK0pWQjYhUykrIpPIAJMQCZiujg6YqHpPnwKA1cWAEDSV+yQV0I5zbTQajd+Gj+ZQgR2XWttS8RTQ/ps/x/4nY7wav41hObrnvkTuCsxHFB9ZvAZTzupSPdY0nApcE7EGsAY4QBpBjRALwULQBdV5/7pYRZgtatXarZg2WW00Gr8BH9+h7ib+AJYnT/W8vx23b93y/HpBlRNzlRLL3myhVIoSCnOXkGUpE5EVzEZkgZlAApAAGkgaou5BFUEqQbB6EyrAKfencTuGqjn5b3OpjUbj1/HRBVXC1Jf6CLh/H0+PjvSX1Ur/ev5ct29/Ft3e6CzLEmOxzH7UeJotcfCcUwpkiZ0Zciiyqd4xZYYEVfEEaBAoqFb7hCAYq5ADwNTsP4VUjUaj8Rvx0QUVAEACO4tTlk+fan10FMsXhS/6EouhOFA8L1NhsoEjEoslj9Il+TqM2cBORCaYVR1qMsIUYdP11bUldYqkppH++mK9caW6UpsarIDp+cUfudFoNH6K30VQN9NTk2d8enysv6xW+u5ejlurQ+9e95wDqkAkM4ykJYI5wJzALEOmlBXKZswSsoQ03RtNg6YdKZzGS2ViHU+t7xstlGo0Gr8pv4ugAjWgqqU/gPsP9beHiL8A2H/2jN+PP0a/WjnHRVmp2DgogZ6YMDAxR3g2MAvMZimJkQgkTFdJ19IfJtbTUVGJhDgdBRjqwpTdrlTRZgVuNBqNf4vfTVABvB1QPX2q57fPBlSx7ItSGTGoXiNdSoYxhzObIQuRGcgis0Uk0Kb5/jDU3X6EDJQgEykyELDZndYT1lbqNxqNX83vKqjvCqj658/1chNQJYvwki1GEgnBAYWZVlN+C2YxMkM1oILq0hQzm+b7CQRqdyqsNqluu/wJTItSdj5YOwpoNBr/Br+roAK4MKB6fnQUt18UvkoHnv3UDlZ9iSiGIVIhEnNdjGLyHGI2TuU/kFSXppiFTIDROO+bBmQSZFPvPyZfKvxUrd8cbKPR+Bl81Mb+i9i5JkUA9PT4WIth0Hf31rFYeyyXg5fRPXJfyDzCUh1LLT4IXBu4Frg2w6mANUIDwCHIAcQIqYgqBAsQ9WpUYmr2n0ZShTrlT9OZhv9Go9H4Bfz+DhVvB1RHDxH4Etj/5BlfLg7d/vvEmN5Yzst6zxSUSBtUkMOYU0JSMBHISprOUpEAMyis7k2pb0EyQWECaPO7zyV+BOpKlUaj0fjlXApBBXAmoHoC4ME8QZUS82pwW/yBpXxviIVxiEQqWUaSMQWQDDWgsqkv1QyGkMFogKiYu6dqT39tRZ0MunZaqHY2/DcajcYv4dII6vsDqtvRvfo+0h8XJUpnafSRFgllyDQOMGQxz2KaOTlWEMkikkCjiRJRo39ChCGCZjYdNmi7fFqx8a91V3U7BWg0Gj/NpRFUAO8JqPa5POicY8fx5fceq0UhYhx7S3Sk7MyyyEFkQ2QhJQMSEEl1Z6pB2KT+tSGVImlSdaSzJ53PUiMCTKmFUY1G42fzu4dSu7wroDq8t47jtcfJ8+9Cd/sSw1g0bfdH8dHhgyWuyRgErhkxiBqItAY4EBwAG8DpplTABYVqw9TkTzcb/iEApDUpbTQav4jL5VBxcUD1/Evg1ifP+PLlodv3J5ZXi8JlZzxxs2QJZUjunpLV89O5hSoikjEyYEZqWpxSvSinMEqSWXXGBKCAxJgiq9iW/u06v0aj8VNcOkEF8O6A6m5ifj24LY3l5anHclEMPlpvCQUpSsnJmGW5BlObs1QZA5uz1Ho9ahAR81vVa6c1OVNCVUw5B1bv+7SNRqMB4JIK6rsCqsOc4/kwxNLuOe6eluXLYiMigf04B1SRc0rBFO45DNmCGQn1LJWbtaic1BKAiZJxWuIPTXtRz0xLBS7Z6Uij0biEXEpBBXBhQPWs73X75G4sk5N5zyOfFqoYkYw9E5wJJZIb6kYqICnVpB9EgswAGCCbkygCSQJA0DaiWY9W54XUtd5vRX+j0Xg/l1ZQ37Xi7/Beju9fGrtXLyPtL9xVPC2tUGkckxILUgaSMpJNTlVMiYhE0MC6iQoSa9hPsL6RBYK2zfsFAPNRwC6sHViNRqNxhksrqMBOQAUADx/qCGcDqm7Z8bCcljIWWzNSQjeSSk6k5MhBz0rMpnqRXzAswSxCdcY/apeU6vZ+se7wA0TO3akIQGaqA6oBWtoupG40Go0drsrBoADoCaDlyVM9Pz2N5d0Si/I/UZbFo+tLjKXQfCR9pPsY8IHOYZ71J2v7VEgjUxoAjjCMIApUL/STEPXuFNTrpwmFSfN9U+3uqUaj8T4utUMFdtuoakB1eHSk0/MBVTm1ZeqKp2KmfqQpyeeyHwlEFpA4n6WG6iJqwADSOL8RJYYxWA8GZu2kVSHd+uXWR9VoNN7i0gsqgDMB1RMADzYB1Uks07fkauUxLopKMcGToRsJJUApULKcOWUkERlAMtbL/AiYJEoiRJJRF6WayABp09ipprunJoENxHQU22g0GluuhKBuAqrzbVT37sX3L1fsXr2OtJ9cy7GkEyUuaADSWJCz2aCMFIGUiKSIpCQDzBRuNKutVGA9GqVAGcnYbEklrN6UCgHB5kwbjcaFXAlBBfBWG9UmoHr9jIvbh47la3opVlIUjGYj+5GM5JhS/1RF1VJKikigUl3lp9pGpaBNW1NEGYy0AAEDTDWUinO9qcGrcwrdaDQ+OFdGDs7P+T+ZAqo7R6dxfFLipJQow9Kj6wpyV1C8kGk02hC0wciBHoMQgyGtDTEQHBgaCY5G1jl/ylmlM0RFQNWdTu8e1talNBqNi7k6DhUXB1T/tVrp6F6O71eH3r1+TYzFerfCVW+UG6naMuVIQeYUSGIkgcmkxJQMEEMg69DptMWPhoDRIIlUvS51EtMppKprVN79gRuNxo3iSgkqgHcGVEfjGDaOwWHlvjeaxlTASIRGEAkF2YxDACkBCUxJ8qQqmlZLfxg4naXWSSmw5k/TYCo3/aigCYpt2t+2UzUaN54rU/LPnC/9D4+Pdfuzz2JRio7Xd2JcHXgZl74oxTGWguLFaKP3Nhg4GDkEOGxK/sQB4kjWL0huhFN0USFqs+KvBlOxfXejgmj3UDUaDQBXUFCBWvrPz588fKhDQM/f/Dn2X4+xGjz2TkdHXhSlrthqbxwtjSw2+iymrJf4idMZamgENSJUTNPOVMJJOoGQGJwL/3rsoDMN/q3Xv9Fo4IoK6g4XBlTj6sDXxUO5Lyhe5L6ZoqohFQfzaXKKHJQ4MDiCHCOlUe4uyCG4xCBCggUAESbQRLKu+AMwK2rT1UbjZnP1zlAn3h9QGbvXg99ZkD72BSevEhedYUCieWKXUxApQUnwpEAKIhFWz1JJAwiSIASRgsJEkwCYon4As+3ilLbhr9G48VxZQQXwVkD1EIjnAG49e8bF4aH7645eTk2pKxjdzKaAyi3BkZ0lJyKDKQEwIIyAkZwWUKGO9ouQiOmWvzrkP+/+3yygboraaNx0rrQCnA+ojgAtAd359NM4LiVOpuUpe91YkEtB8kJaLf3z9iw1EDWUks3BVEGoSHKp3j9FImRTr5RN56iC3nn3VKv/G40bx9V2qNgp/QE8BvAQ0H99+aVuvXihxe3bgVevwvf2XItFsehtUBhHJTASyZRQt/kLNMFTChhBiwQyxNpGJcBYN/ujdlPt3jfFOSSbr01pNBo3kivtUM+xE1Cd6M7RURyfnMS4WnlZLt1L8fDXjjmgMh/JGIM2kBwYMbI61jGo6lLJUtuo6AyEwBAgCsGUowrp1LVqrQ+10bjpXHmHCrwvoLoX369W7F6/jjvLpfs4FkQxrFE3UvXZ5GNSzsmIRMgUnpjqVSn0uohaUj1UFcHa2U9gHquyqUd1N/G/Tn9PNRqNn8u1EFQAPyOgqstT5Iti7IwMg58m67pBHklISfSUEpNCBiCBtJpGGaWY3gIwMyqCqiW/EAGaCZrm/pueNho3kmvzo//TAVVdnrIciyN7YfJilkZzGw0cyKnkD45BjpYwQCpBFUoFghMIkC4gSAtGVGc6l/ub5y2RajRuItdGUAGcmaB6DOBwCqgO1+tYDUPsLwf3fnQf61jqaDYWptHNRvcYzWMk64hqhI0CR4IjyGJkAVgIBKVQhGhzsz8ESZyENbRzW2qj0bgxXCtB3eFMQLUqRccnJ3EyjlHWS0e3KEhdwdgVeBQyRus5RNcPwRg5fWEOp+aACnJJLtJJetTD1ailflXPOfHnJqRqqtpo3BSuzxnqxPsCqv7lii/2Oj8oJ4ZFXxDFrM9G0TRMrVRgCsLgSCklQxSjkSHRwHodqkeGGag5oALM6nnqVj6bkDYaN41rJ6gALlzxt+p7/fjJGKuXRt8bHYNRi76gjAZFMtMoKIFIREoiUkQYoM2lfkIYQBrJQB0/tbo9ldMWv8mdQnXDnwnw+pnmNX+NRuPaci1L/k1A9egRgLri79vPPos7p5/G8d0S48GBl+Wer4p7eDjdC9yLu431a1v2M7ar/Yg8JlqB4CY6DSEy6gVU0/mtpK059WZUG40bxPV0qMCuS+WT5w/1EMB/DV/qKO9Fb8YoL8OXC8c4FkRYUd3wD2Kz4R9MKWUZfLp3ymTuMiNZr0clCJgUZmZSBAnUcEqxbfhXs6eNxk3g2grq5qZUQPgcOAJwfHKiVd/r22fPtDw4CL5+HVytvFssCrwYpGToRo2ol/hlWjgNVEqAiSQTCFddmjKNpZJAIJh226eETTsVbb41tdFoXGeuraACZwOqx/fv4+GZgOolX+zt+Z3lkmUcLSI8qy9APU9FzoYS1bG6UqRklKb1fjKSMBGg6rZUJcZ0DaqpimhAIAKIa3my0mg0znGtBRXAxQHV/7/Xj3c+iVVecP3qdWBv6VoMBW+K2aKrwulmohKpJHoCaYQZAgbQiKAEIkRLBknGkMEAmUGYWqnmbVSGaXeq45oeXTcaN55rL6ib0n+njerbPzyIP9wGvn3xDZcHB87lG+6NxUpaFI5uA5WIkth1I4oSaCmHmVASkxlhDDea1UWpAkASMgPDCTNsx1G3n2VnQVWj0biGXHtBBXDWpT4GHj4E/uvLL3V0by/6lTFel/Bx6RFj7U9dnyTrO+PkUsGSHDSAKRVZmIyUIUhYBiSIMS1PMQKoojpdPT3fo4rdNqpGo3HtuBGC+r6A6sfp+uluae6lmEoyWCooyYBI1mtUYWKmyT0FU0353Q1mteynmGQIBZhARV1ONfej1g8B1GupgLlHdbt+oNFoXAduhKAC7wmocla/XseLlHhnWHqJ0bDsC+VmXWdUVJfqYaBt7p1i3VhFQKSm/ikzUDG1WEERZIIEg6SdkdRmUhuNa8mNEVQAFwZUR7gfz14/4yq/5Hp4Fdjbcx/N8qIvdDcoEqmRyCZHQg6bDkvNJTMzEqJEQIVgquW/g0xUoFb5BMBsggttZ2qjcT25UT/VF01Q/f0E0/XTd+t2//XSD7pFYVcKUynF0ug2baSij0GOYTEGNTK2d09hWpoieRAKmQUVokw0CJvyv674m582Go3rw81yqMC5CarnqgHVoKN7OfqXd5j2Oo/lG8ZYLHst/QElgMloIzwMORmiJNKMRqK4yYwQqGkLdc2iYPWvLJvm/H1nC9U084825t9oXBdunKCeDag+PxtQfTLGYmHE6xIYlx4+WCA8oSvWJQNkRJiGMSGnEZAhZNPgKUUiiQADIoxBCE5DAuCgahtVGMDWjtpoXDtunKACFwdU3z54EH8AkL/5ht8fHPidN284jsXgi0K50c2AqCOp5AjSQFjISAVBMEmUTVdN1fgfkFFQnaAyyCPAMMB2Iv5W+jca14IbKagA3gqoHgI4+PJLPd/bi30zrksJ7fSmUm6jshFhhKyqYjJ4GNM0kgojFLXZv97qB4lmBilAn9qlCGwb/s0E9/rYuqgajSvNjS06zwdUR4D+Pm33/+7ZM52MY6zH72PVF1dxZ8qFyQstCiwKIgpjLNbZiLBCWQmLAlpRmENW756Sgl6vSZm/zrRNXdBCtXvO2mg0rg4316ECZwKqx48f4+HR5/qv1Zeb5Slpb89jWJKLjtZl0otZuAExOVIZIoxMBh9NrupWM2kSQENYQDASTgRr9mSaxNUUiBZINRrXhBstqBcGVE/ngOqTWLxcMC+za5EZ46nBu1Lvjj5NgBJzMiisTCv+jGYIMRkoiQjQkoEhE2EwE+Uk0jSCOt1DZUlo9X6jceW50YIKvCeg+grIJ9/w+0TeeX0csepdfmqSu6ErpQuD1ytSjJ0BnREiEXRaHeGvG6kAIxgG0SnUmj8BCjNx5+S0NlxNtC6ARuPKceMFFcDFAdXwpZ7f24v9l8bYOzjTmzrIzbwz4jQxZwNlKJEwbfVHKYYuU0Uk0tTRT1Co8T6DYSb4NDFlaALaaFwD2o8w3h9QHX8yxsltj3UpsTcuPcbiSF1h8mK2GhmpMKIYbSSjuKyAVhDFmbtiJicUokKwmNf9w+t6v7pAxUGD2oh/o3G1aQ51Znapj8DH9x+fXZ7y/fdKe3sxlDehxcKjJMt9Lgw3DErsko2UmcxYwphllDFU96UiRBpgqgcEBlLhRDhg6UzLFC2pSWujcTVpgjohSSRYO0TngGq73X+RXzIvl65hwWWMVpIZFW4pSnEaoQQkg40JIYMZyahN/WYEibCAOS0gIJkspjlVRL0IYCYApNT6UhuNK0YT1B2kCwKqabt/fvENv08d74xvIlZLVxmNkcsAN+vcDNmAMIqGAisczYoZTTbd47dpozKQEBjTSQNlAiCaapN/o/GRaO0lvy1NUM9zwXb/gy/PBVTDG3LR03xkHUvtjF0YlQws5l0yg0gYSVEISmQCGDQoaGQY6z1TNbfadlHtNPZ7u+Cv0bhCNEE9x0Xb/f9+cqI/zMtTXhrzct+1qKk/po1U9GzMYeOYEhGGlGr6LyMNZBGBuneKJkQIRlDgtC9VoiVxEvO2garRuHo0+3MBmzLoEfD48WMcHh/rv4ZBi1J0eLfE3i2PpXuoLM+MpY6eCqyOpzLqF2J0hZyZRWYuKCSEmUUIMrOYxbSW+/OmFEeNsYBIbRS10bgKNIf6LqpHfSug+p87WYvbPygvl6HyJvYXCx/djF1XSDcMkYhsVBhzMq/p/3ZpSogw1MFTE8Jrs3/yaVdqBFyOyc42Gh+Mdn7629ME9R38dED1kkfLpfuwYPhgMDMp3DwVdG5UNsY0859A0Kbx/bqTOhSAEig3pqSI4Hz1NIFpgmrnv/fW+N9oXHqaoL6P9wZUd7hOx4ySQ4s59S+FFsbSGeFWOtWgSjIUGTpjKkEkgEUkAVmCAZyq+2mz/85HsCShvP3ZGo3GpaMJ6nv46YDqdl2eMrxhRLEIt7Toik27U81VS3/IPIEmUJShgKC5FCCB8LBkabo7ta5RRZKoaYlK66Rq/Ma0cv/D0AT1JxDm0h+YJ6h2t/vzJemjR6yKs+to3nGQmykMilr6I4yWqCHMeqMml6pSDSnNEBBNO7m+13+4WtrfaFwVmqD+HM4FVMB2u3+/NqapN1XsKB+N01gq19yW/oObpVQgUSZDIZOZOwMIgaSFSQjQgHqB387VKExJLjVxbfxqmjv9cLSY42egeQj00SM8BoQnTzAvT7n9yRgng8d6KLHwFxF98fBwelds2vBPT4W0QrP6SCsmOSi3ojBLoWmzPwAFIA8gLAmY96XOtPq/0bisNIf6czlz/fRDbQKqnNWX75UO9iL6pWvoKR9NsTb2XRkVRrlRMrJjGUezZMaOjFGkmUuCGRChepaKqEbUHUwbOa8fA20ZdePfp/3H82FpDvVnslnxVwOqcyv+PomTYYh1KTGUH+s9VJ3Xpn9LpX5ZbfTnvN5PDpOL5lIJyWIaoJpWVJmYrI6kuqOGU82dNhqXmSaov4CLJqi+/eyzuHP6aRye3I29cYzD5dI1Lj3Gzi13RRFuKRd6KmPIabX0h5LTuiKUgMwlhcyC7opS+1ApiAYxJbnXc9Sf+IiNxjtp7vTD00r+X8pFAdW03b9/uWZKiVHehMrCZUb2uejEzbpcIDdaYr3YL0rtqJKZZSBGEglhBgMYAOXOBMCTv3UTaj1Xbf2pjcZlojnUX8j7A6pa+vty6fv90tEvXB7VifqJ06Ig1s6I4paKQp67vkhjyMwlhEkRgKgiTgFVXe/Xyv3Gv09zpx+H5lD/HXYCqqPnzwU8xMGqBlSHd+8GX3YcxjcR+SRi7BwLM4tcPMKYU9EgE8OstwIFEcnQEeFBS4SFEIQlMwlOwEEkMUFwR6ROlG96/tvfio3G5aD9LP4b7AZUjz//XEcPp4Dq/y76n69dp3c8YnXgsVz6Xl83UqG4M6UiDzezQksFMTpCzs6KSgmYeUghQ5isOlUkba6d9nkZ9XZ6qp2rNn6K5k4/Hk1Q/022AdWjbUD1h8/iztFpLJ4908Ftj1UpUabeVHVey/+Uy+CqQpqqsEpyhHkyuUFhk6hSRTJthdWkaYCq0QAAfPETYtnE9OPSSv5fw87ylO0E1aDn9+7F+ptvmPb2wpa7vanFYGZMqTA5FbIxwkxhuTOGggjzsIApIQwwr+OpAVSHOm/3x7w4pdFoXBaaQ/0V7F4//Rhne1Nv7/SmLosHxuKWumIpF3n4bulPSwWSQ3JYctVgqgZUgsxSENAspnMr1dlP02xr4yzNnX58mkP9tewEVHj8GIdHn+t8QKVldg3G6HOd9U9dYSKZElFODTkZIhkjMzQQllwhBBPMHEQhbFrsZ6jamQocAJHQ2qcajctBc6i/kncFVEdv/hzH6z/F6dpjXSKG4rHwl6HiruyOCEeEM20nqZTkCnkKc1OJZIpAiihQuGo45QA3q/2A2ZkypbY29YbxvvPT5k5/H5pD/Q0Q3t7u/3cAf+i/0sEny8BLI5b7XgYSi7qRSu4G0hRhIA1Bg2Rd3zPGkVPij2SYrkUFQ9MifwdoUysV5uunf+pTNq4jF20fa2L6+9EE9bfiXQFVzjq8m2KzNzWfxGrsfJSbkhkiTGE2xtpMyQAjIgy5g4ZgdPWqPqdbmvf5p3lJitdfNDFtNC4FreT/jXhfQLV010v/Vuv9EgfLpatfunJfZ/xTLpZSmUt/SM5+UWIsgSSXFK6ipBSEZH0NqOZm//n9m6beLN5V7jd3+vvSHOpvybsCqmdZh4d3g+klRzO6v4kovcPIM6W/aFAYAMLMkhkUTrMeJYaUkENFNAr1j65ge5Z6nnag2mh8bJpD/Q15Z0D1hz/H8b0/xen6TqxLiZhcKrqFo+tdc0BluXCRipI8R3WnsOShMUwpzBREkSxFaBtMRYK405LapqeuN7M7PX9+2tzp709zqL8x24BqewfV2YDqNmGZpbyJcnoS6jtHuLHLRI56fhphXBg1BGEGCWRv8CGScoo0vUUk1Fp/Okpl/Q1BzZ02Gr8HTVA/BBfeQXU2oLLl/tSbuqZeuWm1IrwYIgxKBhphtIjYbPVHElncPGckCXInsNMylep7OS5OfxtXh7+8w222s9PLTSv5PwDnV/ydD6hO7+z0pr70UNc7PM6U/ojak4oIV0puY12eopQiKYVjmqBSFdPdkdTG9af9hXk5aQ71Q/FWQHWk//3gQfzjq6+w+Ne/uPw//yfG/7cElktHP1AjiXCzbp8RhYgwS4lOMA21L9UEUKKzWDKEg5t4ap7zLwWwdO6jtDPVa0Fzp5efJqgfCEn1oLMGVPgcwH8COBp2lqes98KS0Wzpqz5zcDPkIDwMDFMi8yBTSgQJKQhLSEFEBs3dQoTPf4oFsJSEUtqf7DWmudPLS/ux+4BsA6rNBBX+fnioP/S9Dj75JJ6/fMl8YrybjCW9CZXeQVIRZikzwokUhgBlNs34O2SgFbdAjpRIqRDIQCpAKWDOoiQmyCB58y9Xinedn15Ec6eXiyaoH5rdCarH9aUzvakHLzkujOyWjqEjukS8ooGJCBrCDcmpINkFUhGLgWEJFsWoDBBQKTWgylnYSagKmqO5DryrVapxuWih1AfmzATV5zjTm3pvpzd1cI/RX4Yfvwp14cjhSDGFVdmRktugQEqeU/IkRUSKQKluFBAztG32L2186prT3OnloznUj8EFAdXdB8A/vvpKtze9qcfEcumFHdUP9FdrU5cdOQyJRNRdKBGqzyWmBLA2n1KJNC+TgSlgynIvYEmbdqrG5eL+Q+hv5167qNxv7vTq0AT1I/DegGrTm3qLZpnuJ+HHHrnvHTkRJzTQ2SXS12FYwBVBiAxkGBwEDZy2+iMjAXCfm/sdKKn9SV8zmju9nLSS/yOx+QG44Prp3d7UWO7VK6i74vKp9PfscRqhFB6DQil5tuRKCK96HRwhKolJchQwpWnXH9Dm+q8Ijy947VF9aO70atB8y8fkzPXTDwXsBlRJy//jgWOyFA9w6e6jJXdXxzqS6pnIzjSQYXXPNEJ0o6WkMJISCAEo28XTBIRSjer8g8mchXYj1aXiL59fUO5/AbWZ/atDc6gfkfcHVOt48c03Wo8ew+hRPGJViqPrHblzTG5VKdewKiUP1ZAqhYKAYg6nlFQd6tSTCsCSVDsAAJseGx+P//Xgwbl/50/O/vI97rRxdWgO9WNzUUAF4B99vdgPL78lhmUgGdEvHV2mykDkbEiFfZCREuVD3eofBiTRHLAuM9wtMusf7PyP2Z2W0qamrhDNnV49mkP9yLy94u+h/vMBdDAMel6KTu/ejfXBGONQohSPEsfhHqHsrugcKW9aqUKKFIqkFJFSxFhEQCYpJJVSYJJi97bpdpx6Kbj/8KE2pvTx5h9bmju9kjRB/R04H1DNy1OO/vznuLeeelMPSgx7HloufdUXh09ysT1mAAAgAElEQVSlf8RU6mfvIjlS/UpSWEqhVB8JyFKqi/wK5stT0BT1MvDkrVf+8vnnZ5xnc6dXk1by/168q/Qv53pTzVjcwz2FhnWkLgc8e3DNCAtQhGpfKkshjYquwDS9B7D9U54HqMaCknNLjj8mT97x+jvOTvnFBa83Lj3Nof5OXFj6Y7f0L7EexxjLvJGq+DL3rtK5cnjvczgVrhhCUkRWdaiRIoQ6QTW9T53tb7H+78HbgdR5zqrqF1+87USbO70aNEH9HTnzQ/L4Md7uTd2OpS7cA/3C0UUt/XN9jFAoZU9J0dnSQzkCoyxVUQWqmM5vY3NvahnPf5zGR+HJ9vx00tEz5f6j1nN6lWkl/+VgM0EFAAdf7vSmrm7HZix1/ZLu/bb0Jxw5M7sTkTxMSCGaZThhllKIpErh7h+05yyUEXXNX/2d1pf6e/EY2PzJA39t7vRK0xzq78w7A6q5N7V8o/V4K8ZSorjHtvR391D46WkgskcoQtNXKJIUgansh+Q5b75QRjBlzf2orS/1A/PkrSfvdKeNq01zqJeBn+hNXXaOOL5FLV/5OPREnxyFRElcdGS4iJQ9wsmU6VEYgjIQTpqlDEjQtDyFaSuglNRW/H1cHp95tuNO8QjA2TSqudOrRRPUS8A7l6fMF/ulpOVtDxwfEsvkZX1C94i9ju65IzgyPLFP2SNOaLbAGAUFsJxz0N2iFM6TUvP01FzuNz4GTwDU/tO/vWsq6osvzoon0eT0itFK/kvCtvTHWwHVvfWf4sU3ofUtjzc//KjiEfv9wt0j/M2bQO69T+GhdSBlD0WkpMhJUcZRLilylgFCKbA8lfvjFEyV1pv6oTif8O+60025/2h2p2fZXPbYuDI0i3KZqI5Ej/E5Pp9+8v73A8Q/vvrKbn+yDHz73WYstRjp7oGu9+7NG3qXq5h6IbIRLgIdciJoBV6KOTIk1b9FxxHMWQXY/Lo51g/Fk5/6huZOrwnNoV4izlw/PS1Pefr0KQ6GQfsXjKWqX3rvER4RyJ2HpsdQ5Mjhw6AyjvIBSjmFAWLOctWQqk5RNXf6QXmyffq3hw81j5nuutOL0qjmTq8mzZJcNi4MqB7gH/1XOshZL+7ciZSOaSfGW9MUFXLv/uYNub/vuYyckn6mLBozihVgoCUKNk1PBQoNWWdc6ViaS/2V3L1/X3j69Ke+7Qx/fcudEq2F7WrSHOol473LU74qWjwLHQy3Y2+/ulT0S9+U/vEm5jl/7GVHWnkoIkeOlBU+TU8BIwxnk/75efOrvx31/PQJgF/gTnnmv4HGFaMJ6iVkN6D6ywW9qXUs9VaMe+8u/SO0+SoY5IOUcppENW/GUmcx3fSitgmqX8evdKet1L/aNEG9rBDAF9BfAeAxcHj8QHfvQ/+axlJv3/HYL7diteex9Ah3D/S9e9TUP0dEruF+5IiInMM1KuUUSjlM0Jz2W4YwFmzaqho/m3ufffbuf2dP6sPfHj6cvuen3WnjatME9ZJyUUC1uzzlxwgNtz3GchhlzwOf1NJ/1ffeRQS6ziPPk1Nd5FAk5epQp8mpcSz13HTElPjX5B9jK/x/LbvlPoALt0o1d3r9aAnEZeZcQIWjI/z98FB/6Hstv8l6sW9a/i8Pe1VIksuI8Ah6rAPcZygC0RF5JMwAH5nQh2MKqCB4BoAOwFgPUPNU/o8jkLv3frwGgC+/3Dy9KJB6AuAIwHl3+sVcfcy0NqlrQXOol5iLAqrDBw90MAx6dfRp3P5kjMW332q/3IqVe2A5BVR97/U8tfdFzp5V26gicriklBUmiBkiptl+ZJ13p+009af52+4vdsX0yZMqppswapdHZ6t7Nnd6XWiCesnZBlRnl6ccDF9uelOP/bnGchjFPeoyao9Vv/AuIjw0TU9N56lZ4YPkqlel1LPT6T3GsgmnLHcChnd/sMY7eXv/6bmpqPNtUu3w9NrQBPUqQG4naR4/xuHxse7ev78JqE7v3IlX8Z3e/BAqvheLWNXEv+89OkWojzPnqVmRcoRL0jKHKWsOqQBgHkklurM/+E1f38nd+/fP/Lt6gne70zO0NqlrRRPUK8DmB+7RI1y03X+3N3VZ6hXU7goPhUdExEnUftQuQoqyxjQ9lYOobtUFASOqsHbalvut8Mc/Ln75TMI/lfv/68ED4cmTne9q7vQm0UKpq8I7Aqr/uH8/9vE1vlsAfHmLtveKPCXBCvqFd+s1RTIiaCy0zChmdXqqFwKAMNLVy+e3m0Z1TFlVVFtAdZ6/7QRSuzzB7E7P2tO31vORzZ1eM5pDvSK8FVA9rwHVXZzvTS2xGmtv6iIi+ohA13t4RHSKiIhQFzlyPU+dzlKJToQ2X/Wtqjs961hvNoflz28J4Fzuv+1OdxZIP3p0dgFKK/WvJU1QrxC7AdVfPq8B1e7ylB8jNAy3Y5zGUjelv0+iGhHIB7U/tVNE5MhTb6pJNaTaME7udKYdoFa+evulnXT/CSZ3ussj4K84Tyv1ryNNUK8aBPDFF9ME1RRQnUwB1deuFyW0O5ZaPMIX1aAucuddp+gUUdZrFQwqGpRzFVUAmIV1K6YjMALWdc1N7fDfF01IPdl5/nh7dvpXNHd6U2iCesU4O0F1dnnKpjfVp97UvZ3S3+f5/tpKlaOLnLsIdVE0yHQ2nAIAy+cDKtxIo7r/p0/fFr/p/HS33H+CJxe607dp7vS60kKpq8gcUD0CcX8noAKwn4u+u3s3kB04LsSeEadOeA2qQBIeREciAqZCAxW5DyujBWs4BQBWzSmskzAA1kE3QlD/ef6Fr7cPn9ai/2D+rYuWobzXnbYg6jrTHOoVZPMD+cVOQHVuecqLCK1vTbelllWURW347yOi6/voopb9MbVSmdaK3EXOe2GSrJM2YrrDTS79Dz8tAoCDqdw/406fXOROz4kpWql/3WmCekXZDaguWp6yePZMm7HUPY+l78ViGeFz6e8Rueui6yJiKv1N69rgPzlRU3WmZ93pWYt6XQV2/49/qv+/zvWgfgVs5/cv2tR3xp2eg63Uv+60kv8q857lKffu3YvvFgusXz7novwhsPf6bOkfUZ/D0FlAKox+EWWUZXSARqB/x/sOmNpSN0+uIc8AzOenX7/je57+fHfagqgbQXOoV5iLJqgOHzzQ//7ss9j2pt6JPr7TfimxKqtYLjwW7tH3i+giIro+RkGRu7A1ZBhUJJVOMnUbh1pdan2/sutKh6ueUz2/8NVnm2dfA9j2n54v98/wPnfagqgbQRPUq8485//o0Wa7/5ne1Ge1N/X1d6Gy51F8L3wu/T0inZyoi6hz/rmW/4aa+g/DgNLV89TNWeoFZf+W9TtevxqsjuI9DvKrc+V+rfd/njttQdRNoQnqFWcbUL2jN3VwvSjfaH0wbpZRF1+Fu4f3izrr732YpLSWylrVrQJVSCUNkwsdhq07NfQbgbCuv9pi8a93vH7u/PSiMGrzm+9xp01Mbw5NUK8BZwOqi3pTP4lt6X8Qq+I7pX+E9zWk8k7RdRFpLRVJhimcmoS1utTZnZ5/vCb8cxtIzf2nh+XPqu50+p4dd3qev17gThs3hyao14VzK/7w5Anq3lRsx1Jv347X8f250n8R6c0bdX1fz1NPoei66HIXRZL1kAE640in59c14X+2OUH9enqcx02/fMudzktQNjP752ju9GbRBPWasPOD++7e1G/qWOqb7+fz1FUdS+0XEaF6ntpFjFprXEsbUVVdNr0V1smV7pjUdEXL/uN79y7+3FO5P7vTg2EaNZ1apZo7bVxEE9TrxPwDPC9PebgNqJ6XosX4TAv/VvsHJfbLQaxWHktfxcI93CM8FhFdH1300XWKUdMZKoY6499tt/jPz69PwX/2IPXtcdNNvf9ud9qCqBtPE9RrxLsCqr+fnGhViu7duxend+/GpvT3g2kjVUSS1Pd1zn+ME41TSBW5C5NU1GsYJmFVJwyzsPaa033r+is7mro6OlI9P3VVd/r19DtfbcOok1rub8zp4+16vr8+unBov3HDaIJ6zdAFAdV8sd9c+i83pf8PtfRfTqm/R6Q3quepU0iVUEv/NAVTpes1TM70TAfV9Li+4q1T2/7TC8KojTudW6V2Fkg3d9pAE9TryTsDqqk3dYxN6d/9EFoVj2VZhS+W4X0dTU2SkiQPRUEV09T1wrCeXGovU3Wnacelpv7yn6UuP/lk+ozPL2yZ2pb7b4dRP8edNjG9uTRBvYa8HVA9125v6r1766i3pbrG/RJl7yDKMiK/eqWFewyv38j7RW38l2SCNqKqXlsBndzoFS3z50BqdRRvl/tf1+/ZDaOmZqmz7rQFUY0dmqBeV84EVGd7U3fHUjelf/Eoo4cvV9EvFtFH1PS/6yMiYiOqnYRhjVlY0+RSd89PrV9cYof23bumTc+W+59O5f5OGHU4N/LvulOcpbnTm00T1GvKRQHVtvT/bDOWunBp/+BWdB5arVZxenwsdw9fzO70RGNI0fUbUR3Vb4R1d9x0c366viLnqDvl/raZv6i606+A/6f+3t2T+3oKAE/OutPWJtU4TxPUa8xbAdX53tTBtSzf6Nifa9wvcRIvtFx6LBeryK9CddXfIrq+j3RSk38TlHppPaxRhbV+YXjH+ekl1dbnk02dy33g2ZlR068AHPxf8zUnF7vTFkQ1ztME9bqzWZ6Ct3pT/39Hn8bpNJb6KkLj3l6Uvb041bF8GbFYeCRJo6qY9l0fW1HtN8K6HtZvpftbcT294EN9BH58/28vzzX0P8POqOmnRdWdfrnjTvG2O92hiWkDaIJ67dmW/ji3POVE/z2PpT4LHQy3Y7/cmlL/VRRfxfq15B7RxyL6fhGjTlQFtooq1gOqsNYvALD5zqtL5Uy/P/OrM0eoF4RRF7vTJ+91p40G0AT1RrBb+m8DqneX/mXPI8dLLRceQ4SGkAZJdlLPUueWKuv7jbACO2IK4LIo6g8/7P7qu6llqrZLzev6zodR9Vlzp41fThPUmwKxCaje2pu6LppL//WtW/EmQrX0lxZT6e+LiOgXdc1fVJeaJiHZCOtEmi75+52K/QtZ+J36+S5K+P+xDaO+wlfbVqkL3OlfgeZOG++kCeoNQVvBe3tv6qdls5Fq8a00l/5lp/RPr6uAjicn8r6PWVRnYZ1L/vo4N/lfzvapen76L+CfwA9/9M1n/DnuFMCZ/0/NnTZ2aYJ6k/gZvanLEpvSP8cL5XipsvA6RbWI6PtFZKEKaT+JbL/Q6XqNJGlumToFgPXkUU9PkRa/j7j2t+9s3nf5ySd6fsF01P6fPr3YnR6fc6fnS/1z4tpoNEG9QWwDqot6U+ex1GdauKvfSf2Xe3uRX73S8Go+T32jGlJJqV8I61OkflGFFVVMZ3d6eVzq2Yb+1dGRgH9iDqMudKfnp6Jaqd/4CZqg3jA2rmp3ecrxA929P4+l3ou700aqufQ/fREqy1UslqtYLJbhvog5pBqnM1WsT4H1KebAauNOPwYv336pv3VbNY/6fnN++hzny/0/am6Vmt1pndmf3Sk2V5u0IKrxc2iCehOZAipgCqh2elMPS9EP00aqYw+N+4ex2juI1Wo/TuNYa73SLJqbkGqxUIrJre6Q+oVw+hGF9TxnEn5gm+4f7XzOr3FY/qy6ou9L4Cnwn/NGqecPt9+3405bqd94F01QbyDvDqhO9N/zWOq0kaqP7/QmftCJXmjpe7H0VQxRp6iSpKwTDbMrPT1FCm3FdRLTtKjP58cPxgugP7yl2tT/w8756XdY+idnRPCHP7r2y9ad4sv58r2nZ4Koi9xpo/EumqDeVC4MqM72pu6W/vvlIE4jNLdS5ak/1aOGVMNiUcv/OXy6QDhP3nrl43G+3K+8251umvjPzes3d9p4H2xHQTcX1uIfAPj548d8fnTE48ND/sdqxf1v9+z1Z5nL7zt7sUi26F5al7PllOz4u9OUc7LFPmnrZEMy60kWgrFecwkAy+X2jSZxHSaHmhfLTQ/rMJ/BAsiShmUIb4C80uYxx55e4xWy9gUA3fT9pxGbX/cHh3rx4gX6wxB+BPpbodcRquen3+HYXctyT6uj0A9eJ6P2/1T0r1JUz04hPH2K/zx+oKOH2Fxt8tddAW3z+o2foDnUG8zGbZ1ZnnKuN3VT+ofeROjkhbRc7sVyUftTB0n9ImKQlIV6B9ViodPT0yqkp6c4xVkxff+n+ileAQCO33r9xeZZf+u2diektgult+50/09Fh6W81522IKrxS2mCetN5a3nKud7UwbUsRcfu6r4LvfFQLf2PlUNaLpYxTE3/g6S8WAqnp7DFogorADvfg3o6Ff8nv90hwFZOgbNp1Hd4/ryW+6ujI32DfwL/+MdmZh9f1m38T8+dneIRWqnf+MU0Qb3hbHtTcXFv6u5Y6sGt2Ns/jNWeRymrKMtVrPVKOULz/tQqqtWt4vQUNv/v/ybudJfqUbuDrWvcBlK1oX8zbornwL+qO13+8Y/a/9OfdPhpLfUBAE8vGjHdcaet57TxM2mC2rgwoDo8fvD2WKprSv1DOaQc0ulxaC0pR9R0X1LSUjg9QV4sN451V0zTbyqsEy+AeWff3H8KAMeffKJ5Vd9b7nRq4v/PBw+0uzz6r+fdaSv1Gz+TJqiNCyeojh5CT1F7U7djqd9sSv/OQ6fxYjpP9Vi/lmKxjDRtphrm4GkS1s2bnW7L/GH57wtrt7+/daYHh9vnt25rW/F/Bzzf9p7O7vRfn85B1Lk2qSmIQnOnjX+TJqgNAG8HVHNv6u6VKXPpf3hwK8b9Eqtxb9NKlUPKU8k/O9UTVDc6CytOT357d/oS2Jyg7vSfLvyO/mfzTf/CN//855mN/O8NomZ3yuZOG7+M/FPf0LhBsCoIHj3iX774Qn+bXr4L4B9fFf0RQJ+SfvDv1Kderz3UpVdaldtxskyAXlkO02CGPgAYcHJ6ytVq9ZaQnpycIO22VuENgBV+GccADvAC8/npj/gBQI/vATgW/omWJfTjUWjprv0yt0kNunv/vp4+fYrDJw827hSPPj9X6rcgqvHLaA61seGi0h9PnuCtsdRSNNy+HfsHt2J/by9OpvPUHCFfrmrT/+xUl0sNkk52Ev0TAGlT7v900v965/mm1D8GuoOD+nw6P90t96s7fY5Nq9QZd/r/tXdvO20kWxiA/yp3N263HTDIm42UrYm2UC6SS14gL8HzmDwPL8EL5DJcIBRFmpGSjDcxYLfbh+5a+6KqDz4EktAkjPR/EiJDEsjc/Fqr16pqcBBFj4KBSssqA6rl3dTyWOp0d9c0jZGtbCCxKZ+nplnL5K2/Z4x4Ui7tV4M1X+oHgIaxweqF4XdXg6OlLdTqzShDBNt2mX8rs8Oo615PmvuZlEv8tjq9cxDFVp9+EgOVloiIFJenLO2mHglwji+pnfqHxsgov+Yv6piw1TK+20/NtkLjhfbUkxe6UJ3YSrSxNIi6vzpds5KlSbst+bpUuX16hfwilG9Vp8C3B1Fs9elnMVBpTREo39hN7aQvllr/wFxJYIwkpqxMZyLiSUvmJrSh2mwuBSuQFNUpAPsIdYUXtlaCzZ6Ssm1/NVmvETwzEpgdwVW5KnXdM+vVaZIU1SmwaRDFVp9+HgOVNrtjN/XzIVZa/6xo/dNWy0xdsM5EBJMYk4k9pw/YCtXeSFWGqRfe317n5/gBLGepG/AXd5/uZJI/Os2r048fyz9uX2tyVlSnJwB3Tqk2DFTaaHVAld+benEEwfm3W3/fGPHdS/48I8WQagJ7EcrGUnSy9GmDcfGrPEv9dluStr0cBdco+n1bnZql6jR8XlandhCF4uJoVM/rszqlB+JtU3Snu26k+nfwSn1u/qWbX7/q6cGBCm5utO95Op54OtxWKkkauqmUms4SvaWUQgtIp1q1AKBV+SEuScubploCxPCkJXEcwwuNeBKJb0RGGME39tdJ20hg7K1SgdmRrczIKBO7KrUw0pxnMpilEiaptP+Yy4ckkc5oJHl1enp+LtVWn9UpPRQrVLrbHa3/JS5hb6RaSLX1j1ptk9yUy/75Z0wAr2mr1ckENkg3Vqex+0K89hx16fnpDfLTpgC+YrQrm6vTP8rqdHkQVWKYUh1YodK9VqtUHB/jw7t3+r9hqMZBoNqDge6+eKGGw6EOgkDPtVZ+7Omwq9Vk0tBNrdR0mugtrVSqXEK7ajX/GZ6rToHlu1BnpiWIx/BaIr6JZGqM+G2RxNjqNDDbEhtZq0739g7MlxTSnkO6iXtU4Z6dvgbWBlEMVKoDK1S638puKk5ROZY6l2h2sDL1NxJkRhL3PLUYUuUVa9iygWmMeE37kf+ovCKtVqZeyw6kilnULSrDqCE2VafAR9grUM7xbuW8/gnAMKVHwaOndC8REaWgIH3BW6jXfch7vAHgjqUGl7KfAleLhewYAz/LZNbeNYG51bHREsIgaYk0lcFMa2xNYuW1IGmi1PokKi5OocYx4IVjABF8E8kUIwAGt2jDBxCYbVm46nQ+ECAFmrsHEqWQanXaOYL0AMlPRJ3a6rT4f1v9FxD9LLb89N3uGlDZ1r+puy8aajgc6k7jX2rk3+pI76qGN9aTyUQ3tVapUirVWm0lZesPRJWfYodRQIyZaQncq0+mRsRfafdj93m+vW2axsi1WT+zXx1E2VYfQB+sTulRsOWn77dxQFW5kWpWnvUfZeKecdoAbLVaZmoi8SQSz7RkFpatPyYx7In9uJhOxe4Av90/HSNv+G9dux+YbTfZ33F7p1+wdgHKyiDqBCjDFKxOqX6sUOmHVKvUEwDvATUA1EtA/Xl5qfc9T11dXekd/7nyt671rNFTvner57qrvMlYL7RWTTecSpOJQgREiJAmEwWUK1Nr1WlkxJf7q9NBmkr4zeq0HEQJX2lCj4CBSj/su1r/oKGG4XLrH0/GOtRKlaEaK6CNMljdzVKxDVZ7umqMqYnEN/Zoq58ZaUcdU072/5amO7W1Wp1W32B6atek2OrTo2LLTz8uj9OV3dQPyauy9d9fbv1jF4aJexY6NSJ5O++FLfuq6BjwTMs+CnCno6YmstVpW8RvdyToGFma7Kd7cr3oCf4EvqQv7E387rUmNkyxdiKKYUqPhRUq/ZRNu6kDQPXOz/U4CNTG1n98q+cNrcKuVgulVDPWaqFdlari8txnbFel/EhkNLIno9ar04GM3PPa1er0rkEUW316TAxU+ilKKQUR4O1bddLv4/0p1KB3dufUf9bQ7nmqVqHWajKZaKCDpgvVZWWrv3GyP9821SOm495zU13it2tSq60+r+ajx8VApZ9WVKlvoU76bkB1BvWyAzUMoaLWRx17nmp+/aqn3oHqNJR7nqpVPJnoUGsFdGCr1DxYAd9EMgLgR0YwGiEx7Up1eiVbWSajLJNut2uG965JcRBFvw4DlR7kR1r/qadVENzoudZqc6gCQAdwF6DYz21JMiNBx1anncUzY4+YfpLrxUL29vbM8iCqEqb2G3IQRb8MT0rRw9gX+9kBVb8v70+h0DvDh05H/gt7LWl7vi8hDLAP+NeZAECALtDaMXN9qxZjUSEMbJgaABH8tsjtbRtpe7nV/x+usL23I9emJ80sE6Qp2oeH0gXkAmWrj+NjYKnVZ5jS42OFSg92b+v/90cdH3qq28ifpzbUrNFTkVZqrm/UXGu1GGuFZ8AzuOV93MLP2hJ0Vi9A2bwmxVafngIGKj1YMaBy/7lpN3Xf89Tq89RZQ6u5VirSN2o+0grblW96A9gwNRJvvOv0o4x7PcOdU3pKuIdKDyYisnk3tbyRKr/h/3rRk2Zqw3Ers0dTY2Nk8bxjb6nKPzLb5udh2nS3SYXFXacHAgD5G0y5c0pPAStUqs3GAVWl9R8HUO3BX3oaNNSOr9XU02rWUKrTuFbALub6uthFDXZ2BF+/YivbkdGuSNMYCY2R1an+2iCKO6f0G7FCpfqsXJ6C01Pk76HqvoIAl4gOUmnOM9u2p0a2MpH59rYZZUY6z54VVerWwMgo27Ft/p1hWl5+AmDpJimiX40VKtWqHFC5hX9ADc7O1p+nfvJUXqliH5heaYVe5RsNgOaevXi6GqadNJXP88OVBX7g9TEHUfT7MVCpdtXW/wQoQvVlp6OGK6GK/zzHtPFJHQBIdPlKFHwBwp6RT0BxLV8nfSGf3Wko4B3Y6tNTw5af6le22zbYTk/Re/NGLkZH0q0MqQazVKIU0swyGWaZXLvWPjRGprv7ZphlSxdGf55DgHNUw3S91V/71xD9MgxUql11sn5SPE+Fe55ahmr4PJUvKWTgNgD2Dg7M0IVrlEKiNJVB8cz0ULqvsPbc9PXxsW31i5/N6pR+H7b89CiWdlMrC/8AMADUy3fv1DAMFfAK4+DS1pWHhzh0f//yErAv2QPsAOqVa/OrK1J8eyk9LaxQ6VEs7ab27bn61+4RQA+Qi9GRfEgS6SaQ9nxuPwD57D7a8/Lr3SSRiyO49agyTPEWDFN6Uhio9GhW2m8BXKi69r8zGsnFEVywJtIFyg/X3n9IErk4OhKcnaFs822YnvD9UPTEsOWnR1eZ+pftf7H4f2Z/782bzX/57AwAsPbMNK9Mwak+PR0MVHp0K2f9gbdvFfp9HJ+e2jC1N0N9m5vkn+bHSithylafnhIGKv0SG0MVAPp9+3pnuKrVeW0vOAEA+/v5JJ9hSk8YA5V+qbVgBYpwPen3l7682toXGKT0RDFQ6bfYGKz3YZDSE8dApd/qu4KVQUr/EAxUehI2BiuDlP5hGKhERDXhYj8RUU0YqERENWGgEhHVhIFKRFQTBioRUU0YqERENWGgEhHVhIFKRFQTBioRUU0YqERENWGgEhHVhIFKRFQTBioRUU0YqERENWGgEhHVhIFKRFQTBioRUU0YqERENWGgEhHVhIFKRFQTBioRUU0YqERENWGgEhHVhIFKRFQTBioRUU0YqERENWGgEirr1iIAAAAOSURBVBHVhIFKRFST/wNM5Nu9Gw8IkQAAAABJRU5ErkJggg=="/></g></g></g></svg>',
        he = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 406 241"><defs><style>.cls-1{opacity:0.36;}</style></defs><title>资源 11</title><g id="图层_2" data-name="图层 2"><g id="图层_1-2" data-name="图层 1"><g class="cls-1"><image width="406" height="241" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZYAAADxCAYAAADofpHAAAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4Xuy9TZIbRxKte45HJlB//JF0abrd1m1PA410h9pAbULraWk9vQluoIdPk9sDmXVb6+rqSU2KLBaAjPDzBh6ZSKCAAqpYlEQqj6kKmRGBH6qA+HDcPSIpCZMmTZo0adJDyQ4NmDRp0qRJk+6iCSyTJk2aNOlBNYFl0qRJkyY9qCawTJo0adKkB9UElkmTJk2a9KCawDJp0qRJkx5UE1gmTZo0adKDagLLpEmTJk16UE1gmTRp0qRJD6oJLJMmTZo06UE1gWXSpEmTJj2oJrBMmjRp0qQH1QSWSZMmTZr0oJrAMmnSpEmTHlQTWCZNmjRp0oNqAsukSZMmTXpQTWCZNGnSpEkPqgkskyZNmjTpQdUcGjBp0ocgkjw05njdcjnvh7zS951e8fGDNV2PfNI7Fqf32KT3QW8PBu08nHQP3fhLvOWfBhPsPjRNYJn0u9BhcGjjZtIfXBvvluPANsHr19MElkm/qvYDZALHpN+RjgTXBKvdmsAy6Z1pN0Q0wWPSH0e8cTDoQ4bSBJZJD6qbMPmAQPLNNzdmh693DDusv71V9zvVN4cGAP2gr28f9Pb6298+lHfOceLwC8D7DZ4JLJPeWpsw+Z2BZAcMdunrGy07ZvffcsL/A+vrQwOAHUA8ipCh9wFgI+i8D8CZwDLp3vrNgHIELL4ejkY0eE/A8P/+/e8H/33vo/7XV1/9Wu+Qnfr60IBjtMGrA/B618Di7xc0E1gm3VlroLxDmByAx9c9JX5lWLz9pP/VraeT9ujv9+68VXeF3deHBhyjb24chN4GRNXR/F4gM4Fl0tF6J0C5BSBf42/vDBx3B8SvD4Qfnz+/42v84+rZ5eVDvSN3aye7DgPtf331lb4+NGiXvhl+3R04vwMnM4Fl0kE9KFD2JsAfBiJ3A8ZXOw/vo/tD4PKopnetV//4xz1f/7vVoy+/fNt33Kae37njKN0JbH/fPBhOD7mnu8LmN3QxE1gm3aoHgcoIJl8DeFuIHIbHVxs399HdQHF56HCv/vPWE/qXb9X9a+m/3357r3/nR198sfGu+8e+gW/X+Va6FX7P954MugGlv8evg8D55kjI/AaAmcAyaafeGigPBJPbIXI/gBwPjcuNw9HZDd0PEFuz/gEI3Hdy3q0vDg24u255yNf//Oe9XvvF558f/+779n6dt97tCJ1swW/QBsv2g20A0/O+ZTgYoBOsGYXetmHzzTe/K8BMYJl0QwGVewDlLWGyHyJ3B8hheFyuj9aHN3Q3YHy5cbOt+4Fhx2w9arrvhL1fnx8acJSu//0d8dmhUQ+s74DTv3x24F37z9u776H/XW/n2xDcINZ+fA1g+sfwC8CWE3r+fDh8dnmpDdCMIXMUYN49XCawTNrQvaDyFkDZDZPjQXI7QC7Xvy9v9h4PjS93HgJ3hcUXNw6PAcPNqX6z5dWDTuKfHRoAALj6/t8HXzf+emjA2+vfhwbs07/2d83/9JfRu/+7veOO0Wkeg+6fA4S2Nf/8cwV71gBaA2cHbCponvdhtG3I/MaAmcAyCcA9Q1/3BMpemBwAySGIXMbNDR0HkJtu43horIHxenYTFLd7gHXv3QDx2XC0Mcm/1WT+l42zxQ/fH/fv//OhAe+f/nN04+aA2aef7v/0/Gt9MP/TnzbGfQeg+ewzhaFau6oAzhZsKmjGkHkOAJeX6vMzRwOGgHT0J/5oTWCZBOAeTqVC5WsAxwDlPjDZD5L7QuSm8zgOHvvBsR8aI2A03x3xHADw2R0h8Zebk/+eSf5Pu5sHXf9ox73GTw8NWGvx00/HPSaeHRqwVz8eGvAgOu5ZZp98IgD4PwDww3bvuqF99iw+ZQOotoD0L2D+p6zv6mmT89A3X32u3tXcgMxz4DmeV8Dc0cE8sHuZwDLpblB5a6Dsh8k+kFz2BLncbD8KIndyIF8MN32I6pDbONZlXH3/PTdIsQcaix/STlDsAsP1jz/yxkx/xMS/nvAPTOh7upc//3zL/8dP9neNursXL46Ezn308aEBB/Tz6Pfxap4+jU/QT9s964b2448FAD8OrPoRqQIp2PNDgOc/wACcfwHf/yng0uTP1DuaDchcfyHgHxUwYwczci/ArYA5cgY4ShNY/uA6GiobYa+HA8oumFz2vy+3e26DySZIbofITQdyyHkcA5Cr75t4zr3Q+IE9Kf4E7HQXx8JiJxyOBsF68v8fO5qXeyf9/RP2yu4Cio8AAN0vL/ff5+nenjto80Fe7Bl1U8eP3KXGn+i/Gy2bZ41XAFV0NU+fCj8B/x9+QvPxxwqDVIHzA9A+c+E/wOzTcgtkVgKAk+trAVgD5i7hMT5cWGwCyx9Yd4XK1wAOuZT7AuWy/325Oe4hQXIMRN4WIIsffmC4i0qNLXjcAMcWNI4BxhoUn6zBsGUUbsJhBxQ+BlY7IfLRjZYBArdM+N2rW8JpT2425devCTy+2THWge7blF9z/+t5S72qv9PFxe5Pzy+bp+nC1+NeAi8BpEePBbwAXgDp8RMB/92AzovyVMBPaMrHSp/4Dcj8619AM0AmC/8bmP8/K/Uhsj48BvSAOcK9PFBIbALLH1gkeDxUfj2gvD1MjgHJMU5klPPYgshtAAl4ALsAcggcy59/ZsBiRIrR4RoYI1DUw0OQ6H55yR4Mm3yIs9WrXzbvvwWD7vUecIwm/4DFo53Dxs356mr0WHvG7+javN+2LvZ33UGv6215c9tzAens/JZPz+v10SvAzsdjXyH5+jxdSPgFeH3hwss1cJL3sHHth8x/8MOnn6rJWfgOaP6StXYvW+Gxbbh8A+BvN2eAI75qHtQElj+oHgoq7x4ox8Dk2NzI7Y5knxP5C4CrURjrVogcAMgaHMAueOwDxyY0Pto47F6+5E0jsQWLQ5CocAgwADsn+0f9xL7uG6by2rSe+PdM8hfbcNgPg2JvbpnYzzfO8vWesWc7WwGc482+rqqy7zGr0unZzk/QFa7WJ/VJbBh7BVzFfV/jNZICMHYu4RWQzl14BVxV2NiFK7kLL4BUXC+fuFJ5quZjCT/+iJQ/UfvMNStrB7PfveyCyzfvxLVMYPkD6i4hsOOh8g6AcowzqTB5KJD0Bbe7QLKGCDAGyT6IPBqFrHot0/4Q1WaeYp2HeLpBjfXJyrYcBgDgCbrXr9btG26CHOOis36C34RIvrpiNN2c9DP3g2MTBJsTf68594/ZmMi3gJAXB6rWzgC/vuZwskM3QDIMO91o9sXi9ufao2sAdnKiOMKNJ7RTqW9bnJwKb64qcK5gittrP1Oqk7K5lM5dv7wCkktWXOlRgOalrwGTvDqYzjX7tOj7LffyW8BlAssfUMe6lX1QOcalvDugrMNcDwmTuziSzTLagMmjNE6QfzLcbDuQ1csX3ExhfDT8Xtk4mf10h9uIg+71K27nHh7j8SZQHgHdlrsAgGybYMh9uOd83QYAJ9dvGG07nMEwIa/7Bijs6MuL660+wK935z+K9ZP65mQPAKWf8E9v9gGAL0dAONk9ZlvOBYGTQ8MOarGvZQHY/GT9aVtcY1nPbQQQAFhIshOX6Ux4c4XrU8kqaMylK3elC8k84LIBmCKlT1ytj9zLMusouHyDmyGxCSyT7qK3hQowBsvvBSg1X7Jnvcj9YLIfJM8ALHaAZNONVJBsuZDzG0nwUchqFK7aCFVViJz2yegNVjxGd/V6PXYIV22C42IEjiFsVMGxEUY6CyBsguImJM7OgH7yL9ejCX3cPv7mf9qfryf8TRCM7jdux8kw7/tyubP9Zt/N/mHcamvcfD3oRt9BzQEACyxvHWWaqwfNajYXFgvYfPN2OT+RSephs/A4NneZpGuX2v9x6qYKGO0CTFFTilLOartnmq2Kvt8Dl+fPnwM/Xgpf4Z24lubQgEkfjkgS93ufDDoWKpf978t1/72B8gXwP3dufXIbUGri/a8YgDKGyRUA/HlNk02YfLqGyU89SnqY/FyniE/CjXwCRHnqxwA+HoHkBT7CRzjHRyMn8hKrVIHxCtWA/ALgCbpkhMWox3iMxl5tQKS7Mna1P8ZdVIBcAUZc9LmLNxdo+GiARfPIkK/JxRIYQjQXFwGOBXCGa6Tzi7WrWC6As1Mg1fU0SwBnCwCnKIsFmxQvYrUEClcxJvUvDDi1E5RFTNDJLCBxAmAFJDvbAEAyQ+l3fOgQg3ACNuO1PB2QT4A5drTPgTngqxXZJGzK4OUmKJgMvqqvezYHcjf0qeSt8fP14Qw7lAEAxPZzV63qbdsJSFgBYOmENoElC20DlKzu/Fy2XIAuUdJyPldjqKAxLfxK8/ncbbHgtaSZu9py5ldOuZtKcT05f+QNhBdwRIzbAURZ+/f/Rrz5v/0WJ19+qVf/+AcvcannXwH4+98ZIbE93yLvqcmx/IH0tm5lAyqjG+B2qPyaQNl2J+ucSZ2UbnEmwNqdbMKk1xgmAPDxRmjro3qwM6S1y408DjPSbTmR7mrtVrZDVwNA+rDVBZDfvGHvKvLIaZRrso8+ZVtwIxZ1drrlNE43HEYhuRFMOgXKYh2+CmBsWgJfLoe20gPkBJitNsNeZUluuI0VOZ7DfYWN82HMjcl9Du/h1o/rVgTmAwjifKwZ1HVbjxUnvlrteI7NBrHb8X5cMwQA2LZaN6x7MmYCVqDaeit17SxcymoJCupmM6V25qzuZalr2bXUzOYeLuZKzXzu16+l9uTUzaXFWXH7rysV1/zisb8oHqGx7Go71w+roo2w2PUXevQldoTEvnkw1zI5lj+IjnIrB0JgG9oLlcsDLuUOQLmxEe1DA+XTDaA8wzM8wjPgGbAYJd43nMknwOplnfg/eoGPPgJWv8T56ulLBEhsBJJfwo28xgCSxupE+xroHgGd1cerX/xz7b8AkEmOQ1iLBMAeDedI5wAvMK9ASeeMRPcyjMSS1xUo5wGOs9MIOC2XSOdna5gsl4CtgYblgqsROPyXJU9G0EhmgMUL7kNIKZ2h5P7Y4CSRgc6AdrUiMAPmQDqrk3gPgLQi8hoG3Dr3bkWmGVAwausIZHA2ciAAaCcx+Zc4NzN4NwLbrABuQ388Xo4xTYov+i1GMiiPYCLb6PccLqdBmC42jeRlVBiTAHSwppW6ArYmrQqsTaIkFpNWKxgada1kZs7cGSGtBDWenElaJWNj12r8wherK87T3BerBdO8+MmbM6SWun4CX/78iz29eOzhXAzAD/gUHX760ycKg/UF8GVc2O3R5aUQn936ao/54B+nCSx/GN35S8eG9oXAbjqVtfZB5WAO5VcCyuKnn9iHujaA8jOwBsqLmkJZu5MBJr8Aq6cAniJg8grAk1+AJ0+GBPtjAKePqysZQLJOqufrK8KqG7mKqquGcb6wN4zJgQGRi/gnzWv1Uzpn9C2umS8MQHUhjCT4KU6ReqDgNECyXHCF08g/LJcoq3APJwAwchwwI1Yr9OdMxq4zYA6UGs5r64RrVif3+QoJHNxFAlCqY+hOTtB2FRhADbVloMzA0TFmgIoxQl0zODsGwAJiKvGcNIN3mSgR3lLXBbjaAsKQcseeAGrycAwHPNWxALpSXUgChvGrzDU8CpAMqgBBgz7KBKC+jswBLsXrQsiEPlIGNnNJGUyN4B2YWiFJkISugE0SJLFAZHYC6iRZ0zq7leV25k3qyOuk1WzFGS98uXjD2XzuzRJYzg14BD99Cbv+eBsuDdpnz/SnUvg9AOCfwLerUUgMev7VVxES+9tXwjffcMO1HPoyukcTWP4AevAQ2A5d9r/j4O5Q2Rn2evdAAXATKOkFe3fSA+Wjj17gvAJlBVSYvCJePYlcyZMa4noNPH78CqePo0qr68NbvRu4ArIZgStc4AL5DYnzKwAXyOj7Ymi4lXOcA0gkQSAvjLk6m7IkgQVAYrYkgSWSEYVkwhlWfRL8LIBysgLs9DRCVqugSTqNx+lOAE9GdCtgfoKmzwV1hHNFswCc5yWTEb5aMc8CEqVbcW4n8LyqoJnDSxwnOwk4lIxsJ2hQnUtn7N3CxnFuwfrc3hUS4RB6Z4CWdZJvwQR4CUjMLMXzOAC0kCeijYlV2YimRHvOBBLQFgANmpzZuxDPHs+RDJ1nblDEDGIefY5GtkXr3EyjRkPWJnVhY9wVYHQBCVARHIIaMUkU4gcrMTXerSpUytJyOnUzkW9Wllt5k1t2ZcX24twbd6wAzNM1lm9OgSebcCkXjx1Iw3svY6Rvv8UJIFxe4pBrIcm7hsMmsEyqOtIG73Arl6i/4+DOUNnnUnaXDY+S8nhYoGyXB28DBcAWUJ6ge/2aeP14w5l0rwE8ehUf6CuEOXkE5CuGF7mIxHsGAyQGDK7kjDivx+mMAIjF4jq+tRuGZPfMFkx9FRUXLMNx9LfLBdcQWSLxFB2X4UJOT+GrJeddJMWVlkQ3X4fCutUQjgNWaNAfE2AftjslLMJUyQwrZgKGZgVi1sHACC/N8sZx1xnbWYaleYSzWoCpI0pbJ/cFgThmfQ3uHWkVCt67hBL/H5o5lDPVIgAS/xegZAGZxuPf5QDaAinGaJVZ+yJp7wD65wDQtLO1SwGABlBJXE/OARzlTDTraVRyNHWSzkgxwyYTcoaaRugy0EjwRoCHawHCsSRzrFxMjdOzl+bEuVwZ6Z5TcsvOzjNT2zJ1K+Z2hhmikGI+X8OlewlDgj8x8iUSihnxA/Bp9x/81G94CQBffokN1wLENLDtWg5+K72pCSwfuB7UrewwLJc3m+6gL3ZevwT4PFzKZ5utV983xF//vVXl9YBAeQFsAwX4CKvRViirV0bgyeBQHuMxOnvNDo9iF49HNflegZKvyIswJMi8YsbFyLW8iQn8Gjg/exOu5BrIZ2Pg1ET6WSTP09B2RqBPop+hre7ETk7gyyX99DQS6CTcyDlWMISbQbeC8QQdVwGUk5MADeYoqPmKLsJZ3q2Yay7Eu46zGeFdR7MZPK9oDGhY7c82g0rHFi3sBEN+w+aAMsg50GWybTNoRhRAZgQKUNoKN0LLTDQx0bOtIDFCHm6lNUDIlBfIC+Ft7WsqBOL+cEAp2gMmgAqJZJCqQzGDVAh4DXuBcIek6G8SIEAqTP2UmeI5cjJAo9gY1tNwSo0yAOUOTEmp61CSBDWCXAAkSRDElByrTmwapxdnk5yluJ3Qi4zmYiGZ6Ey5Y2lapG6FlTtn7Syq9ObXwJtTnBt88ZFYMvkEhtc/k2h+Qvvsz8qlrD9vY9cCjCrEtnRo/tihCSyT8PWxbmWkzfUql/dwKxH+wj+3t1/5fEfo6ziXcltSHsBBoADAub3gJlBernMoQAXKaz5+/bg6lNgba1jFflVzJzYCyhUDNBcXQwVXvibPz4D5WawjyexhA8CuAybXQLEIPRWu3Uhh5ExOAeTT+q2eJE5OBpi03SrmbZIGoBtVXjnBOVZIPUhWc4DGDh28hqUaWxF5Vif6yHeAK+ZuFs8FoundywkYsJlD7EgQXVfYFsCshdARZQZZdSaW2ZUGjdXcRzaiBZQLCQKtQWaUr2FCa+E5s20MqpMjm1mEyObhLjhro09NdSkFIgkZhBVhDdQVYniMBkJ1JakdHleKL2OSEU00AClAkxwqYMSVDKnOoH0twFjKjpSgYgblDKZUHYpLg1OpUJELyRxenKnx7O6W5Nnl5u4lNcUk2goszRwpX6M0LVoA2UwFwGwJrMo1MC/o3pSIfa3My8ULNh8/U/e9c5drAbAZDvvb24fDJrB8wDrWreCt3MrlzY5Bt4XAdl+Wd1f4ay9UdrmU26q8eqCgLmbcAkrccxMo2+XCp6+Np9Wl4HXEuPpkfGyF0udOrpjPAVxdRIjr/Bx4E3mTc7wZgIKzNwGUBVBqBVcAhSwYweTlgjipMOEpAWC1XBIna2dyQsKMxPwEZbVkJNTn8NWK85MZSq3EshnQdSRmAZLZrIPV0l2bh8uI/E4HJzkD4F2mzazeEgCRQSqDbYu10wDpmbTemaCANaxkFQTWthAzu2xsmxIhrwKogkbLJdk0QMl0kIBBLKQREgkDBBBeAFm4C+9vSTQlCgBS71waqBgFD1B1IhpDKh7OpRRCDhihQioVQglx26Ag3BGsOhcrRL92xQF4odXTDIBK8akzACpISComSK6kpAKISUKGaAqoWHJKTmmAC33llNwsFXmheSp+Mof5EgWnA1yKUS0MHa5xctJq6cZziddGWjI+MeNtrgXX17gE9Hz8Ib8RDrubJrD8wfX2bgW3uJV9+mLPzsOfA599t9ES4a+NpqOhAmBUOlwXn2zlUc63VsavrA979UD5BXgSQAEAjFzKeNuUbFe8eFTLgnlFnPdAeQOcB0TOz84xxzky3xDj/MrZKWbXC+LsDGXRAyVcSVkueHpyGol89jCpZb8kxzBZrWroq1uFazmZB5Q4Z1fbnB2Rgdl8Du9WtPkMuYdMreZq2DFA0xEdmGeAW0fkGRrriNzCmWkgRLJkwDljYiZhMAO9ZBpbZGaiEKk6iIBIgWg0ArmAyWvYKhvREjBScsIMBKhSyNTAcg+JQjQpbtsGKiBnNcRlmepINAKUADOq65iaFNBAiXyVSjgYxblcDFdS2LsXwQg4LCWgMNyKB+hKUjgXAPF48Q4KvggFABOEYhAyJBNBwSRAkbw3CDJHkiO7YPJcQUIvnmWeTCW7M3kqJRlSyfA0h62WKI0FVMzULd5g3p5ptXTT7EyFTjenJ7H8Yly7lu+JerGxTV3Gl8e94bC7MWYCyweq37tb2aVDl/DdyKls6NPh6DaoHOVS0Ie9fqmplCdYjfbmisWM1aVchWM5sViwmN9csd9zq3cpAZSxQzmPdSZn1yOgLFCM1bX0QCFPT4hMMrOGupbLgMlyiWKkGbGqwEAdM5/P4asly2rFMgt4YD5H05H9gkLvyGxd5D/YYYZZ5E04g+eOkbjv0KDmTjLYO5JSHURilPM6M5VBa1qUTIpgQ8A4o3ImmwhhlbZFyplsmghP5Uy0DZAzsxmbCh1frSIZ3ifFCwgjtSpk00IK5+LulBthHqErbyDLVKlhtQKCHRMayER1IpIAZxRgySA6kRjPkQC5KBMhh4yUO5FSTKpm7PMsSAnMTgJASrHW3dcugJaUACCXGiKjkplKKbWuwNwBweRJkrsclhySw+To3JhUzFKhRHMvkYYqKCkFXE4M7lBDU+lWmp2eqnvzxtTOdEJyaeS5rnhtmZY6PrFzvv75Z6ZPP9Wn//43N8Jh+DI+ygfCYXfRBJY/sH53bgXfbbTscisAthL11Ums2RIaoFL1CXA7VOJsvLjx9LVxhVfVpcQ8MnYpj4bji50uZX79hvMzIF+TwBsEVK65Cyjrle2nmJHEySkyY3W7L5csJE8A2FaIzPsqsG7FRKBbrQgQPj8hADQ8YQ8dZxd9M7DpOtp8FmGvWV0gOOvQdKS1bQCmPrbYsUWsKfGaDymZdBS2IJwgLMOMFMCcM9G2SC2pUmgzwnNhmQVcQNKshUqmLEq/MsBE0KyBQPauhYbhvFPHxlI4lAbhbEoUV0tOSISLYEKyQhWjkgNOwkCVCgoUqoCwBOUeHoWRQ2mg4hRBWGT6FfeHHESyCpr6/6aES6Ot11yqOAAHzaSgllQyAEhmouSCRFWYgHKyEHCquM+ssCOJwuKppGQoXuCWkEqBW5LTlUh57tSkRqVbSTzVnM7VcmGaZRWSePQIKAXIGfjkE5T/+3/Z/vnPyt8VNs8+C4jUBZOX2+GwLd0lz2KHBkx6/0TySLeCD8CtYHcIbFB1K6PrmZy/vB0qT7Ad+hpDxdi7lO6Ka6gMLiVWnsx7d3JN4iwS83lxzRnJgMppgOQ0IFEWjD6SmQtmgr4knWRL8uTkJCCEGO+rFVuS7QpsCZYVWbAe35C03JnPwZw7c87ZALSO1pB0zplzNidoubMYT/MZmEu2QrMGpJFGM8sGK6QV0ozFyGgtRnPS8qIkI40sZkYz0kqhkTS4JTMaS0nZPRXSwJLgTEYYa7FTcU+gJXhJMEtwJtQ+GhPJpM4bmCW5GnXegE2SeSOPY7ZMSd5A1sC8gdiIbGRqQMaP2MCsEdTC2EDeStaC1pjUmnlrUmust+atga2ZWoitpJmkVkUzGFuYWkCtOWbmZQZTC2OrolmStSp5BrPWjC2kVsY2Sa3kLaQW7o3UtZA3dGvgatgy0SyZMRUymVkyL8mNVjynVGhutERayZ2VjtamleXV0mQLnjDem+dXRn9tLGYsL14QeIbuxx/5178CufmOy9k/uRh/Tsef99HlyO+qybF8kDpElQ/MrWzrFrfyMYDleNv6jV2G++vJPgF2OhXjI6Am60f5lFHoa379hvmsupPrNwGVei2RWXUA4VIWEfZanOJ0tA9XJgicwHuYcMliJFbL9RoVMpLyBGMjyAhxNZk0zKOMGLV6i0QD1NJh0ufxGM0c9A5ES3ie0RmJ8yaTyB3RRn5EGUTTIjHTc91ZpQ95oYVIOjLNyELCM5kIygvNYtmJk+zDYNY2VCn01MDqOABk2wClYYn7EaUQJOGpuoNCFLIY2LAAqC5EThqHvIy0zs8ADcG4H0DKnCg1CU8QpVAkk1mE57xQIoEGoBNQ5FmImoMRDYIoAoZiXr/AhQsCBYCwIrhBUWRginJmiZBo5pAEo5P0QjgFp+huRpMKBXrnNBNhgLmjuCAzpVISzeSkpUx5MSm1Pps7i5NifLnwhdFnpIssRrZ4ik/geJF+ZMoHJoh9eZY7aHIsH5jIt3Mra+22xJc7W8f68tCAG/o13cpyOwRW1Vd+PQE2cioARuEvbGxZf9OpYNhmfgyVs7MtqKAPZZ1ixgXLgszL3qUsw3XU8FdZMaq8SJ7M52irW/HqUjCbo+3CoWBWcyiMsFcD0K46c5L5TTYn2RDhTEA6Z8yltgO06mB8RpaSrUHLBJIlm7OlGK7GmC2RLKSVkgdnwpLNqoMpJVwNSbMCi2/aJXFwMSUV8+Rshpt5SiAAACAASURBVHO4J1Tn4k1rZGOgJ7KMXIsnZTVQuBmQSVI4FnlDY2LDBMW53BoYG3i4F6SUVPuSWZPIRkUtilrQGpCNFA5EUhvn3sLUCmxVXQuo1sRwIeatoFawuLXok9RCao1saKkBm8akFmJTpBaltMhqSTVkfc3uDRn/VmdjznAuyWjmnpzx/zcxmzOb5mBi/I17qMyr0xXfsL+8cnn1C/Pw3t+OGx+rQxPLWpNj+eB0+I//9S19Gxfx2htuvdzXEdoXBtuzbuVXdSvjsVtuJVIr1a1g5FYAAI/wCOucyoZq+GuAyRgq6HMsqBexOkVh7OMVixtPkZfrXMpJvxblJEqGC8OttCTLahX5jPkMBWTLFcE5SoUJOtTy4BkctW0WbQ0RuZaO9P64AmVwLbNM5cyE6p5KpioIU84USQFwBGRSzuFGaqWWABpJ5Ewj4zt/IY2RVwHAUpxoCAvPQBVnQeQ0jGRs2tUQXuiMWVQCYU4UECA9JRiri3GQqu4FoFws7iRQn1MUUEvnEGtRjDSQchCIxxZEFFBg/N+Jf3Yk8BmuBQQhJ2iI0mUD5DQkgIbiTsAAk0SBSEJxQCZVt+JirLIXHbFPZ3GBlJNmxQ2QO8wEEnIXZJRIc0KN0VSKucxk9JSzyZIHVBB/r/YUyAUn12R3Djw+Aa4LohYanwA7V90ABz/Xd9AElg9Nh7mCfZVga90kyo/Pn/Ny3FBP7hQGO3Ldyljv1K0MuZX1OpV9buVRLS/uL2c+divn/XWwhotivam319F2XfsWsTX96entUBmHvk4wTtSDZbUaXApmc5SOFSAzNF1HB+hYRbK+I2czwDvUxP0MTtCZ2VyD1ka4zBdRodUADCeDumCRTABjy5QWDlCFTMh0gt4GUFIJCKCCBm2DVEgvARQHWYu5CBaCKXhQKohiFqccFJxGREiKzkIM4+o1VygvdIUdAkcwKCDpFEn27cBwPIAEEeYCwQiBsccGQY/7lQBVXGvGqVLHGNFHtQDF2hevK/RZ314iCMkh0CpIDELJAs2Z4BDoCKCAVtyd5rHFDAyx0EU5WdRDmAizJrl3namYScUalQEq6uJvc5JOkFkCMAUALlCunDi5QCy6KcCnwOrfifgk35gtvgLw9+Hs7uHyXlMo7AMS43vVrfr62ITcvdzK4TDYplsBboPKhnZeLnhLu9wKgN6tbGjrCo5PRr+Bm24F2O9WxldhXLuV60230l/LpL/IyQn2OhUAe6BCzmcRDitcsZB0rtiQbDrSAfa5lYYVKkQNjZGewcTepcyGvoZggzqmTraWiyXEsbctS8lmpVhqsR5Tw12l0ARQbcPUNGQpVljMSWOh0SOp7yympqENbTRHiUmznpOI+5FGpCGc5oTRPVGeWENghUzFmSBPdE80H8Jjzkj292MhRPJfaiIUVZP48gZU/JhqW03yGxuU0g7nZCOP8FjfpqIWQoPYLCaO5Y2kloqCAa/jlZggNa4Iy5EpXqOYmJKJTHJPBsa/FTA5zd1NBeZeTABTCzaosAQCKuyqOx1f3OwcXt+XPrpsdanXHPoMW7rcbri/JrB8SHpLt3LzWvb30GG2jHQDM/vDYBvajBHfy61UHedWsDe3Mly0d3Aro9v+ulr1tixGIbBKmP6Kiv2FsYbwF3ZBZV1ejLpGZTaL7d8dfcK+Y0MyXAoYoa+ObdsikRQ6eg6AJGY2uXcpmZ7BCPaDyhUqwDA7O8FSiiW2TAgoCYgwltNYihUfA8VN/bTNhgkN6VFZ5ihmLAEUD3CsgRLHTjc6zBhVZk6Yo+ZoRjDxChn0MBEjVyMk1GPWHAaJYVzcpgSmuEVK8Wq9gRQ/QyWZN0A919YtNRofbYrHbyA1hOJ5FbkUiolUonuSmMQBmAFReRIDKiItIdGa+LskkiiRT0HbApjVKwDM4rIEALRccr4g3a43Ps/ll5d82n8m/gwc/lb3zYH+/ZrA8oGI/YRzi45zK7vDYBsNlzeGbGjvvmD3UFxKeK3BrYzCYDfuBIzcCm66lUG/tVupp71LsfXztvXiVb6qLrRuCAkgwl/dipjFwsa1UwmorMeTbQu0bQvPARVghoBMpmroC22DxICKAxQjpGV1IlPOFUQxuZVSrJT67Zlgavr7Rb+RARMkukfmgCxW6AEUD6B4BUo/oW4CJcaodysjoLjHxBv3CZdjpEWcCQZ6iqS/Uqw9j3NQCVRiPReZHEwkqpNRM0CGGLmdHiSVu2OoQA2gxsEGtNSfV0eTRCYAyaWGFSIAkwvJqcSoeYt/ZwWKATTUfxxAuRtKDdsxvBGaBsqgckd1HeOLxRzxs3llz536D7Cd28Tzm8M2dcT0UTWB5UPRceuWjtPetSubOj6/sluv/v3dEfcfxcBu03YYbNAOrNwpt4IHcStAbBs5div9BDBcxheo11gB+j2+MAfKimy7Vc2prNh/Q226jugdCzvGJuo1/NWRsQ096Jn1wlUzJEaORRkEWrRtTcznNVQatGjqCvlIqlfAjFxKImkegPHSQ6fZcDGpfst2NhQaJqQoRU4BHktBCy/F3N3o+4ESbiUm4R4oXifkHi6QJ7gnkbUdRjFBTO5MohmZDF5djTxBSqWURiMYQT1Dw2X0TgNErTZTAzLB1RBMAhMVx8M5lVjUEEiUUnC6Oqj67zLCXEpy1utxJtLdRJq8GLD+fylGTgqpgcYzfP27zrCljetKh9LjJ3rx9OkwUXx3Y8TzUX7l7TSB5Q+ieDe9bRjs8tCAvdqVuD+kfsPJTbY8XBhsl2IfsF4P51Ziqxasv0yeoOZW4nRwKydrtwLUjSPrrFHq9dy9W62T8ata/dWvjGeddFogZQRQWkA1JBYXzGqABujDXxHyil1+G9QkfXUqtq4Goxcy5czEQjGSz6lwBJ3C3sVYcSurYsXdrIRLcXdzp9ER4S+nOWDWNLSUqCYRqaFSoqXETaAEYLQDKCKseISSbACKJxfTGEZwJVVXQKMF4pBoZpEtZ3JHwIVM6ENYA0SinUK4HCBJCJdSnZAUIAGRlGCQkshEBfCIaIPc5DQzkPTYSIxuAAkHkVLUALjHdjMo7Pe9PKwFcH290WIXjwagpPyJqmXZrbdcwwJMYPkgRI6+wezRN/cMgx2vOyVXQp/taDuYX1lrbxjsKO0Og23Yky31bmVDG25l3IYbbqU/yssFNwhzQ/ONm7brwxyA18WPM6zzKgDCvdSrGjoiUR+Oheyh0qIF2gZCXeyYw6HEszRIrK6lRNmx9d+UM+ilMKHu39UkAA0aNBGSqVBJFSoCuXYx9Rv3OLRTQWR92KyOAUh6MbpHwno8xt3kbvEYjG/26kFFs9gn2NzH0PEBRpInVqcAKrk81ZWL4Sh6eEnJ48LBSUhRQCBPNBiIRDE5lVxch9ZgJpi5+lCbmaQEKZ5TMIFmcpNkABjP5Yb47HINlFoV5iAs0j63qgOAFVarviEK6pcnJ7ITl52eVUi8BPDf4W6zTz89DI+t3Y2P3c4FmMDyYejoP/dvq5vrVzY1XG74kA6t77otv/IUN7QaVcz02lwQuQmTPgzWu5W1zitL6tUcF4sNt7LtWk5Oahisdy2MSjDMEWEw1BOg5wcAxJUXt49ncdxfWKtFQKV3LOsNI+s1UMbtNQTmOQdUQDZtg2E1QgM0TYVIQZQOAxQLhTxARYw+FbBpmpgUU0IPFW1BpT8WwT4MJtTwWx3jqkBBhOTc3eQw0WiBQhPdVL/5k+GIYq9gGuEG5URUtyNPdBiZjFISAkQBAk+kjdyMB4CYImRVxxNmfXhLURdcw10WjwUPmDhMYrw2wWRGMyMlq+GsKLF2MpJRgHldF3PLzMymUX/LphXbVjabydqY+Dmfx4zwJsancx/NED/hVj1QLGwCyx9Ah8JgGzpkWi4P9D+g9ibut7UdDRu0P20/zq8AwHZ+pb8ZADPW+fALwGYYLM4rQEYuZfP2pFaD3eZagiTzrTAYAMxmm0n9piO964aQmeeu5lRqCCx3cc2UUQgsZVCZXLOjRbiR6npyruCIEJgyqBIwcWz2pVL7SoVGD4x6nFJCD5UeGANgKlSATVfj7uZyM/QQA91piOtsknBzxv3obhRNSJRHuxlJwiQYkAj52sGQpnof9qEzhqsQaCpR6kuM+qujCRciE2AawmwRjpMrwnykycjY9R8jkJAQIj0PAGYweL0q6K6puACxjyWIFAtnSgZyBoG4zDFWwKoDsMJyBZgkLBagS3Z6piTpl1dA8sdq/Kmajz8W8MPwDPPPP9fJF1/o0ZdfVvhUsnyz9VKO+8o3aALLey7e+U9+U7flV25UhN2me0TDHkq7E/ebuk9+ZdBWBGytPWGwLZV66eC8XNx4DWUVyfvxupVI2u93LTfVDu6lRWxVH1VgtS+P3AqaPmqGcY6lD4E1bbiTXk1vXhpgCIH1P00CUoMATaHVW6GwbxMjP5BqrkD00VgnLKGvguqBpBrywggqBpAEBbceUnSYmOp93CyBhkQJJoB0GegBArG21ckfEU6TeoigwkcxNh7DYjN9VqcUsFqHuOL1Ml6bgWCEu2yAJwACIr1uC+ZOBGBH8vjPTB5bDCjWMxbQEK8GABKEJLGpP4CoVpTEmcTZXDY/EQC8eROredOFBLzAT/gZ+BFonz3TvwA0+TPhWwD/iFfw7PJy5GzejiwTWD5wCW+fX7kc/f6wdUt+ZVcCfwMiuwET27fc1Ak2w2CY31Ii2juRbjVUfvXlxON+AAMwhnxL7hhH1a3kzNQDZh3pGvrjPpn9Fi1rt1Ji88jBrdQQWClUqQUBsR1LvU1IaCCvbsZrVVPtM68OxxGbP3o8vryulBxBJVyLD3kYq1DpXZCqa4m2RMmNFSpK1XCQMfkDhlRzNjQSNKJehWsIXVm8AMrI6kIEo4WbCiaQgqy//5ot1aXACQcNzphmie3p1uEATHBAZnJDbAETH1tRUNQIxGWMLa4yWWGCeqvhxwStJFn94alkLuEXIPkTpadPBfwYf+2cBfwT6MnyvHqVB0jcAxNY3mux/3Z7UH87Lgz2gWijImy0Rf5DaKPMeEtjzvT5lUFb1WDr6FctOV6tS477/Mq8v1AXgH2uZfN0hpS7zedtAxTDSR8iy3lI8I8Hh1tZtwxuBaOE/dq+bLBkl1upHNlyK2CffwGqM0kJQ86lXjRLjtgrrAKmn7hj6xcQjNnc6rEwwIMAGVCJUBQDRIELdyONAQRQNMphA9E89iaOK0iCqiGtcDwVHn3inevXAfj66QViFOKK6Jcj/sEmVEficDjiqpJU7CdGKMBh5kQRBTmkkju5kpdOypCy4odbP0tJ5i7zM6Vzl124gP8CP/2E9Mknwn92VYQ938yvvEXiHpjA8n7rbn/r30j3XBn5TjXO4I8TLVvab2B2lhnHeQ/7XT4FuD2vUjXfosdIEe663bX4UOk1G7gRIMnc4AiA1K9fKX2oDAA2Q2F907jc1UvZzK0UcNutAHFRrm23koC4mNboqosqcYngVJP9AIaQWezxZSAKQY8cRWwXQFQnI5B0UIqSXZeb1c0oh3BU71qICFpVYNHdaKRqoQBoFOq5YJEjqa9JURoMM9BRw1oGsN6GpQHQT64BE6/5c9aUJ3tXAsSSHfXnsd8kUOQocpk7UsTQUnICstQ4V5A1jVvTemnlqW2j5ExQ5Fe0kV952edXfvgBP9SKsP35lW+wIeLOmsDyAevO2DmUuH8fdQ+jsjNhf29tlxlvauxU1jmVreO6KPLWFMugbXRsNt10KVXjpH0ptdx4MwxmZR0G2wbNuCh2HdYKcGz09e0J6HMrYjgY+Ro2cmdCAixBdAJOONlvVMne+cAAxIIQBDAgIK6xUmGCaiPYAwYBO1anITKS6nW8oGE8IUI19jVArb4es7rBcUCFcqJ4/N0Iudd/NGvtAiDIhKLYmJLmlDngIuLYDe6lSIpzxsYuHmGwLCa5Jbk1cq5Wg0vpBKV25n0Y7FqSnUvJJbx4AeBn4Mcf0T57JvzrXxEK+/bbIb/yfCO/sq27fxwmsLynIo/7a3/zzTe8LQx23MLI90WjOuMjtavUeFO7F0a+E83nuxpHx3VlPQI6PWi8u/leGCfub/QNzmRTWx5l3dj08a4dY9cmBX0YLKV120Yfo0IsIAJi7FjcmQDAIjyGZHGfftJ21IWCkbsAEuBeHQcpr6Bx0lSPI+wVQCGJOqbShuPdjgUQUcUwCmsBYUGswi2quAIujMsgD1Oooy8qExRGxUYuBBHOksFr4kXwIje6RHeV6JNFf1y1zE1wl7wPg7knL0pevPHSNF4kT03rQwhsCIO5rjzCYOmxK5WiPgzW/OlPI4hEfgXAOr/ylmEwYALL+6uj/9S3UGXQO7Yqv8do2PuivTZltnEDIPYkHGnjtBmft+Nc/egOO9ECoE+HjPMraTi2Gu5ak2RNG9sIg/VuJiZtG84jDBYJ9NrnXu8TjgQGDCGxvroKiJXpkRsnABCIx/LqKOrX7VhwWF1FH7oyQOIADBoiGSJQAsO0xBwP9E7FwH6bfACAR87EEUkTKNyJRWJdfciLAQ1IkuQuuCIEFiAxK5RcksusyKyoQsUkN0ulxuacXSdTrcduWl8tl0rF3XSthQdcks5j4Y27XrqrKR+rddfuMNjzdX7lAcJgwASWD1ZHc+cuujw04NfT2626f0faU2p8jA5tG7hO4vfn3S3n64qwOL8JDN/jWvb4lp1SibDZzr4eGCPZ9lj3IYlv7kOfekdigOhRlus1l2SolIupy6y6HwARuarlvNWtyKtbgQ+wiJJfVOfjZF+5VcNsm5OprWfJesuoERNMwZLercBEQhDkPVBEl7scUnUqTjOPrZ1VYRIQkVmhqTBXt2IqVoFjo59kTbFGntTGjpxt6ytJjc+9mRdfzk/dXDJ/pORPlMpTpU9c+E9Ug63DYBEHizBYJcuWW7kvWSawvIfiXf7axxiWt9ZvuIDlPVDZlVsZbTx5a6nx22hXLmVQs7u/2bjZ2RfJ991A2denETiA8Aw17LUli+ZR7gJIg3mxASIe4bLqWIS6LqR3HcNzrB+HfXirVmyJoqE6FIr9bKha0QttvuYeIg4HPEqFZZE3CWciOaBaG+0REHNR4UzUOxIVDzcCh6EHR2HOrozqWFTcrLjkslTK6LbIvbg8N/I8m3lqZ55mc1+4ZFeRtF+cnXty6aVLzceqSfty8/vm8+dx+9VXuuFWgHuFwYAJLB+0jlu/UnVrNOzyts4PS7dUgv262pVvuU27Y2YbzmQLJPtyLYdcyz6oAOFU9vUBwKjMeNDgVixhndsAAAtQoX9MG91YfzO09wDZhtim6xgd9+0cnWvH97Y+CV9DXoApjh2xBCagQsJZg12E14yNFSUWkoWAG61QVkgVE4vEAlMRWWRWwqWomKXSh8BSSiXV87VbiesHcLFQ5+6N+5ZbicR9Kq7krnHSfr5a6eT6Wo++/FLPAeDve/Zx4fHTx7YmsLxnOjZp/xC606r7SQ+u7fDXUWVhAzy2B++yJ+u2DZTcxpVdJmOP+qEDiNI6z3JzcPT1E9IwZjRDmXsk8Htw9LfytVvpx/bbpiicSJ9bWd83HM4aQrwJJJoARyzSdwAONwjuoCARQ1KehMshUk6YiywRKJMTcIV1Ke7FYQEUUcWIQqlIKJKKZEVuYUykIqmUVeeSiieVwa24e5Y8FXe7rrmVwa0UT/7fcCtFav1T/VCKNpP2CLfSV4N9gwdJ2veawPK+6Yg/9XrIu4uDve21WCY9vHx7ceQx2guRZscREKvsd+s2J7Nvk97xfTYn9h5Cfdt4qtp0LuP2fvzO+23PdmOnAvQLF8FaHgygfpgCLlS/u0tf7cW6hWQ4FVIuWK3ogpMsoBVJxRQOxRgQgSEgIhZ5uJTUWDbGsSxFKMysKKVSXO6eiieVpmlK8sivdO7ezObelN6t/CLzcCmpeM2tfI8m/0V73cpXX+nGFi5v4VaACSwftg5w5cMqNZ60T/tDXrck8W9zLaO+QwZmDY4KilLLiseyrWmorwwbDRxyKbWPNwAygpJtwaTP1dRqLvmOfbr620i+1/tKfVIecgwJeaOrbrMiD8CIclSoiFYEOT1KyowsohURBWwyqUKxJFoWVdC0uXcn/Y+5Shp+vKTkxVxu7p5dXs7bktqZN7O5r4p7c3LqSa+0ODvzdSWYaiVY0c2rRT5/Z24FmMDyXol3SdpPem+0azuXo8Jexw16MN2aW7mlbx99Nlbeb4TH6h0GaIwfII1udrQDMK0BAmD06zZFqh0OgNWVxLZdAhzOfj2K5F7Lhxmlwopl9Q7JBThRnLQC9qDABjQgFVA5nAyKKUefq8g4QCYWt0QILNyKF2/akuWeXN65vCmRW7l+9UptPnX7b+9Wyo1KsF/LrQATWCbhq3e+jGXSw2ijpHg2Or+NL9uplVsrxe6gQ1YFYzexP7eS9sXIxjOTx9bG+zT0yXnDrWweAIiQV7/VY4S/alLeYv1J0CXgQkICaoK+X48CBUYgqhYuC05GUl60AkVC3mjFqGJkNrEgWQatwiMXmQdgyGy9U6Hl5B5OxbwkT6UZQmDubTMrfcJ+NS/ellNvT878qibrw62UtVv5DpivRutW3rFbASawvDe6q1u5U0XYpEnvSkcAaKz1mpRe6wfYTtqv8ymHPhs1iDU+3zoka8WwA0SfrIcEE5m8blwWbsXgih3QXDAHo+pLKBEGK5GwN6EIKkJUfoHKlAqlAlbAeBxLKjDbdCtJxb0Jp+JNyQt58bYkd29cEQLzU7/WK83Oirdn2ecXj33+5Imn/IlmpajJWc1fsoCtdSvv0K0AE1g+XP3tQIJl0iQAD1YC9pDaOyvtS9ofKeMaL1azJsOPiaJgUTosC6ggaBP5FIOTsQVLX/lFRqJeiNwKS3EzFIBZUAGZIxQWPxAzendCZqhChZbdfbhV8uKeStHSy0KefeHeeEnlemcI7HVN2L/oy4s71/c7EvY31q28A7cC3OuvM+nX1l3dyqRJD63bqsHuJXferPzao7fkW4S7fMOoAIjF+fXaXT1gJEqxmGXIqTDqiR0uqVYOS7WsWFZEFsqKheuIfImpqK8AozIYQJFK6UEi1bCXBWgaS3mdsE8lJS9NaUrT+BAGG0JgZSsE9vNmwn62J2E/uBXg5ir7B3IrwASWD04P8nXjLfTfb799uHfnpN9Wx+/ucotuocJW1734cdsM5hs3APowF9ZGBfWKKLBhGxZIgijE5iwS6bHgEU6YG1locMmdkNPdQZVKnGKpdySW+9yJsooqXODKUh7gIqYaFvMis4yZZVnKXlLxxounpmSPNStN8VoF5ntCYK5ZKfp+R8L+2TgE9oCr7HdpAsvvXJNbmfR7160VYe9aWy5krEjEDyeDKwEtkvSGCH9Vx7J2LhH+ElzCelt7iV739nKQxcgCooCsrkXRFnt/RfWXIhxmVLZaHQazLDJLuYiWJY82S3kjr5K8lNSULHnbtKW0szJ7MitNKb4qp97mU3/93z4E9uMoBHYTKnj+fPMKke/QrQATWCZNmvRByQGOcikVPAJiBX3fODgW1cQ9hLqSnqiVYLRwKop1KpG0tyIUZxliYk6phGvhOhE/Dn3VRD3kOdFyrFGxHMn6rsBSdlcsqvcASlOa0riX1r00uZQ+r7IqJ97Oi7enxa/Pis/OH/lJ99j7KrDZniqwjRDYjh2MH9KtABNYPkjdqSJsKjWe9DvUwbzLhvrSrn4vr5GodeirNrCHSFwLTEA4F0ISIp/CmlMh6XGdlLAwpJy0mj8ZKrwKEvMYKlHdhQDM4Fwsg8p99Vei5YaWk69KkkpKkVtp3EvR0r1pSu73ARvyKu7LcubpZeRVGv9JL4qUcl6HwLaqwG6EwG4k7B8+gj6B5Xese4fBpoqwSX8g9Vux9HL4Rlu/NsU1IkzNptAQO3pZ71LoBCJhbxUmMhcYK+h7lwK49Vu2QDX81W/dUkqiZZOHU3HV0FddJElfr2XxWlpc3YqSijfNkFfpQ2DNVl7luuZVXpSilF1t1/0uQmC9JrBMmjTpd6dtWNyU7zja1wDATKQpLqKifr8vSIit7zH6cUh1/y84JBSxloNBLGYWeZXiHiXFFvmVwZVU5+IVNGSG1XBYXVkPq87FIiTm5sVLKu5e8mLhjXtpmzZCYPNwK7OtvEpTftT86VNvO9ds9ama/Jnmq891cv3bhcB6PUjdx6SH173dypGa9gmb9L6LZlGY5QBQAKRRW5+Er5+jWgHWf6riIpECYKA2SeR1Oxea5Ixci1hX2UOuUvcDM7pxvE1LBUpdvxIwUZajmOdCa///9t5lOY4jy9pd7h4RmQBBihJbp7raqu2vgc4ZqId6Ab1EPU+pnkcvoRfg8GhwuqxNf7esy/SzRYnELS+x1zqD7R4RecOFBEiQ9FWWyERkgCqJBD7uvfbanseO2YM0IJiSDNZY5MKUgiE1FkO0vjd2qwuGpvMW2My4nBs7M1rfc75+wt/t/2iefRWvVv4OYAXgEvjhm/fSAiuqYKnaq7oyv+rhKgrY8mD8rJThGuEMGf9SroAYFeh9LgRktDDAAZS/JiiAQMxDx/7zlyFGSpJCMCH4mHGQSXETKjmzIpmBwdCEXKmoF9eGmO+nTKABNKRgXDcmNMa1UcetdSGZBbPGjMGOuDSye2U6W1GzE+p3k+aff86Do8WAvv8eV7fA7qdYAVBbYQ9S912tVFV9ULLy4orZYg4f9rbRxjUt+XwVeUninopyViUQoLe9FBliXtcCUGaetBcYg1coBSoK/sDERxkqFuWdYMVfKX5KYvZXvP3FhsbGjA2tKUHI2ZwrIzsjp77K2SSvMrvSVxkqki2o3F8LrKiCpaqq6gOVbZr0Yw4FCEHKJz6G3PnK93r5MlQjkEJ0w15+jLBi9D1g0gAXhJysdzhQAQNUYog5EClLIfRpqF5irxBHfyXEHjH1iqlHnPVM9MOFvwAAIABJREFUm2Z9yiHIYbSYZDc/4gWpNPFVSl5l1v9JPw9QGX2VL6/yVXC/LbCiCpYHplqtVFXt10YlMlQxWyIAcnhwGpJUhgsJxknSHhBIKUbPq5T19yGYJJ8Mgz8rBj9XRcGPFw5elZQKpVQmPhW29jFiMj/76ybSEmWN+WhxymY9m9a6trOu68zNenLZm1crj4qvMuZVfvrpJ+Dfy7/cc+AHHy3+/gpf5b6mwLZVwfKR6W8VTFWflLylNcZUojaqmAwQAT5sLEkxDkHIACgwr22RGEhfNjnABRZQzHoZAixmqKCk64dFk/2QVRnaXpP2l48Uy4Ylk8nXtbBprTffWLw2sjWxnRkv+NpHi/vHbLjpq8xyXmX2vyYtMPyA63yV+26BFVWwVFVVfUDyUiXEaRhy13sJMfrOLw7vDSBxWz4/LPsrLBuMI4Mmocjc9hKMUdGCiSpQmQYh4xiQlOSfDyPGuQU2S74PjI3RGiNb6xek5UplTdLXtZCdHbPrj3lGD0EebfkqP+/xVX749lsBV7XA3g1UgDoV9qBU22BVVXsUo7h12FeZ+hoslQSRFgLCeC1GCT79hRghh0wIkykw5FZZiFGUsu8SGGNDypS9FcrPtzdBnEKl+ClG5DNXYo9IP2eF8mvRKxYgGVNviMHInl2TjIHGbNZ37cxWacXOTrU8nnPWn5A92dgLvRx8lX7LV8Gmr3JotHjbwL9nVbBUVVU9LBGTXornU4qGnApiHjH2Y4gzJRTywq8QMK6FcV8l5K8d6psCmPxXeYUIySA37o0I+Qx7GBGi0UT40sk+KlppeSGEPsXYg/0wSowYe0C9SENMhkSD0WhNBgytJ0kjuygGI1eJ7OzIfZXfTKePXmpuT3T69ClbUt3K9NNPwKP/6yvNv4YeA7qxr/LuihUAtRVWVVX1oeiKaePNW9y4D9G3GJepMErDHrAgEZIk5SmwSCkyNsGUD+4KMuYqxEeLs78S5X6L8tkrU5hs+CqRhujtLz+zXqaGZlw4UkoLzMh2ZkynpxrN+sdDCLJlboH9cd8esOvzKu+yBVZUwfJAVNtgVZ+63D25nh7DwV0o8JhsLYYkRDH49FdAFOnnrWwY9sVPCZExgyTCV+LH6PBADCYDpXxuvYKhib3iGIgMzWQHmGRoM1woE5Mp0mg0Gc0W5D6zvqzB7+bHTJTO8nLJdrJc8pCvAmDMq7xnX2WqCpaqqqoHrkleZTJmzOECASGfBJnvB8QQRUGY5FeAPFqcgRJoUszHC4doAZYPYhGlmEeKZTIRTdyESHku10n/vIv9OAHWjBNgDS0tyHavWU8uj42zHIJszPSyp9r1l3t8lTGv8v00r/KefZWpqsdSVVX1fpTtkxCjfGFweY0Nb2Tn67KfAmPYqPMD5N5KBAZngSFoHD9mTt4Hmq9tidGHhmPOr8TobbAAwn0Wk4mKE5CE2CeVqsUMkFkbe63MV7QgmWahb0ivekJjSI2RNpj1HR07q/kRO3vNi/6Vjvt/5ilfam4v3Ff52X2Vn/s/a7bCg/dVpqpgeQCqbbCqqi0RW2cVcwc0IUa5je8zYiICAhAiPIUSgeCQmRj2QaUCYknfx8CgkNfk+0p8hGBAoCRTFJHT9WXSS5PnED38iK7rtVqPcGEwoPGVLWuSjQaz3vMqxmjksj9id2w87V9qe7nkrO+Fslzy+SXwzTcP1leZqrbCqqqqPggx+yrTK27U+1OIURg2E/sz4S49IAWIAZAUPU0fxdIGQ/TKZFyJD4cKxMiyEj97KOWZtBC7TcM+JVNSbn/JD+zKbbBuy6xfzYzdUTbrcwiy3QpB3tpXCe/PV5mqgqWqquo96dBeFhuethdKulkvDUAxgDFK+VqAw4V+YWLWUxD8nJUohhh80aSQ4WKMpe1lRgVZzFBBE3vkTcYDRESvWCINseuLv1ImwGwpliBkI9/91ecdYINZb8e8eCU1kxDky2tCkNf6Ku9gD9hNVFthVVVVD1IbcZapDAghStF7yIKfyaKScRlbZsMP2YAoxijQEAQRVIyRVMjbjMe8SkSkYjT1PRExnA4pyYCy9p7DeDGiTEiGSGNeg9+AJi6YGp8CY0i+tXhm7E5JK2Z93/Oyf7IRgsR/AUdfZl/lEhshyIfsq0xVwfKeVf2Vqk9Sh4z54T0LQPIWF5IKPAxT2LjvEhihSABCiLs/WBklEQgwBe+HKUJSEGOInrCP0SAUAz9DJedU4FBpJluLoWCgr74HynNjkcVfka/BN7KY9Wsj5+mIqznZ9ab0G3X6iJob9ejpUy4mvsq/93/HbOvQrgEqwIP0VaaqrbCqqqqHL23mVUKUjxczf66SbclVSfZWFMVgUAx+xoqQd4EJDPAz7RGjhQNQKf5KCsqhyFyhxOKncPBUysO0ZM/LsfXF0axfGdn1xuWxcZ5DkK1Jv/KKFhh+8BVgBSoP1FeZqoKlqqrq/emAzRJi0uDKDzcSIcJbWlbug5DPYQmKCoKYHzFEBkEhZqDAfF1LBENoTBIlYzAQMXi7K0MlZqh48n6SXZl4KUMIMj9sKZJ+tkrXtNY1rbHtfN3kbM7VzJj4WheUmpfUaQ5B3shXwWFf5SE2PWorrKqq6r3JYIhICDFJh1pju6lIMEIxeOLEx4vjZKQY3k7LZj5hQ4CSokIIzp4QGfOBXuxZgEJIfiJkdMMe8OolxGiCGSJNkCEx30djkCnQGlszxpa9kYxiZ+TajEdGwo657D0EedllX6Ufl0seHVgueZ2v8tCqFaBWLFVVVfeqQ5NfE00niCcKMRvu5R4rU2FuytMA+V5JCL5E0h9+IqRiICUFRbohD2+DAYwBeYULSIkpRgtTqKjsB8srXHJmRfLqJClZQ3+kpdiysSY1pqZ1s77tRrN+Tl7qVLNj4+z4hKe/+kmQj54+ZfulhyDxE/Dvew7tGjcW44OBClDBUlVV9UCUD+XalPlEV4hJKGPG8GuIEAwIktxzyQ9JlCkYFCOoCDKfDIkmWpSn6yVQIViK0ThAJY5TYFGWosbTHzWeBinSbLliWddiXNAWZE+yyY+1kR2PfLS4P+L5b1TDl5qfPGFrNvoqf+z1855Du/A98H3xVfDwfZWpKliqqqreszis/JpeKp9bKVcAN/GBoc0FwAGT/0dBBBQRGWIkDYJJER6KjHknmEK0GIJFeMWCWKAyAQqjScnA6JuMY5o8GlNqzBaiVymNsfHju3qK7dSsPxrN+tMcgnx5zXLJD9FXmap6LO9RddS46lOW+yqWvwcMvsNlugPMUL5F/MTIAMECEBAQfQ9YaYuVX9PDL4IBlA1r8ykqIpLytL0f3uWQAXuKDpUYZVAazPnQuJ8yHStWvyJmyRRoDLR2Qca8rqWY9evZnJ295spe6+LVsWbHbtYfffYZX/6Datfrj85XmaqCpaqq6oHIQRIipOBFSV7TAiMCYIgOIyAwBEA7Do68NcYIReQpMUARJgYvaKKZL5uUTOypEC1F909QJr7KNNiwAp+GNpgC3aRfRuKoMZl/3puHVbp+NOtXdszZsRGTEGSXQ5Dd6g866v+k/8zLJfH8+ZBXwQeUVzmk2gqrqqq6P01+8vsI8aadH1La+SE5VB8xeU7FfMzYjyg2KCblvfbyEWP3VYJ5bsVHi71KUcw7wUL0vV+lFebjw4wZKuxB9T0VM1SySU+JKSVrUrK0EpuUsklPs4VoEnsju7azhrMNsz7xldxXoZocgvy1hCD/2Ovf8XeUQ7v2+ioP6HyV26qCpaqq6p51g8mwfaLnVIZgJFlS+QhI8geGZ+VpMJ8g9kkwmEnycGTM3ooDxqEiGNmDZe8X1yCU3GOJ9K3FHEOQXIpqPKuixo8Xbuimfbtl1i+Pjzl/1PNyTwjy6E18lfDhdM5rK6yqqup+ZbjyJw1jVASgfCYLvHclX88SwpCuT8N595qsAQORT5I0T94rIk+HQWT0ieSYp8AyVBwwcG8l51VSDCbQQKOQzfogI8nAZErBCJoWIhtf0xKb1vrYcNYb12bsTk/VPZtzacbmJXV6Qh2Z1PWbUPnPj9BXmaqCpaqq6q0U0lXhxiI350c47Kq0vnzvFwbI5HQ9ZAzjKZGTlhkAmFc2hAQDYgQJKXpYxSfCMLbEHCqeT/FjiLOPUlbfkz5+HGkCjYzUWmwaUbxk5BiCHM16ctWQs1cmO6YuT3o2Zup66tc19bj/k456fLS+ylS1FVZVVXUv2lh5f103jADMNm6UcnaFHtsI8FFjRn8AEGB5ZYuJuUpR9MUrvhI/mpCYYm6DDdNgshSjxTiBSkwFKqYoI1cUG2tTY22iNY2PGJcQZOMLXLxSMXJl5OzYuDzu2fxKNWbuq3zpvgrwEz5mX2WqCpaqqqp3IzPAbDDx/Vq+PgmxOJCiAAMNYIZLAYpDxlP2MUaHSD7DvrS6QsxLJyWmxgOQknxtS5AlRV8k2fc5x5JyKJLWxJyqT8mSlrSlm/TGxWDWNxT7bsZ2w6znYNZfbocg39BX2ej5fUCqrbCqqqp7l2Hyt1gz7+4MGZbcKItRCAF+PQApyo+eR2CSdvpn5rCJQ5bFAcMABTN5XgWk+rzZ2Oi7wKJRPdH7uSugLPoaMQbkEyCDHy2sFD2vkhpTiNY1rfWr9WDW9+mInZEoG4v7xzzlr9lX6ff4KptQwQdyvsptVcFSVVX1fhSjwmZMOMDMk8MxSuZnsARP1m/IkCfGAORmkbfJaIoxkYJi3gMmiSnKqDhCJVcsqZj39KkvMVArUWlFMZFrUg3ZRlJ5+qvvyFnOq3Snp1o9m3NuJ7SXv+n0xEOQ3T+oX9df6nG/HKHy9dd6DGxA5fsPcA/YTVRbYVVVVfemfTkVYL/lYszTXTH5SHHM+8AAgQYgivDAY4iRgC+YVPD1LYqRMeZ2WNv4/q825l1goHrltle0FJOl4q8k91bAcl59MlmyJtHaprW2aUxNZ6UF1tjMzfrZEVfzYzavpHP+pqOTJ27W0836neWSz58DwCZUAOzsAcOH6atMVcFSVVV1rUJq7vcHnTlIbHidhgO7fD1Lki8xjgLkra4QSZiCmWgmX9MS/cCufIBX7EUKuUKJealk8mmvtVc0XK1JuY8Sl2TikonFVyGNGpZL9nkH2KZZf8LmV+r1nhDk0fZyyR9+ALBl1n8kvspUFSxVVVX3qkNVy/C+oOEeEoxRZgYKMgOYJCSf+AoyxRDJbODHGKmYGKMvmfRTIOEBSDlU1PvrlBP11Jpaw1P29GqlIa2JjSH55BcbDhNg5RTIYtb3czJtmPUvs1kvzbgvr7LHVwE++BDkVaoeS1VV1b0r7DnjPucgMfw0NRsyMRtLJpW/PgiWR49jjIIZFCMjfKtxbiAx5mkwCtlfyRNgEqW1T4CBppisCfIgJGJO2DtUbLFgF/OWsLazbbN+1Rvnx8awYdZT/7MNlU/IV5mqVixVVVVvreuqknJPiEkh+XLIjfdK1WLmRwxPx4rzg7lCCWY5r5J3gsWx/RWzWU+BKRZ/pawWS4aYLNFPikxrkRS5WpHylpdpyYZi17Rm2ahvM1TWZkynp1odGefHJzx/SbV5Y3EJQeK/gKP+z/rP1Veaf/21Dvoqf91td30sUAEqWKqqqu5J2wb98LmN73h6Jf9AzRVLSMiA8eWSirn1NQGKIMboHknofbTYK5NIZWPeAZPPWonJmijz9liuWibGvZKsbRpLJC1vwPcQpNjPZmwPmPWvi1n/5eirYDsEuc9X2dLH4KtMVcFSVVX17jSBSg5KisgZlJi8kjFDqVAIZG+l+Cll0SRkJsWYKIkR/qyYbKxaHCopJotrN+iHhH1e3UKtmHywmEZfMGn0NS0NPQwZz87VGzmbmvV0s741q77KHlWPpaqq6k4UUhImocdNGZDfCjEJAZBZPtDLjRZCynvEhJj8rTIZFiESCGZCkigoGiSJMfkzywFeE6hEiVyLSH7yIxCMEpt8X0zZb2laswWp3AbrY0N2xtaMPcnOTnXBI81/o+zRS10+ecL2/3gIcsdX2Vou+an4KlPViqWqquqeZYC5Ac/ixeTKZeK1yM9diQoxjufXN94Gk43ZFSm5QZ/9FinmKbA0QCVlqCgmQ/JWGLVilNiUrEqicTJW3OUJsJ7KvsqcPY/Y2RFX/RHnx8blo8dsSbVSXi755Y5ZDzwHfvj0fJWpKliqqqruTG7OT438fHbK9FqBSvIllQNcUj7DPj/o5ks2+iXK/OAu9RKyUZ+rFEZMoJJME6iQYpLYMBlSMiPdtKfIpvFlkhKt9bxKm/Mq6fxMnZHbZv3lZ59xOwSJSQhyulzy3z4hX2WqCpaqqqo7lwMGouLmD08zME+HuZeiAS7lofwIMRImhSgqJgaDoiKFRDf1fbS4QCUOUFlTGS4xn/qoRKNE44olq+KwEVUmwEg23Yz9jJ5XmRkbSvvM+tlWCPI//9ceXwXf4zvgk/FVpqoeS1VV1X71191wlWzPWFjOqQDBzICUFGmhwGX79iDPsLiB3yvEJMJ8o3EPBYmU+ys+VpxYoJIkKskQ/HhhUVRsjFqyzf6KUmMmr10a87NVeiPbM6rvjjgzcnVsbH6jbMusr77K1aoVS1VV1Y202c7aeNq63B+EysbrnK732eGcccmTYTEmEibFyKg4TH1FZahEUUiTXWAOFQpMuSVG+rOiVytJZJsaK2taTGTXdNa0nS+XzOtaevNk/QWp5jdq+ah3X8Wkrn+2AZWT6qvsVQVLVVXVHWq3UqGkDajk1HyAhyKHYGQOQnoLTQq9hmAkJQV4XiXIWTT4KxKlNaPApgQio/spg7+SXxs5tL6a/HlPse08q9LPj9jNR7P+3KiWdF9lKwR5svpK/5FDkNVX2VQFS1VV1Y117TLKCVSKzzK+N1YqZfprOPwLUJD3qEpWJabk8IgehpQigxKVfAJshIqfu4IJVKQ1U/ZXWO5LjZnEJk+A2WQCbNusbyidv+Smr7IVgvxxKwT5qfsqU1WPpaqq6o40CT9mL2VomZkhpSSZhVK9yCyE/Dd4A0rFgmAQYKCigrmhzxgZoonoVabBvL3l61umUEny3AqteClerbQSU4aLWrFJHdUxH9pl7M04M4mvpOVxz+byTX2V/VD5FFpgRRUsVVVVt1JQkrAdhOwBCwgpiQAixkO7AF+Db7CAlBTNv5YJApK/bxksebNxSFFRUECSqfc2mCIjeklpApVECZTIlKsXSsQEKE0QU9OYLRxIRrLLLbD+XJp3c5Zk/dSsLxuLt0OQJxvLJff5Kn/dAcinBBWgtsKqqqreQO6NlLaY7eZXzEfKQkwK8OtB3vpigpj8ulcpSbGNDJII82s9REimXm7cR8YkSomMW1Dp6FNg0dteJauSKDapyWPGorV+pkoJQXbZrF+enemwWb8ZgjxZrQZfBQC+/BaqvsquKliqqqoOaN85j5sKKRvzG7eat7aynwJ4NeIAigqKKgsmy2O6FyzGRN9YnBiLSZ9E9qYRKqASmLroUJmNUEkE29TYMBWWGmuUzfq2Y9+R3Yxcz4yzOQ+b9c+o2VYI8kdgZ7nkv/0F+g745H2VqSpYqqqqbq4NgHhVYltQ8fUtSUPVkpP1Y4Xik1/DxNcEKME0tL5CbnuFXpJAMk6gknybcT7XvrTGEkETHSjHeaGk8njxYNbPuDyXZjzi2o44L2Y9uROC/J/rQpDfX23Wf2otsKLqsVRVVV2pHvv+BnqgmrFi3FswAClJshDGtS2AiEAlIWZvJSUBPYJ6WUyKgKIkAxSjfFeYElNaax9UlJIliogeeERqzLhkRzE0pLGj2SWbvMil5FUWPNWMx7p4JR0d97wqBHlylVkPVF9lS7ViqaqqupX2FC35dZ8hUaqWfLQwpJByut4ADqvxk0LyVpj1kAEK6EVJht6h0kNRYpBDJaaUNxg7VJoClTRCJXE8qMskNq3YdF0+WjjnVWZHnNmxm/VGnZE6fnLYrP+PPSHIq3yVT7UFVlTBUlVVtat961z6nReDmDAJQRZ/xeESYhoBM33Iz7G3nFlJ5fz6VDYV+2vFRArD9mJkkz5qTNebyKYRU/m8QIUcQpCdkcuzczUHzPrXcrN+tv7yRiHI74DaAjugCpaqqk9ab7EQLJcuIWk070vVMoQhkdP20MYjA4UpMXg2RWZQ6KUoUFEMk9HiKFHJoRLz5wUwSsmaPPnF1p8bdQ6VyQTY2tysX8+PON9n1tNDkP9z4xAkKlQOqHosVVVVe9Qjh1D2XB/fDgkehITPgqWUJPQhpCaHIcuobZr8CvkIYgCx96my3nr4fjBf3xKVSPTjFFjXEflMe06gkuSZFSsTYBSblrRGNHZsk9iTWs/mnJFcGzk/Ml68ko4Gs/6FHhWz/la+ytYYcfi0fZWpasVSVVV1vba8+h7FdM+foEdAksEQlM34pJxV8WkwQ/FRpBilqD5fkwpUwlqKUoZKcqgkz6sMK1w4Sd1TNLakxDaPFVveAdYyn6+S17UseKqGGsz6M1LtFWb9rX2VvSD+NFXBUlVVdUPl8WE0ihOTHhghU+BCJQUlBUk9/H9Rkj8cNEyRMSaG3qe+ojyvopRIjlBJW1CJE6iQfsxww5bMUGmMjJeXKlDpZ8bZAbP+dd5YjP/+b+wLQVZf5c1UwVJVVbWpbdtl8vmYru+HyyFB6LPXgjGvYjkoGZUUlQOSgJhE6924D+hV/BRKUkq0da+USlUy5lREMTYi5smYRDZie9wYG9Ea0tqOTdvR8gRYotTP5pzZEftjsjlo1lP/s/rDwRDkTZZLVqhsqnosVVVVW9o/EhZSI/UIQ8enB0IDyRBCgtTnH7HBAtCgrHJxJViS0GsSmMx+SkqkoNj3igKRkigxpWaASkoio7xGCR6UDGRuhfnRwuK4Bn8w63WmhY40f0Wtjo3tS/8lXpu5r/LlzXyVf/vLX/T9XrO++ir7VCuWqqqqa2bD/Djh8XO/O6ak4essVy4ASgvM171IJn8EjYl7Rd/7FZXIvlfoezElUtoPFTlUbGiDebq+QMVIri8v1RaozIyz+Zisv6DUklqePGFrdmtf5TsAPga2KZXgZ9WGKliqqj4lrbc+P0CUaWRlmk+Z+ixAn9/HsC9sWNeSGpkgm8AkAEo+Puyfa+1r8GPKXkoByT6oNExq2PgaSVIt0wQqZmRLcnV+oW4254xHXB+R+8z61/aFur7XfB9UbumrVO1XBUtVVdWofpM0oRn/Rl4Gw8rUF3ogJqnvywgx8ugw0FuPATSAUnSgjGHIRKXEGBOth5JEk1SgklKBSspQKW2vDJxGZNvS2o5t27HtZkOyfnF+pkSpeS3tN+s9BPmi/5P2hiCrr/LWqmCpqvqEFZvDJ0LGafurjBRPTpAM+Wtj8kmvTcDkxZJKHn4sVYvWij1kvRTWkEpVMq1YJNpaohIbYgMqTZuhkifA4uWlbDJWXCbAepua9Y/3mPUm/PQT8O9/B/aFIMtocfVV3kgVLFUfpObPntVv7Jtou/V18zd3q5fkq1mAfsyqACptMQfM5JG0kV1JOati6hUTqCSGnL6P67WYGpbKhRLjau3GCkVrHCrZr2eTx4qNZLy4UOK5lqSaM2mhUzXMZr1RLaV2crzwdGPxyf9a6T8uv97ZWFx9lbdTBUtVVVXWCJIwrWR6YGyElaqlwCVfy4ApjwEo8p1gsR+DkDGNPgupvVBJOaPCxiuUJhv2xpYNO5p1nqzvZrRuxs5mG+taLvhqYtb7FNiM3O+rHDLrq6/yxqpgqdor7zFXfVKaFjD9FDN5/1c/Vi0jXORByLz63pJkSUM4MiYopURTn3MrkPKGYlJMKXEvVPxkrrxUsiXZsmHLhuJaC1lHtp2fsdLNjP38iLPJBNjR8fHErNdg1r94S7O+tsBupgqWqvvXj9fd8GkrdbPhh1Xsunf2gysc8FcKJADkrMp4BHG5aAYwNSqA6fseJgl9jyj4mSp5XYspG/YSJTGs1zJl4GCtMWGf/ZbGq5PkBwSTFJuGtNaPF26NTJeXWulCUdLiXEo81YJS80o6Oj7hPrP+5/8CSggSwN4QJIADyyWrr3IbVbB86vr+uhtup8+//vrD/uY7ve6Gj1Vermyb+cxp+mHsOD/7RuMRMBHlAcF8TxhjYqlSysFdQZJSw5QSbb1WUkOm0g7L5j0bhwrJXks1jedXLBv0RvoEmM0mZv0x58fGi+KpkJpJKscL/8/KNFtWX+VdqYLlI9NfcbNvgGGZ3kelX3cv/bZ76YPQavdSbNvx92wFxDb/0N9z71SHKpOD3n0/zaq4ytixr28xTAETMIYhg9KYX4GPEZcx45QSlRqG9dqnwZoCFW1AJbvzPgFGcr1cyqHS0boZ226WJ8A217VckDp+9Jhn2ax/Rd9YPJ+a9dVXeSeqYHmP0g0h8L71w3U34PkV7z3sPlh38viD+D24e20lI3vAdgDk91BlBxgmFYuPE6MH0BtChklpe02rlCgNFUpYr6X8/iZUmk2o5AqFbNlYy0jJOrEl2c/I2WzOmZELSU1Z10LKobJp1ldf5d2rgqXqnenvV3y2T4/+8If38g3dPno0+eeeHb5xWxf7L6fZ/L38e2xqszzZbHlNILPO1crGSvxx8jg0XomU6yFBljMsAVBoJtmV3PqKgmy9VkoNB6hwGyqjYe9QyYZ99lWMZNSFVpSaM2qpMzWS5v1kXcuTMgG2z6z/Sp8fCEECqL7KHauC5SPT/RTtP2w8AcC/fPPNnX/DPfpjfye/5uzp0+HXmX1WXk97Yr9PXr/CrXQ+fHgrpdls8u+62HtPbG9n5Mdm0irb1x872PoqU17Okdg0GtphuQUWs/NeEBSayfkqzeijOFB871dKiVHIrxuapNjkabAmkUlME6g0JBu1NLZsW2+FWfZU2m5Gs9nGBNiCr9Vwsq6F1OygWf8jnj/H3hDkd8DuoV2ovsrbqILlk9f3d2fgX9ERO/nqq91v0p9278N/7blvBzllAAAddElEQVSWdfTll/u/0V8A8y++uPsfAu/KyF/e8OI1XgqAHXjsS9aHRtocJ87qN794PGNl/AEbNQJmOwxZ8itB8omwDBV/vVaUaCsoNYmmbNxPoEK1tEZs23xYl5Ftl7MqRnazOXsesUyAzY+Ps1nPwax/9cxDkPO9IUjooK+yreqrvJUqWKoO6sFmWX657ob96p58ds2/z81J0hwda3g+0AK7jfbXLO9C6w34hKZRv+6HqmUKl23AlPtDrlx815dXKbZe+/oWrD1Fr0TTFlRSgYovley1VFoutF4stZaUJK0vL5WGsWLfAdbbMRu+0sVvxaznplm/z1cZzHqo+ir3rwqW9yzdh4G/99jUt9MP193wBgb+4z/9+cp/95/Li/+eXh2pcnCtyzAc9hIv996wX+3JybW/FwUoO9fnR1vXL3eemzv0WjYmxABc3frqh0+3K5ig8nmpX8oXjebKeLjXCJjyKPmVICk2bugz+ZixbzJuGORZltSItppARQ6VHiv1WqohaexobetjxZ23wHqbcZbHihevy7qWY7ZWzHo7aNZ/vtesz99z1Ve5N1WwfIT66/Y3ywFtjBxf2w77YePpKu3NsrzxcNgGVXb0Ai+ufH9H2V7pHj/Rhr3yevvGzeql0SMVI/+Qw3IBoDm67ofSFbXJ8nD76zq/ZRM0JZMyudZPXkyAM70cUqMSiOzXEwj1OWGf0vAwJY1AaRTlULHcBvPw4yS30uTV902BSsO4lHqs5Ivwy6binFXpZmw5GybAejtio1PNj/ata/nioFn//IBZ/x1QfZV7VAXLR6h31R3ea+BfVbjg+smwbQN/ezLsoM8yyMuVqYF/VZblFfaMHJ+OT5sTYlvaaIFt4ibNr6tOHDDT1H2apO7H11PYTKuS1c6lbW9+vXV1u1qJQ06ltMPKHrD10BKj4ODIrbE+P2IDRWEACpO3uGJuiY25FTFgLbFhgE+BxZUUlyuxzd4KW1rro8TWFqiQ/WzGmc1ZJsD6/ojN1rqWvWY9gGvN+uqr3KsqWB6AdC/tsOtumOpwuTL1WX44eFfR1VS5CwN/0LbPcoWBP50MG32WqyfDrhw53mDIgfolQycpA6YUKgsgzma60lRZbra1UtsJq5EhEQ6d4fM2//mZkCVgUq2sJy+mr7MGz76fPjtcCmAGyExgEpomr2zJVYoyXJqGKYmmta/G34IKG9Gh0pLNFCodW84mY8XnWkqaToCtj0/KohfNvjhg1r9hCLK2wO5OFSwfqf66p8zfp3fXDvtxbzvsOp/F9d/X+Cx72mE38Fm6x092/tntydYPlz1+vvss55sGftEeI/8Su1mWBfLI8WK3cin7wrb4ckNN65bxFyjp+/Lu1Fvx9zarlqBGTpwRMMMDEvo1ysFcMbe8PAyZGLWWraWkxpP2WG1CRQUqnllp244rSvHyUitJ07HidLo9ASZdZ9bv91Xyn/O9UKm+yl2rguWBSHdctdy+qH+zqmW3Hfb8usJltx320+b7j/7Yq1QtP+P6dtguVvasdplqq1gZ6pUDPkupXvb6LBfjczM/0qbPcgsDf7mvhFlOvBVviUW1mrbB9q11iQM0gPXUwM8VSZycClnaYZa/JqJkWLYA069RVuBbygl7jGvxp2FIquRWIIdKswmVZoTKWtLq8lJt1+X19z5WXBZL9vM8AcbNdS37zfprfJV9Zj2qr3IfqmD5mPUm02F3WLXs6kecrHbbYTerWrBbteTCZZgO22qHzay0wF7inFe3w7oTbv5/OHWgnObXN2uHbfksdIjstMOw8HbYls+yAJD2/c35xpXLalKvHPZWCmxCU/5ZThyT1OfKZRcwPgFGwJdNToDCxle2NKkhmzxurJVSQ5INGzU+VqzWoUIyQlpLKlkVo9jNZrTZnOn8TD4BpnECjOO6ltlBsx660lfZ1x+uvsq9qILlAUl3XLV8d+vpsLutWq7adHz7qsU2fq3dqmW7brlZ1bJvOmyzHbZvOszbX+fb7bBctVzbDsuAWQy+y55qZbnaMfCjOq22qpVVfl3kFU3W2ifD1hNvJU5hsvabYj4BEvAWWb9eowCGaERAbBrFRkOFkuYNp1WKaa0eUtQ6Q6Vhv4KapmGvlRq1ZCOulwtFSEbls+pHqCzPL5Qk9bPpBNjmupaZSa+yWY+9Zv0VIcjqq7wzVbB87KpVS359ddXi02GHqxZvh5WqZat6uQCmVcu0HZbmu20xb4flamWy2iVJ2kZM8VnStetd1sPI8TpTJGxlXUKDYcdXaX2FSQssAiqeS1AzjBOPjyafsQL10GQPmPJKl7XYNEwqUNEWVKS2bVmgYiTXgpKk5fmFZrM5l2d5AuyoTIBtmfX5zPr5yvRiYtZ/fiAECaD6Ku9BFSwPTKpVy6AHVbVMCpehauH+qgUAtp+T5roENqbDAGCxt1pZTg78yuPGq/F1r1axy39OVkDftoptqyHz0rQafZYVolqVzcUhVx4AYGUVvqQh+5IB4z5MHisGRqA0I1CaJLLxMKSn591L6bXKUJGanKiPS8lXtXRs246eqIfKWHFDanl2ptk8T4C9KhNgbtbPJDfr8wTYiz9umvXPD4Qgq6/yflTB8imoVi359bupWpo5D5r43g7zz+O0WuEIsnWBSmbKelKtbAclvUpZDa+Lme8pe2kcO15nU99N/NhIWDtc1vDKJUgafJe+GPlA30i9pkDxhZI9fPRYqaG3wVZi4+b8FCoNWzJDJWmh9aXUdjMayW42Y3N2rn5+xERqwddbE2C6YgLszUKQ1Ve5f1WwPEDpg6lafth4771WLRku77tqAbBbrWQTH5cZKVveynqrHVZexw5KnWdYYiuVPAuw8ioF3QCVXq3GqqPVdPIrtFKUey1RPjI8hUsUVACDtVcw/eQR5RXMCBQprPN5K1opYJWrl4ZRUL+UGimf/pih0jpUrO38rPrZjInS6uxcszxW7BNg2wd2UTMz4ZdfsAGVr77Sm4Ygawvs/lXB8qnohlXL7XItWT9c9abPHu/Ltbx51XKDXMt7qlpKlVKqlpEylzmN79VKGTuO0ywLR8CsJz/8UictAWAFpFaKE8DErpMvhFx5xSI4bNaACSrwKC0xh0tZde9tsdg0I2AyZEoQ0h/ut/QYvRSfAPMVLU2pWJYQ2bBpRTZ5AkxkFJQWGSoUV5LS+YVsNmeStOCp5hkquxNg0qv+2a5Z/+OPOBSCBFB9lfesCpYHKt1H1XIztmR9v/E01d6qJT/dbs3Ljzj56ittVy2P+024HMy1ZLjsVi0YXjhcrlnzslW1THMt+6qW7VzLVVVLI19OOa1aVrO5sMgm/kbVskDqZipVS+q6DAogQRozK0vEFurVCqvcBlOr1eT1cO962hIb4WK5LRbggccIZcjkNfj5tWEKFPdSCmTiSupXUL+SSuAxYiU2LeNSKlDhkKp3qHRGLiWl87M8ASYtyA2jvn06nQA7YNYfCEFWX+X9q4LlAevO4XJDsuy0xG4Kl6xbtcRyGv/tW2JjlTF/9kx7l1NO0vjn22tefgeA3we4TKuW9kS6Wa7lfG/VMngtF2PVUkaPm9lcpWrZTuIvlmXM2P8cLFdA1GZLLLZtnuby130x4ldAhLzFNYFLaYvFJu/0UpkEKxuLfQ1+nx8peXvL22Ar9ZBS0zBqlU36hm7ULxWBESrtCJW27VhS9QUqMzMuKTU6HXaAldHiwax/dgOz/oa+yl1/L1VdrQqWB647/Yb46191+5bYLeDyw/jezeFyqCXWaxcuf9qFyxVG/ouNlliuWm7bEpum8U+B9hEnLbFJ1XJ0rHNM8ixDroW6yLApiynLhNjgpyw8MLnIcEmdhOVm9RIFjS2xpbfE1I1VCrqheunVKrZQgUsUtF77Chas1wiQsPbqxdtfyo8mn1vvAcioklFZqR9Gir1KYdNkk36lXlLTtiRbxuViByqry0t1OVW/lDSbOVRmc+OCnOwAu25dywGz/ga+StW7Vagtxw9D4U22tBzQd39DwF+vu8v1/37//eSf+xfgL7v3vPjhh+GebwHg22+H9/77+fOt/9/fAN8Av/3449b1r4GvgX/++9+3rn+F0+anjWvn/2gC/tVf/wnA+S8p4F/G9y9fRL//D8Di11/Dl/gS+BJYvHwZgGcAgGX6Pf+aX+BRLK8/xyq+CgCwOo0Bn/nVo7MY8ARYn+WfUI+B9XkMjx8D63O/1ofzAJygjxfhER6hv7wIOJ48Ly5DF/xei/k5hHCUn/vlImA+B5fL0IYQMJ/DVstgIYR5vocrBMwAQwjtOgQLq4BuBq5XoQkhAB2IVWD+5zQhBK4R0AFch4AWYI+AFkh9H4AWwjr/u3fYlA8IlFYa1kDfQBFyYMnhEjsoLqVeS0VJbNsBKpGSdR27SQvMclaljBXPj485HtgltfZCMzO96nt99sUXfNT3+qWY9T/+iPEkyB92fJXvagjywaiC5QPSncHlb38L3+GvuFe44Nvy4iBcgP2A+efuDeECoABmL1yATcA8A5a//x6AL7B69Xv4/HMA+Byr168CngLAU6xOXwd8NoXLWQAeD3ABgHnMUJnABXiE2R64HB8fob9chNvCBQDaEAKD/xlwuDhYbB0CgwOlA0AgcB0GoHQdwDUCw9rhE9YBaAEAbQswQwYoc2V5uky+nLIvns0K2dvJ1Qw6lcmvWHyXxdLhsgcqK1KzOdnbEX2xpPGC1HE/nQDb8lWWm77K8+fP8fj0G3kI8jqoVF/lfamC5QPTncMFuBFgNuEC7APMFC4A8O0ELsAewHzjdLlZ9fIVTn/+KeDP0/v+jPN//Bzwrw4XYLN6uXzxIgB/AP7gn9+melm9jhkuY/WyPovhCYCherkKLpcXAY+24QL0ixhwDHSXIeAYsEUIFhYBOEKpaPqAwOUyzOdz2HLpEJo5ZNoQAlergFkHWzlQZt0Mti6VioOjyX9OGMIAmSZXL8BYwQAA+xE0wHo4IGy19jHnApQo+cAAVhj8lAyZfrlU03p+pW07h8keqCxOqfn8mH2GSkvq0ZMnPH1xQ6iUFtiLb7UZgqy+ykNSBcsHqjsBzN/+FgDg3quXG7TGgHdXvQC5fpkAZgqXfdXLCJez8ARPMG2NreN5KFXM/DwEnAB9aZGV6iX4c1+eD7TGuuUiYH6EfrlwUMznaAtc8j0MIcwAMCDYyquW0horbbACmQarASzTaqVZrwfIbKvsHxt8mnYTKF6xdIqt1C8XatrOK5YCleyprCR1M3J1xtz6OtXcjukTYCNYlk+ecEjW7/gqB8z6ugfsQauC5QPWncAFeBjVyy29l9Ofm4PVC/D23svqVQz4HPgcY/WyOs1fX6qXPb7LABfgmtbYZvVi0auW0vbqtlpjFoJXMLk1xtUqzGYzcIU9XssMDKuArgPX64CuQ7OafA5ghMyuxvUwK0yBEtWqbyGslmiaNqftSyUjtUaHybVQOeEFfxsmwE4++4yHzHrgR/zH5aUqVD4sVbB8BLoTwEyrF+BeAPNt+fjt+P5t2mNn3d/DVxvX7q49tkgv8z/vmfsuz4Bp9XKoNQYAT/a0xm5UvVxehD76/YPXEkOwxSLg6Ai2XAxeS4ELALQxDK83qxevTMo1CyFwPQVKh64DuFqFwazvMMCmAKVsUC7J/ilQHCKdYpfPXsmjxEnSzaEitXw5TIB99vQpf89Q2WfWA8/x+PRUNzPrq6/yEFTB8pEoBIQ7+Xb629/CdwDwNoD5y25/7C7N/ZsA5vwfjX/dv5bq5ZcA/Av2AWbaHtsAzE71st/YX2dj/wmeYH12ugGYPp6Hkx3vBegvQ3h07M+lerFwGYBjdJO2l+XWWDtpjdly6S2ywdj3CqWdGPtAaYcBzWDkO2QAbFQu6DD2v4BhS/JqtfLdZBkose20XaVESkmSdTM6XC7U2Sx7KsWkJxevtseKf1VrNkyAzdZrzVcrvVj+ca9ZD1Rf5UNSBctHpnAX1Qvw7gDzFv7LfQHm8W8vA/4J2Fe9DIDJY8nAU6zi6wB85lC5FWC8apkV035SvdhiEY6OjzBUL8NkmBv7G4AJS69WZjNwtQozzMCwHPwX5umxZr0KwGxjspjr1fDftSy49DjMcoBK33YqeRgsl1h3ndq2Y6lSkqCkC5lluEygMg1AjlC5xQTYwUO79gCktsAejCpYPkKFEALu6vf1EwDMABcAi+bX/Ot/icd7qhfgC6zy5NgIGO+ROWDGCuZo23+BA2Z+EXLVEofqBcfAbFK94BiwyxBwfIRusRhaX4cAwzi2v4CxWhmqmNwmAwpMNgEDIBcs43HIPToBS0yBkiZVymomdbMZVxdSKpXLbJ5XtJxqfuztr+aVdGGeVekone6DynXJ+uqrfFCqYPmIVQHzLgDzuRv8OxXMFDCefSnTY/35ecDjE8wvzgMebVYvOJ6Y/IvLgOMj2OXixoAZWmTLEDDPfspshnIvJrJVBgx80SUwbOof1shEedp/EyizXKXkioUaFko2OtOCfEOoXG3WA9VX+VBUwfIJ6H4AA+CGY8q3BQxw3RTZ3QIGAD7fB5hJewzAHsB8AQBDBQN8jke3AUzOvlwNmO0KBugm2ZfyPHgwmFQtuYopGRhklfv2KeYfCH03E5ZA7JT3mEkrOVCwuMSKUvf0aW59ncuhkk9+lFQ8ldao9RZU5j31+9p3gG2b9Z9ffq3ntzHrUX2Vh6gKlk9Idw0YIC/9e5+AyU83G1O+G8As08vwT3k8eZrexxfA6nevYjYAMzX5ARzF/YABgPngt+TnME6S9YvRgwGAbmuCDHN/nucpMmAOCxkoc4CrDJqi2Xx8vVyM1Uo3LsVcYIE4BcpMSpoPra8VOTmnXmrom4ob7q9U5j31+5f7J8CuNOv9/9ruH97aAnuQqmD5BBVCCHf297wHARjgyhwMsL+KmQQtz//xjwD869WAQWmRjethHu9ZDwOMVcyjK8aU+3gWHk/XwzweR5PnWxmYaRXTx0UAjlGmyCwuwhEmRv8GZACggAbAfPjgrbOsVA4bWyywyq9TWdkv6RKX2ADKnEo6lvspGp+3lkpuQOUZtTlW/GcBf0f1VT4+VbB8wroPwAA3h8xNcjDANmS+ndowd+7DbANm8csv4Y97ALNRxWTOPH6ZW0zTHWQZMOvXMeQp5R3ADEb/Vg6mzzmY+SQHU4x+uwzhGJuTZIDnYHz3WG6VLRcToBwBANrlIkwBs8BiONWyrPN3mABpLuHSj05OR16h4MLfX1JKR1Q5T2V+/M9sWdbfXw2Vn34CbjIBBtTlkh+iKliq7hYwwB1UMTcBDHBTyBxqk539fRMy22n+aZtskSuYPwI7bTIAWPyagbC3ihmzMECGzIEsDPAER3tGlcsespOtLMwAmeLFYAoZh4vjBLmiATBc2dYlVspgmc+Fi0uko7kucImGR8LFOdKRtJSU6NVKQ2nxyOHSkrrgk2ug8if9hJ9wkwkwoPoqH6oqWKoGhcHUvaNv2+0q5q/XE+bNqpjrWmXXezFXQWZfFQP8C/64ZxcZkCEzVDH7d5Eh7yJbv341QmYrD3NzyIytMru82IAMgKFltqG8ADPNpeH05Kx05NdW8yMB50g6FnCOpY6VKDWPvPV1dgqU1tfFST75kdQZnw45lamngv8CphNgn3+Na6CCvSHIWq08fFWwVO3VUMUADwQy+wED7GmV+ROAt2+Vnf6cq5Y/++e7kPGFlxuQmayLKa2y5cuX4Z8AHMrEAJ9jHV+FpxuZmBEy/VkIj4GtkWWgz5mYXcj4r2qX/peF4+FDHmPeUjmQrCgdHQsX5/kAs3MkHmegPNLZ6RmaXKVc8LFaSvj9d7RPOKxpmdkXW0b9tFLxseLPL7/W/7dxtgqwYdbXFtgHqwqWqiu1UcVMnt5K99QqA94BZP48fj7dqgxkyPwLvF2GN4WM98scMsC+seX+zE3/YasyplNkXtGcAEPLzJWBA+wUL9OKpRyjfH6e4YIzNHqk5lGuUB5RjR4Lr19jrFI+U0fpJV5iXNPyzHMqeaT4J2AHKj5WnM9WAVDN+o9HFSxVN9adt8qADwoyAFBAcyeQgY8uA8/wT8DBbMwGZLZGl/s8uvx4x/gfR5j7i/Nc1QDl41Rnk484B5pjP24ZABZ8JOAUDR+pOZFevwaaE6rlk60q5almX0h48QK+++vLSU6lTH/tQgW4oa8SagjyQ1IFS9WtNQIGuA/IALjxGTF3ARngdp7M20PmcD6mQOZQPmadl2A+xf7pMuAJ+rPT8BjIY8xjVYN8zaEzqnn0SDgtn53ibOPaKRqe6DVeo7ETtY8p/I4MlKfCUKV8oVfPfPU9/huYr0yP/nhHUAFqtfKBqYKl6q30oCEzeZrqLqfLbgsZYBM0hyBTWmbAM/zTgYzM+nUGylPg6aSaGbwZIMPG1Z+Nv1ePgZElAIBTNCcn/rv32q+0J9SrVwDwCq09FvA72idPJkCZVinPNJuY9A6VXgBuARVUs/4jUQVL1Z3p3UAGb2D8AzedLrspZIBd0Jz97y7g//bXX2HfYWSHqxkAeHpNTmaZczIjaDbHmEvbDChrMfMgwACcqcqFV+Ol/PLi8RMBvwMAWn4m4DfgN+DsMwqAVyhffCG8ADaqlG0/ZZKox3OgQuXTUQVL1b1oEzLAna2SAe7Gl5k8TfWmoLkKMsAh0PwZ583Pw9ctftlc6f/0iqyMVzMA8AyPhwEAYLN1BmCkztBG29HvQPvks8lv0G8AgI5P9RIvAQCtPRXwKxwoL/Dq2TPhF2C7ShmCj9trWr75RvgB2AsVoJr1H5kqWKruXe8CMsBbguaG3sxWXGavN/Pb0Z6W2f/++xZoNlfKAPuqmW3QbOdlNifN/OozAF7VAGNlU9poV8shcvr0qfArAP+AUp3Mn1G/AJjRK5d9VQowaX3tCz8CuBlUqln/IauCpeqd695aZsAdVDPAbdpmU9DctJqZejNFNwONZ2YOVzTjqv/pE7ALnk1NAFL0wj/Mnz3TLwBKdQIAczO/bwg8ZoM+VykARj/lTaCCO/9TUfWOVcFS9d61AZq7/vP4UYNms6IBdn2abW3C5wUAYP7s2c5/9F8mIAEwVCcAUCoU/ORtL2C3SgGw5acAwM2gUltgH74qWKoelO61mgHeC2jyq7cCDfAV/rAPNAD2Tp0BG8ABxnFnwKfRjr78Uv/AAU1AAgCDhwKgVCjACBQA+I/Lr4VJlQJgx08BslGPCpWPWRUsVQ9a7xw0k6er9DYeTX4FYD9s9no0+0CzdbZM0SHg3EoZJADwU75UPBRgP1CAq6sU4IqcClCh8hGpgqXqg9K7BQ3wEKqafaABsAc2wFXAual+yh+O/jRWJgA2PBRgP1CAA1UKcLj1BVSofGSqYKn6oHXvoAHeqH0GvH1VAwD/z772GfZNngH7ps/eRl6VAKUyAbDhoQD7gQLg5q0voELlI1QFS9VHp3vZaTbVe6xqgNvCZqqvD1wfwbGtzy+/FuDhxqKphwK8BVCACpWPVBUsVR+9PpyqBnhT2Jw+fx6+wT59s/F0UM93XgyvpuHGoun4MPAmQKk5lY9ZFSxVn5x2ApsfE2wmT1Od5ipnypcRIa7H33wz/lf4YfgAYAISAPtMeeCGQAFqlfIJqIKlqgrvqKoB7h02wD7gFH27/zKAKUSALZAAA0wAvAVQ/EOFysevCpaqqgN66LABbgecW2kCEmAXJsAtgALUKuUTUwVLVdUt9K5hA9wVcIq2qTPCo2gfRKb67m9/8xcVKFUHVMFSVfWWemewAd440Pk2GioT4GYwAYD8n6RC5dNUBUtV1T3pfQCn6DsAt61yAAB/K197S5AUVaBUoYKlquqd6p3CZqot8OzotgDZVgVK1UQVLFVVD0DvDThvozrlVXVAFSxVVQ9YDw44YfhQgVJ1UBUsVVUfoHaAM3m6U1WQVL2BKliqqj4y7W4WAK6nzuaXVIhUvY0qWKqqqqqq7lTxuhuqqqqqqqpuowqWqqqqqqo7VQVLVVVVVdWdqoKlqqqqqupOVcFSVVVVVXWnqmCpqqqqqrpTVbBUVVVVVd2pKliqqqqqqu5UFSxVVVVVVXeqCpaqqqqqqjvV/w95SDyInc2iLAAAAABJRU5ErkJggg=="/></g></g></g></svg>';

    function fe(t, e) {
        var n = Object.keys(t);
        return Object.getOwnPropertySymbols && n.push.apply(n, Object.getOwnPropertySymbols(t)), e && (n = n.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), n
    }

    function pe(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function de() {
        window.innerWidth <= 568 ? ae.a.select("#box svg").first().size(400, 400) : ae.a.select("#box svg").first().size(600, 600), ae.a.select("#debris1 svg").first().size(200, 200), ae.a.select("#debris2 svg").first().size(200, 200), ae.a.select("#debris3 svg").first().size(200, 200);
        var t = ae.a.select("#box #a"), e = ae.a.select("#box #h"), n = ae.a.select("#box #b"),
            r = ae.a.select("#box #d"), i = ae.a.select("#box #c"), o = ae.a.select("#box #e"),
            s = ae.a.select("#box #f"), a = ae.a.select("#box #g");

        function c(c, l) {
            var u = 700 * c, h = function (t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? fe(n, !0).forEach(function (e) {
                        pe(t, e, n[e])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : fe(n).forEach(function (e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    })
                }
                return t
            }({ease: "<>", duration: 1}, l);
            t.animate(h).move(.2 * -u, .7 * -u), e.animate(h).move(.2 * u, .8 * u), n.animate(h).move(.5 * u, .3 * -u), r.animate(h).move(.5 * -u, .3 * u), i.animate(h).move(-u, .8 * -u), o.animate(h).move(.5 * -u, 0), s.animate(h).move(.7 * u, .3 * u), a.animate(h).move(.7 * u, .5 * -u)
        }

        function l(t) {
            return 5e3 * t
        }

        !function t() {
            ae.a.select("#debris1 svg g").animate({duration: 5e3}).move(200 * -Math.random(), 70 * Math.random()), ae.a.select("#debris2 svg g").animate({duration: 5e3}).move(140 * Math.random(), 100 * Math.random()), ae.a.select("#debris3 svg g").animate({duration: 5e3}).move(100 * Math.random(), 100 * Math.random()), setTimeout(t, 8e3)
        }(), c(.3), function t() {
            c(.7, {duration: l(.4)}), c(.3, {duration: l(.4)}), c(.8, {duration: l(.5)}), c(.4, {duration: l(.4)}), c(1, {duration: l(.6)}), c(0, {
                ease: "-",
                duration: 400,
                delay: 100
            }), setTimeout(t, 16e3)
        }()
    }

    var ye = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 2484.76 1659.17">\n    <defs>\n        \x3c!-- <filter x="0" y="0" width="1" height="1" id="solid">\n            <feFlood flood-color="#2e73d7"/>\n            <feComposite in="SourceGraphic" operator="xor"/>\n        </filter> --\x3e\n        <linearGradient id="arch-未命名的渐变_4" x1="274.35" y1="320.75" x2="1765.32" y2="1115.3" gradientUnits="userSpaceOnUse">\n            <stop offset="0" stop-color="#fff"/>\n            <stop offset="1" stop-color="#50aaff"/>\n        </linearGradient>\n        <linearGradient id="arch-未命名的渐变_4-2" x1="899.34" y1="794.55" x2="1345.24" y2="549.87" xlink:href="#arch-未命名的渐变_4"/>\n        <radialGradient id="arch-未命名的渐变_8" cx="1213.28" cy="622.01" r="362.15" gradientUnits="userSpaceOnUse">\n            <stop offset="0" stop-color="#fff"/>\n            <stop offset="1" stop-color="#5099ff"/>\n        </radialGradient>\n    </defs>\n    <filter id="dropshadow" height="130%">\n        <feGaussianBlur in="SourceAlpha" stdDeviation="4"/> \x3c!-- stdDeviation is how much to blur --\x3e\n        <feOffset dx="5" dy="5" result="offsetblur"/> \x3c!-- how much to offset --\x3e\n        <feComponentTransfer>\n            <feFuncA type="linear" slope="0.4"/> \x3c!-- slope is the opacity of the shadow --\x3e\n        </feComponentTransfer>\n        <feMerge> \n            <feMergeNode/> \x3c!-- this contains the offset blurred image --\x3e\n            <feMergeNode in="SourceGraphic"/> \x3c!-- this contains the element that the filter is applied to --\x3e\n        </feMerge>\n    </filter>\n    <title>Cloud Native</title>\n    <g style="isolation:isolate">\n        <g data-name="图层 1">\n            <polygon id="main-bg" points="1502.29 230.13 440.84 230.13 604.69 1241.78 1666.14 1241.78 1502.29 230.13" style="opacity:.42;fill:url(#arch-未命名的渐变_4)"/>\n            <polygon id="border-line" points="1502.29 230.13 440.84 230.13 604.69 1241.78 1666.14 1241.78 1502.29 230.13" style="fill:none;stroke:#50aaff;stroke-miterlimit:10;stroke-width:2.83464574813843px;stroke-dasharray:8.503936767578125"/>\n            <line id="cross-line-1" x1="440.84" y1="237.18" x2="1666.09" y2="1241.78" style="fill:none;stroke:#50aaff;stroke-miterlimit:10;stroke-width:.992125988006592px;stroke-dasharray:8.503936767578125"/>\n            <line id="cross-line-2" x1="1504.52" y1="227.4" x2="613.36" y2="1241.39" style="fill:none;stroke:#50aaff;stroke-miterlimit:10;stroke-width:.992125988006592px;stroke-dasharray:8.503936767578125"/>\n            <g id="cir-shadow" style="opacity:.26">\n                <image width="558" height="558" transform="translate(802.38 449.59)" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAi4AAAIuCAYAAACYSoPfAAAACXBIWXMAAAsSAAALEgHS3X78AAAgAElEQVR4Xuyd63bizM6tBel37fu/22+t7g77R14lYjKlUvkABuYzRo062IBdDtYTldN9ulwuJoQQQgjxDJxHOwghhBBCHAWJixBCCCGeBomLEEIIIZ4GiYsQQgghngaJixBCCCGeBomLEEIIIZ4GiYsQQgghngaJixBCCCGehl+jHYQQgnE6nU6jfSou+tcvhRALOOneIcR7sVY4joYESIj3QuIixAvxalKyFZIbIV4HiYsQT8Yd5eRen5Nxl5uTpEaI50LiIsRB2UFQtn6/o7HpzUxCI8QxkbgIcQA2kpTZ95jd/2jM3rxm979BMiPE45G4CHFnVkpK97Vb73c0ujeurfe7QTIjxH2RuAixMwtFZfSa0Xaz8T6j7cjs/rPM3oxG+4+2m433GW2/QSIjxL5IXITYmAWiUu1/z22zx2227DVmC4TA8tdU73XvbTdIZITYFomLECvZUFRmxtfuO/P6itn9ndkbz4y0dMey8Zl9q3GKREaIdUhchJhkUlRmBQHHO9Ix258Zq8b3YkYQOmOz/e4+S8ZvkMgIMYfERYgGE7IyE/xHglH1s/bMtk4/G9uTJSJR9bvbZt6T9bOxavwKSYwQYyQuQhBWikpnrCsbS9uj7Uv7Gd39ujeckSTMysho+5J2pz8zdoNERohbJC5C/MvGsrJGTLYY6+6P7U6f0dnHrBewRzIwkopqbHb/0VjV7vSzsRskMUJ8IXERb01TVvYQlY5grK1nt2Gb9bOxNXSCeVckZrYtrbvbsN3pZ2PXO+jGLd4YiYt4OxbKyiiAd4Vgpl66bbRvtX/VrsbWMAres8JwKfZj9dJtVT0aw3Y2NrxBS2LEuyFxEW/BRrIyCu4dMcikIxsb7dt5DxzLtnXb1dgMo8A9ao/EYjTW2Xf0HtVYrEdj2O70b5DEiHdA4iJelh1lpRobSUPV3rrP2tVYrKt2NTYDu/mMgnpXGqr21n3WrsZiPRrr9m+QxIhXReIiXo6GsOD2KkCPAvxICrr90Xi2rfs+Zr3xWFdt1p+lCsZVYK9EIhvHwsazfWfep+rbgtqJ/WrbDRIY8WpIXMRLsKGssHYW+LM262djM2Xm9WxfHDO7HccxJ7ZZfymdAD0SgEwasrGszOzbfT2O2aDN6m6b9a836oYvXgCJi3hqJoVlpp0F9EoAqpLtc268dqaci89ix2GkzeqqvYZRQGb1SAiYPHwW25eU7P2s8VrcxwbtWC9p3yCBEc+MxEU8JQNhwW0s4GZjLHBnQb8a7woJ7le9rvOecR9r7G+kXdXYrsYY7IbDAm5VLxGEjrhU++C2zvtl+1myL46b3Y7HMdyOY1n/Z4MCgHhCJC7iadhAVmKb1VUwnykdGTlPtjt9HLdkOxYj7arGdjUWYTebKgiPgveo+H6ZZIxk5HOy3XmfbrGkHfusrtqs/7NBwUA8CRIXcXgmhGXUZjUL3qPxkTBk7dmx0f7ZsXQyM14s6XfqCBtjsBvOKBhXwbtTZuSCSUln22gsO45s3JJ9cdyKutu+QgIjjo7ERRyWlcJS1Sxgz5RMHraoO/uw4+gITVYs6Ve1g/0ueOMZBeFOUGdlNotS1Z19ZursGGeKkXZVV+0rJDDiqPwa7SDEvSmEJQuacZwFWhaccSwL9CNJ8fZIQta0s7HseKrzqYqRdlU72B+BAXEUbFmQ7pbZzMpIWNa0cSw7HtZn40a2n8K2Eb5/7H/j30MJjDgayriIw9AUFtauahaUWRllMqp6JCDV2Mz7jI6DHT/rs2JJn9XYZv0MvOHE/qWoq2BdBXfsZ9mPjnhk/Wq88z5VXbVZsaRf1VX7Z1DBQhwEiYt4OBsLSxaIs1IF/pGMYL+7bWbf7POz48RzyPqxWNE3UmOb9TPwhsMCJgbg2Gb9WDCws6C/RFZGgrJkX9zGPn90DqNiSZ/VVftnUEFDPBiJi3gYGwkLC7xxLAvYVfCv2o8o+Pmj48dzZOfdmbu4zcna1ZgZD4JVwGTBtQrILJBXAZ/VHdm4R7kM2qzOzt3INiPtWFftn0EFD/EgJC7i7kwKC46xgIqBtwrWLNAzOcjGP5L9qm3Va3C/7DjY8WTnw867W4y0We1gH8ezGwyOZ0GUBdtu+SRtVmM7k4m/g328ZPtVr8dt2fGwY87OtSpWtL0fa2z/DCqIiDsjcRF3Y6GwsDoLtCxYVwE+E4IZOflYuG00Xh1f7Fc1m4+sWNJnNbZZPwNvOFWwxKDK+llhgbyqR8IwEg02jvt0t1XvyY6vOjc2H9k8WqPG9s+ggom4E/qrIrE7GwgLC6xZwaCNQT+2RyKRiQjbpzuW9bMxdrzsfNi5Z/MSixV9IzW2WX8EBjgWFDG4xnYWeEcBmwX3kQyM5KIjJ0vGsn2ykp2Pn/sptKvi+2X4Pt7+Rn+FJO6FMi5iN+4kLCxYdwJ+JQ6ZeGTbu3XV7pYTabOazU9WbNB22Bjrj8CbzgVqHKvaWflM+qzGdrdkYoEiMlN33ic7BnYO7JzZ/GAx0mY1tn8GFVzETijjIjbnDsJyJm0M6qNSZUgySZltsxrbrM8Knhs796qdFRu0We1gPxsz48ENx6ogWbWzkgVqFtCr4F/JAvY7UtJtV2PZsVTl/G99sa/rxOYmFgv7Zfh7efsbZWDEXkhcxGbsLCwsIGNAj+1KDjpSMtrW3Z/V7PjY2Knos3nANuuzObai7f1Y4/hozIwHPxy7QO3tS9FmfRaMP0k71thm/VHGY0ZaWH9mf/Y57BhjP57POYydLJ83n99TaDP8fbz9jQRGbI3ERazmQcKSBXeUgI6kxHZWsn1wnL0vq/E4s3IatKt5yooVfStqZ9QfgQEs67OaiQr2sXwO2iywxzYrmSCskZZqfCQw2eefjR9/PL9T6Mc2zqOF7RkX+/l5uNpPAiO2QuIiFrOjsLAgjIE7Kx1R6QjJh319Pzr7se3ZseBxjsqJtLM5yvrZXBtpV7Uz6o/AwJX1qxrbrM9kBfufpMZ2VVi2I5OXjpjE7X+a+2Xj7Fiqcrafcz9ZPn8Wtmf4e3j7GwmMWIvERUxzIGHB4D+SiEpMlmwffdaZ1Oy4WTmRNquxXRVL+nHcwe3YZv1ZMHDFPsqKt3EcAypKCyufpM1qbGdlJC9LBGYkLtX26rOy4/Zysh/puMCYBEYcAv1VkZgikZYsuLGAGdteWBBmATwTgEpOulIy6o/KSFi8rsQFzxXnI5urTrFBO9ajsQgb68BuPHHsAjUbuwzaozIjMJXE/CVtVneFpZKTUX9U2LExibmQNpu30TVwsvbXgAKRmEAZF9GikWXJgh62sbDAjIGbBX0mDFn5taJdjVXH0pWVTFyyuWFzh8UGY9aoq3Y1NgMLVqNgV9XYrsZYAB7JS2xnhckASgO2RyLyZ0U7K3gsZ7s97jh2sp/zP1kuL4yL/fysePtqf2VfxAwSF1HSEJbYzgIkK5WwsNKVlEpEsjobY31WUFjweEfnls0FzhW2s2LNtvdZjW3WH41nZMEJx2OfiUrchoKStbOSZRRQWuJYR2D+wlglLZmsxD4TlKxm75MVl5TYZuVk1/LBBMbn/BTaBq87hbFvJDCig8RFpEwsC7E6KxiEu7KSSUsmGqweCcwo65KV7FhH53cibVZn8+fFij5rx3o0lvW72xhVUMJtGPhGY5dBm/WzAMyExeuuxPwt6k6ZEZU/jX3Y+8byYbfHmglMFJlKYDIu9vOzc7Xv6XQ6SV5EhsRF3NDIsmCAY8GTlSxYY6CPwR/loCMq2Vhn30xafCw7LiYr2D9BnwlK1q6KDdo4Fsdxnwj2s7EtYEEKx1BSWBv3YbIS21X5HLQxmOMYBv5KXrzfXSrKJKUaj2MuKPi+8bjOdnsef+365xNFpprPyMV+fpa8fbWPsi8iQ+IirliYZWFBkwXgLHgzAahKJh6VqFT7snpUsuPGc6tEZSQuo2KDdlVXbdYfja8lC04s4FXtqq7ao5KJC9ZVYeKCApOVbpal02dtFJlYosCc7Vpk/GcuygfOlePbI/F1pzD28yJlXwQgcRFmZmuEJbZjQUmJ7UxaRqLCpIX1sWT7o8R0xOXRwmKDdqd2Yh+3ZWOdbTNUAYlti2MsCHbrql2VRwkMZl062Zas4PZf5P0zgWHyEiXGBcTnwux6/hzfF/HXe/trZ2VfREDi8ubstCxUiUomLGe7lYZKMipRGckLa7PPRVmZFZYTaceazVksVoxhnV2vbKzbR0bblzIKSLi96l+gxjHczgJsNvZZjKG4xHZXYJjEoEh0MigzBV//UXyubzvb9bGjwJxCm80Zu94X+/n58vbVfhIYYSZxeWtWZFmqwoI2BnkmBCgMayRlJC5MWFBWmLgwWYl9POcTqU9JnxUbtGPNxuK2Tj8bQzr7zBADVrXPaCzrY51tq9pZwaCcSQz2MeBnEoOFZUaqbMqS4nLyAZ93DrWLi4/F84g/w35tM3mJc+34a7z2sW+0fPTeSFzekA2zLCwYZ4WJCpOWWVn5p7EPkxUmL7PSwsqJ1GyusmJJv1NX7U6/u21rqs/y4MT2YQEv67N2p74k/ax8kjaTGFa68oLSkklMVX439vHvwN/QjyITJcaP+WS353UK4zhXGSgtJyPyYmbKvrwhEpc3Y+MsCwvUlazENmY7usKCotIVF/Y5RxEWS/pxPI7h9shsv7vtUcRjwgCF20b9CEoKjuH2GHCxfxSBmZGXX9AfiYwLDMrLH/v5DnzatcT8tduf9TgPZnzuIn4d4/W82kfZl/dD4vJGDKRlFDC9YFDGwB2DfCUGXVEZycqsuDBxQlnZW1is6Fujrtqsn43NbD8CJ7sNbHGbhe3xfGLQw358v0ujZgEX+7FsJTCZxKBELBGX36RfCUyUFxcVloE52fW5+PXzcbPruYlk1zqKzM/Okpe3QuLyBkxmWVhgjSUGaVZQACpZYeKSSUomKyNxwc/FY8Fj7QjLibSzecrm00ib1d0264/Gke5+jwIFhHGy24Dnr0GpQYHB/WK7KzE4FsWFCUxHYpi0eD8Tl5HA/EraLjEoL7/t9vuMGZg/dvtd8WM92c/5xO+Bn78Zn8dIlJaba6Wlo/dB4vLibJBlYVmETFa6wlKVSlRGEsOEhckKFnYOmahkssLkhc0na8d6NIbtamxm+4i1r+9SBZ3OMcSghpzs+v19v0pgTmQM66p9Dm0XlDP0UVyw/5e0XVZ+hTZKTCUwTFyitMSxP/YjKFg+wjYXFRSYLPtyCuNex3kZEa/PN8q+vD4SlxdlwywLBmomLCxzgcIwEpVKUCpxiX38rBlhQVnBEucA21UxqNmYU41F2Fg1njG7/z2YOSYWnKrXV1Lj+PZMVtiY19lYLExkKon5tK+fTSYumIVxifkDbZQYXBr6ldQoMjELwzIwKDAoMZh9iQKD8mJ2PU9IlBa8Jsq+vDgSlxekmWXxNgbTk90GaJSWSliiPFTSMpKSf4pt2EZZwXokLdhm543zMipG2qyu2qw/Go909nlmRueHQYvt35UZDJCxndWVwDCR+SQ1tqvsSyYwUVow2xIlhtWZvLikVALz177OD+XlZFxg4pjZ9bww2DW5uubKvrwmv0Y7iOeiKS0YWLGwgN0VlkpWOoJSiUslLF7WCEsmKl1hMdKuamyzfjY2s30pe71vl7UBJzv++L5sn5HMnOznPbyd1WbzEsMExusP+wn2sT0SGMy+oMRkAhPbUV5cTiqBQWHpCIxLio+xeUOyeTczk7y8IBKXF2GDpaEztGPQxkDPCopDtpzTFZVutoV9diYrHWHBeTg1ipE2q7HN+tlYZ1uXLd7jHnSPczYosfetZKYrMr7PpaiXCIy3OwLDJAaFBEUGn2mJktJpR5FBgYmicrZreYkCE0XGz8H7ZtfzwEB58TEzMy0dvRgSlxfgQVmWX9DGgqKBUsL6s9mWD1J7G2UFReXDrs+TzUFVjLRZXbWrsWq8w5rXPhvVuXYDFXsPfy1uG4mMc7I8G9CRmCgwZ7sWF2+fQ//DbsXl034yIy45KDIoLVXWJYpKbLu4fMDYOWzz71psx++UH/fJ+tmX7PrifJuZKfvyIkhcnpwJacG2l5GwRAGIBeVhjazMSgt+PooLygpKSyxsDlixpF/V2K7GqvGKJa95J7L56QQvfG1XZE6wL5OXuA8G4UpgsI7iEuUlSoy347jLCIrMb2j/Im0UmExiftv1/SN+7zzjc4KxU6hx+SjOT5Z58e1sns3MJC8vgMTliSHSwgImC7YxQKOwsICPYoA3MJSLrqh0pcX7TJiYVFXSciLtOEexb7DNGjW2WX80njG7v8hhczkKZviarsg4J+NB1Wt/LZMYXzpxkUFpuYQ2ygsTF8y+xO+TLyF15IVJjL+Ht33bGbb795BlYDD74mNmfG4QnN/4OsnLkyNxeUKaWRZvZ4UJCwb8WKIsZLLSlZSOsKC4dIQlkxUmLrHOipE2q7HN+tlYxez+Yh0436PAlu0fx5dKDAbnOM7kJYpLHGfyghKDAvMnlCghUVAygclE5jfU+L10efHvJUqL1ye7Fhg/1zhnDkqLz6GZmZ57eWIkLk9GU1ow6MaSCUsmLZmwMOFYUypp+YB2PC48bhSXE2njXGTzZUWNbdbPxjJm9hX7g9djFODi/ltIjL8mljjm+6HEoMjE7S4rntHA51+ixGDWBbMvH5MlLh2x+09cOorfQyYvJ7sVmIxsbs3MlH15QiQuT8SGS0OZtLCSCcuMrPyn2IYCxAoKVBSUeBNkN0R2/qekGGk7bIz1szFGdz9xDPB6VcEu7jsjMQ4GWiYyJ9J2ScnEJWZhosjEpZ0oMV6ixGT3BfzlYiQw2XcWn305Wy4vJ7sWmCgxPie+Lc6pj33tKHl5KiQuT8ICacESgzjeMPYQFiYrPobvge+fyQqWrrBUsuLFGrWD/WwM6ewjnge8nlngi/uNJOZk/H183GssJ9L2n30UGJSWKAcuKfE+4NmX7K+JmLDMSgz7DrvAYInyEnFpOdu17MXtcX6v5lry8jxIXA7OjktDH6EeCUsUDZSOSlCy7fF9UFiYuDBhYTc6PFecB4MxnDcLddWuxpDOPuI1iNd6C4lxPMCyoBuL2Vfg9m3n0GcCg8tH7NkXzL5EgfHv6Ehisu8wux+xwgTG5cXCWHfpyME51XMvT4LE5cBMSAu2/UblNStMWFBcmKiw8h+oK2GJ4sKkBY+FyQq7yZ2gfYI2mycramfUZ3T2Ea9N/BlYIjFMYBwPtl77a3EMpSW2o7jErEuUmLgN7xfxH53L5ORX0mb3oLh8hN/j7Pv8177A/ToCE+fK62+UfTk2EpeDMiktrDBxiYEfbzAsw5JJCxOUWWlBYdkiy5Ld4HC+rKixXY3NbBfvS/zZGElMNwsTiYHX2zEgo7QwecHaC1s++ghjSx7SZd/tThktHSFR6DAz5eMnqL+RvBwXicsBWfk8CxOWKC4oLF6jTFTCgpLCxrGPMrQ2y3KC9gnasRjUbD6xzfrIaLsQSPyZYUGRbfcxJjAx4GIQzgTGx/w7s1X2Jd5L8BcQ7J9Jm92z2PecfddZ9mVJ5sXHzMwkLwdF4nIwNpAW/LLjTYLdYEZZFhSTUd2Vlg9oY9lLWNicRthYZ5sQM8SfpUpiWBYG8eDLxkYZmNhmtZeYfcF7Cv47LaPvczXOBAa/+zPZF5+XjrwYtCUvB0TichAmloa8jgW/1LGwG8issLDMSiUt3o/vyUSpKywfdn1+eN5YjLRjjW3WR0bbhViD/3ytzcJ40GWBuCswHvzjGLuv/CFjLi8oI1XB7zvrx3sc+87HgtmXKCxV9iXuE+dPD+0eDInLAZiQFmzjlxm/9CNpyYQly6ZUwpI914JZFhSW2M5uWOw82Q3LSDvW2Gb97jYh9iD+zM1kYVBgnBiAvZ0JzCmMs+dfPuxn6YhlXfB7jP9XEX7H8T5VSctSgcE5uYSaCUyclzh3ZmbKvhwEicuDmZQWVtgXO94QUBJQWLxmyzwsy1JlXTJh+Qc+fyQs3o7nV92sjLRjjW3W724T4l74z+G9BCbW/n37tDwDEwWG3XuilGSFiUolLvHYRvcEC20fd1lxGYvz4EheDo7E5YGslBYM7NnNIopClWWpMiyjrEtsMzHKhCW7ccWbVHWDMtKONbZZv7tNiEfhP5f3EBiWffFx9gBv7H/YdSaG3ZOye9U56Wf3BHY/YPeGuGyEZFkX33aC+hvJy2ORuDyIjR/CzX67ibLQybJk0pJlWli2hQnL1lkWI+1YY5v1u9uEOAr+c7qnwGCwjvecKvtyttvsC96bcIy1K2lh94cTjOO9wgsTGD//rrz4mJmZ5OWBSFweQENaTtBmX9Ds5hDlYG2WJRMXJixRXEZZluoGxW5AZ/sijhmpsc36o3Ehjg4LvrhticB4Py6j+Petyr7M3KOqsRlpwf6JFIO2972eeWgXJe+rI3l5CBKXO1NIC6vxZoBfXJZp6SwNsezJSFqYsPwH3hulZSQsH3Z788luQuxGxG5IWX80LsQz4j/PawXG97nY13fwEooHebwn/Q1tLLichIVlXUbigmV0v2D3jmzpKMoaCk3cN2ZhzMwkLw9A4nJHVkpL/LLiF50JC5OW2QxLJ9sSP6fKtGQ3KDzH6qaD84Rt1h+NC/EK+M/3UoGJwdjblbzEsZh1YWLBylJZie/duXeM7huxxr+kcqKsYP31YsnLXZG43ImmtMQ2fjnZFx8zLSgtrIwEpSMuHWnxY6puUtWNx5K+k80nko0L8Yr4z/sWAhP7KC+YgcHx+L3ulDUiE48jG8f7iGdenCgqWfbFTPJyCCQuO7PTXw4tkRYUEC//D/prpAWzLNXNKJ5fVqyoHTa/1bgQ74D//M8KTBSZq8D8Lx7QT3YrL3EMH97F+9jawu6Vo/tJVlBizH6kxc83zkMpL2amf6huZyQuO7KxtEQJiMLiNS4LzWRZMnn5h9T4WSgsoyxLPC923kbasXbY3FbjQrwj/n3oCkyGB+hYTsbl5WS3y0fsntYdy6RlJDOsOOx84xhbMoqk8mJmyr7sjMRlJzaQFixRBKIkjLIsTFxQVLCPGRosbGkoZlq6wuJts+vzN1I7bF6rcSHEz/djicBgYPZ+zEj4eCzV8hG712Vj2X2kEpZs3Ejbwe0uLZKXgyFxuR/4RWFfKvYldQmoloaiuDDx6MhKlW3Jloe2XBqyosZ2JBsXQtzi35eOwIyWj1xaZrIv8T4wIyj4njjO+nH/CL6Xj7ElI2eRvIh9kLjswMSDuKMvM0oLZlrY8lAlIx15GS0PYaZlJC14buyGwebHwbmMVNuEEDlZkPXvVJSVDH8PLxZqvL+hvLD7AZOV7L44kpbqXhPHnNG5mv1kmdj4CWozM2VddkLisjEbSksUgVGWZUZaMnmploeiuGTPsyzJsrC5iWQ3k85NRghR49+jTGBmlo/Mvr7rVfYljjFpYfcMdj8ZSUq3GOlHcKx67kXyckckLhuysbRUy0NRJlA6qixLJi8oLP8J74+ZFlweipLFbj54UzHSjjW2I9m4EGI5/r1aunwUt3WyLycbP/eStTvS0hEZJ7bj2Mn40pHk5QBIXDZiI2nBLAtmN6qloX8sz6aMhCXKD2ZaZqSlupngTQNrbEeycSHEdvj3rBKYLNCPsi++X5SC6h6B95LRPaWznw3aTmyzMcnLg5G4bMDO0jJaGsJsSyYrLPOSCctIWlBYYsHzq24SMzcLIcR98O8dE5jZ7IsH+ZPdBvrq/pgVvG+OhMaLU32m2e3+GZKXByJxWcmDpIUJS0dasodxcXnI63gc1dLQzG87scZ2pHPzEELsx1XQDWNm/ezL2a6Xj9i9gf2bL+x+0t3WLRbqJUheHoTEZQU7SUvMbqBIZMKSScpoiQizLfHz8FjwWDNh8baFMSM1tqsxIcRj8O/j2uxL9W++WFKzeybeb7B09sFiocY260ckLw9A4rKQO0pLlWnB5Z+10oKZlg8oZ1Kqm4SRGtuR6gYhhHgcV4E3jJn1si8uLd5n73Wy6/+9md1L1haDtlNtGyF5uTMSlwXcQVpi9iNKy2yWZVZaYkFhQXGJ51TdIGKN7WpMCHEs/Hu6NPviZJmX6v6ZjY+KJe2sj2TjiOTljkhctqf6Ei2RFsyyzAhL9kyL1/HzmLTgsTJhiW0jbWftjUEIcQyugm8YM8tlxffxrEu2dGRQZ2W0Pbsfsc9Alt6T/E+8GZKTDZG4TDLItsRt8QvElliWSEtHWNZISzwmlmUZZVqM1NiuxoQQz4F/f7vZF8SlhS0d+f3EH9rF8TXFSDvWS8A5iFmXOBfej3OkrMsCJC4TNKUFvyiZsMSSSYtLBnuWZSQs8TW4NIRLROyZFpZlmV0aym4Ga24SQojjcBWEw5gZXyJh3/2YeTHL7ynZPTa+DrePxvF4RvcuZyQa8d+uMbs+d8nLSiQuTRrPtXj7ZLfBPpMWXKLpPs8ykpe4P5MW/NxseQgzLfHcLIxlc4GMbgZCiOcjBmQcr5aO4j7Zv/fC7jXsXpwV3I6viYzuX2ZjYYngcy8sEyV5WYDEpUFDWtgXZiQvTFhmpYXJC3t9FJZseajKtMSa3RRije1qTAjxOlwFYjIWAzZu86yLB3vfzu4vcRvug2NxPOtvQVz28r5LC34Wy0SZmUlemkhcBiyQFsxOsGxLJS0oMFlmJZOXpctDLNOC58NuFKyObH2DEEIcF/++49KPj2HAxvuDC4wZfw92D8KxSLZ/Bm5DIcnAfVzC/B6Kf20keVmBxGUOFqhjGWVZuvIyIyqdTAtbHvJjYMISxSUrFmpsV2NCiNfnKhjDWOe+EAUmwu7BuJ3dq+L2mf0jUaiwzcTFyf5UOpUXUSNxKSDZlqvNSamEBeWhWiLC51VGWRbMtizNtJxIHW8S7IbB5qlzcxJCvC4sGMexGLRxu2cszmGc3X/w3pTdi9i2bH8UkUpKurKR/ak0fb2yLjUSl4TGX3uVWkoAACAASURBVBBhybItLgZbCku2PNTNtOAzLZhlYdkWK+oIGxNCvCd+P4hBOI6dQo3ErAsToFG/EpZYI0vEJMKyMBfjWZe43efCzCQvFRIXQuO5ljieycvM8hAKzEhYZqTF65hpyZaHJC1CiD24CsowxuqIB3zPviB4n1p7H2KyEAXqQvpsmxOlJR4bypzkpYnEBWhICwZ1D/YxuxLFZXZ5qFvY8pDXUVhYpgXFJRMWJi7YrsaEEMIZyUtFzL50701MZqrXOpUoMCnJtmVj+G+8+H4nqL92krzcIHGpwR9uFtSzpaGlz7YwgfkPtCtpGS0PbS0toxuOEEI4fr9g2YbYzu4ro+wLY3SPQvlgcpJlWqptRmpn6s+kxTUSlwBkW0bSgsF+JCwzS0PZGBMYJi2zy0N+/GbX52SkjoxuCEIIwcDAHIUmk5eT3f4fR3Gb16zdoZIWtm+2HUUIt8V7busvjZR1uUbi8i8b/AVRlnFBeUHhyLIt2dJR3LcrLUxYWLbFSDvWkZkbghBCICgvcSyTF5eWLOuy5L6UCQHLorCC+4+Ko780WojExai0YBAfCQtmWtYsD1XtNdLi9YnUlaxIWoQQe7FEXsx+shWYKV7CBWpvo7TEdkdq8LUZ+kujSd5eXBoP48bxjsBUy0NRNmYzLEuWh2aeabGidpbeGIQQIsPvKzEgM3lBifHsC752FnwtykZHYFBY8LX4Gu+jcFVz8DUoeZG4ACxwd2Slm21BCckyLCgxLEOzpbQwUZG0CCHuyVWADv3RvQezL2vIJCaTlmy/WamZ+kujd+etxSV5rmVGWrJMSyYsuDSUiUomK1FYJC1CiFcjk5fYZvejNfKCAuI1ygqOz+wbycZHf2n0zbtnXd5WXIolIm9XJcu0RIHJloZG8tIVlj2khd0QJC1CiHvC5MXsNgOBLJEXJiCxvbSM3iPi5xPvybjdDOblneXlLcWl+VwLikqVbcmkpZtxyZ5zidKD7+mfJWkRQrwaKC9xbCt5YQLhNdvWEZKlJRIf1vVteO5fg28qL28pLgAL4NhmApM907JEWrDdybZIWoQQr8ze8nIZ1N6OcjESkFGxQTveny+kHeu35e3EZYPnWtjSkNe4jMMEhi0LMWFhmRb8DEmLEOKV2VteIhdSZ+WzGP8M22M7kxgntvW8S8Fbicvkcy1naDN5YdIShYNlT7KMy0haMmHZUlokLEKIo+H3pRict5CXTBo64sKEJdadwj7Dx/wezv5lXTMQmHeTl7cSF4AFbyYvnYxLlJbOElGWZUF56QiLpEUI8Q5cBevQXyIvF/u6b3obRSJre/lstKuxrFioMevi43jeb8fbiEtziSi2UV5QWFxacGnoP3YrLygs1V8RjZaGMnmRtAghXp0t5KUK9pmodAoKSrZMVC0dWejHe/eFtK/O452yLm8hLpNLRFFWqmxL9ixLJ9tSZVmybAtKEwqLpEUI8Q6skRe/T5pxWbiEPtaZgKCgsGWjmaxLPA6z/HkXM5iLd5GXtxAXIAZwJiyZvGSZligwI2GplopQWthnZMtDKDCSFiHEK7NUXhgX+1k2imNRICrBmF02qh7YZZ/r8Qifd4nb41y8PC8vLpBtqQI4Cktsj5aHRhmX0bMtUVpweYgtUWUZF0mLEOJdWCIvfl/PyOQhK5W0YEamKyyx+LHGrEt1zm+RdXlpcWk+18IKykrn2ZYs41JlWOLrqmdaosCwLAuTFyO1I2kRQrwCs/LimYsoL1mQr8QFRYRJC25jMoNtLxE/D3Y/v5IW59Xl5aXFBYgXO5MVVmaEZSQvWWHPtFSyEkVF0iKEeGeWyovfP1FQPkLbkjYTGZQWNob7YzsrTsy8OL79RmBelZcVlwVLRExgOs+1ZBmX7sO4mbCwZaJRlkXSIoR4R2blxe+hmH1xuqJSicuFjGVlJC5+DvE+X53vS2ddXlJcVi4RMWmJ8tJ5pqWSF/b6maWhTF4cSYsQ4h0ZyYuPmeXS4pLwEfpxfCQqI2nJ5Ia9tpIXs+t7Op7n1w4vKi8vKS4ABvVKVlhh2Rb2fMqMvESByYSFZVowyxLJfqBZXwghXpFKXoxs89oFBoN8JhCZYCzJtDCRcak6w/s7n3Z7X/ftNwLzarycuGy8RDRaHhpJS9we6yrrUj2Ee4J2JjFCCCFuYfdKz76gwFzs53kXs2sZYLIykpQZcakK3vfjcUVRu5jZS2ZdXkpcFi4RsQxLZ4moIy2VxKCsdLItlbRg7UhqhBDvxHfQhn6skbPlRHFBWckEpisyF2h3RMbs+jzi+VxJi/Nq8vJS4gLEi1kJS2yjrFTZlo60sCwLvh+TFpSVTFgkLUIIccsSefFY4LgofED/Yl/37q6cLClMWGLx4/y023Px874RmFfhZcRlkG2J/UxgPqCNAvOPXcsLCsmMvPh7obTgceBxSlqEEKLHrLzEJSO/58YMhy8befkFfZZBQSH5GwqOVyLjsSF+HsYCdq4/Ay+UdXkZcQHiDySTlSgs2TIRZkZGGZd/oM36mHFhy0MoL1oeEkKIZczKi8cGhGVdmLBgHYWkEhYmLihBF/uRqShULA749huBeQVeQlyKB3IrYYltJizeZtJSZVcyYYnvg5/BRKUSFgttSYsQQuSM5MXHsHZJiLLQFZgs05JlVLJtmNXB4pL1afzef3Wer5J1eXpx2WmJaIvloUpYorSgOGXy4sS+pEUIIcZU8mJhm/fP9iUDLPtysfEy0UhIosxU++B7eryIn42/2LLz/Bl4AXl5enEBWIDPhCUWzLigvFTLQ2wsk5e4NBTbLAuUHX+GpEUIIXJugjhsY2MuLp7duNht1iVmRjKB6QhL1v8VxmKmxdtm1xIWzyUK2VPLSuSpxeXOS0SZqLAsDBMWzLYwgYrCwuTFSC2EEGIeD+axjnjWBQUmygNmP5YKy0hitGQUeGpxIeAFqwSmyrjg8g4KS0dg8LUoRmx5aJRpyaRFEiOEEGO+gzf0M3mJccPs+rUx24GFSUtHZLz/D9k/Fo8X8TMxXrDzfAmeVlySbIu3MdgzafkgJWZFUEIwq8JEJY5F8cHPOYc6y7RYqGNb0iKEEMsZyQuOZZmXD6hjdiQTjr92Kyw4Nsq+fFqeefE4ghKG5/XUWZenFJfGA7knUrJMCy7j/APt7K+FRtmW+D4x2zLzXIuRdkTSIoQQ81TyYnYb+FFaPNuBS0WYcYntKuuCbdZHYfHMSyYvzo20OM8qL08pLgATFm8zWVmSbWHCMsq2MFlhS0Ms24LywpC0CCHEcm4COWyLZFkXlJe1WZdMWpj0oMh4cXx7lDGz+ryfgqcTl8kHcrFk8sKyLqxUf0n0C+pMYFBYmKyggMVaCCHE9nhAjzVu93v2JdQoL1iifPxj1+LBlolGUoPFj8PFisWRSDzHp8y6PJ24ELIfro6wZJmWLOtSZVxQXj7sWlhcWrKlIiYombRIYoQQYj3fARz6cTyOeebFsy5OlJfPUMfMS5SWTE5YQdnJsi5RpFBc2Dk+LU8lLhs8kDsjL5hZwYxLVrJlonOo43GhZBlpRyQtQgixHZW8GLR9e1wu8nu7y4vLxC+7zrh0My2V2HjbPydmXaK4RHnB40che7qsy1OJC4EF9UxaUFZmsi0oLdlfDzFhQWlBYcnkhSFpEUKI7UF5wW0Rz7qgwHxA7VLhWZcoHv/YrZTE8gf6mK3Jsi5YYkx5mazL04hLM9uSSQsTmF9JYbLClomqP33O5IVJChOWE9RCCCHuhwf2GOCruOPZDpcWFxevsyUjFJpuYVkclnWJ2ZZ4/E+ddXkacSFkP0Qso9HJuoyWgLBglgYzLl5jlgX7kSgwbJsQQoh9iJIS+37vxW1n++FiP9LgscbFIS4ZRemImZeYZcE6ykrsewxDefHPisfofTMiLc/GU4hLI9sS2x1hYVmWTraFyQtmWzDDki0RseJIWoQQ4v5k8uJtJMYbs+usi9//XSpi1iUu/4yyK7FE0WFZF5elmHmJMYaJ2Pc5PkvW5SnEhVAFf5SWSl5Y9qRTWLals0RUiYuFOiJpEUKI+4HyEsfYL5V+b4/CUC0Zrcm6ROHx17OsSxQXlBfk8KKCHF5cimzL1W6kZNKC2RYmLTPZlkxaMMuCtYU6tiUqQghxHKK0YJbC7+lxmSbWLhUX+8m4eL0064KFZV78GHyJKBYmKt/jz5B1Oby4EJikZMLCMi2ZvHSzLnFpCOUlSktnichIOyKJEUKI+4MBPoqKQdu3e/zx7R9Qs+WimazLH/uJNygvmHVxWYqZF4w9kUOLCnJocWlkWzrSEttLZCX766EoLyNhycSlEhNJixBCPA6UF9yGfb/XZ1kXr6O8fNqPtER5qQSmyrr8DZ+J4hLlxez23L7P9+hZl0OLC4EF/fgDwwSmyrZ0hKWSFcy0oLycSG2hjm2JihBCHBcP7FFo4tjZbpeMWNbF5eVvqKO8/An9rrh41iVmXjwG+nKRH1c85shhRQU5rLgsyLagsIykpSswTFow04LighmXSrgs1I4kRgghHk+UlNj3e3RnySgKTMy0eObFxYNlXv7YuiUjj0PZctFTZl0OKy6EKvjHrAaTFhQNlJUZecmyLh1hweNnSFqEEOI4oLzgNuzHEsUBBcbFJS7zRGlh4oLZGB/3WITPucQMUGyjgDmHFBXkkOKyItuC8pIJTCfbgqLiNb6ffwZKC/Yt1LEtURFCiOchBv1sychxYYniEqUFf5mO8uKSguKCWZeYefH3+2vXMQilJf4C/XRZl0OKCwElJY6hqKCsoLRkUpLJyy9ox2zLmdRRVqrjtlA7khghhDgeUVJiPwZ//MXU45Mv03yE2qUlZkmitESRQXH5A9swA+Mxj2VdYsFzcA4nKsjhxGUy23KGNopElmnJhCUTmygrWJg4VbKSMdouhBDicaC8sO1mt1mNKA0xTrlUxDjFpOUfqP/YrbTErEt81iW2fbkoHlM85sj3uR4x63I4cSGcoOAYZlqwRmkZyUs325IJDB4vilg8ByGEEM+JB3cM/lmcilkXlwh81mU261I9qBulxT83SpQf29NlXQ4lLhtkW2KmBSVjJC1sfEZWsB4JTEQSI4QQx8cDPeuz+3qUlrNd/6XP2qwLyovv6+/DHtL1Y4jHheLlfJ/b0bIuhxIXAgv8KC+sRLlAYcnkpMq2MBGK4pLJi4Ua29WYEEKIY4LygmPe9lgQnzGJdRQXFw2UFhSYP2GM/ZXRr9D2OPXXbmPkU2ddDiMuG2dbsPyCMhKWKCmVsDB5qWTLQi2EEOL5wcCPEhBjlQvDh90KTMyU4F8NoaygwMT9POsSy0tlXQ4jLoRKAFBYMnnBCx+l5R+7lRYmMZkMVcJipM+QxAghxPPxHdCTbU7MaqDAeLy62PVykceu+LwLLhlVz7r4a18263IIcZnMtuAPgNejLAvKS7YslBWUlSgsmbw4J6iFEEK8DjHwx2Af7/1RWryNv3T/sp8lo7j84zGKLRWx7Aw+oBuzLv7Z3sa4dfisyyHEhcAmk8kKXnyWGUFhySQmk5VRtoVJSyYwEUmMEEI8LygpuA37KC/sWZfsQV2UF5QVzLqw5aKYdfmEOkoXHvvDRQU5j3bYm0a2xcfxwnv9EeqOtLAlokxYUF6iIEVpiW2z6/OoxoQQQjwv3Xs9xgkWSzB2sTiGv3Djow6jX7zjZ8ZYOvpl+3scYvZD+DXa4QHgRc+EJRa8+OxCswvLhIZdePwcdkwWxlhbCCHEa3Oy/EHduEQUny3x2PIZ2h7HfLnHn3XJnmlhY/H1MYbFh3Qvdpt1icdr9nNOh+E82mFPimwLE4COvGTZFrzA2fMt8XWZrWKJx2ahzhhtF0II8TyM7ukslrFYwmJOjEf4y/do5YDFMRa/MI7h8Trf7UdnXR4qLgQmL6xUssKkJbuwbBzfCy82u9A2aAshhHgPOjEhxrIY02Jcw3g0il1VTKskpoq1zqHi2K/RDg8gu8DxQlemml3s7NmWUbblHOoZeWEc6uILIYTYhJONH9SNy0YeQy5Qf9jPA7rx33bxZSKPWdlfF8XlohgHR38azf7CCJe5DsPDMi6Nh3I7woLSktnpjJn667vCgvJioS1REUKI94PFgCxuxNgS49rZ8l/EsxjGCouRWTzNYprzPfbI5aJfox3uSHZRswuMF2BGWjJZwYvckRez62PMeNhFFkIIsTsnG2ddzG4fzJ3NuiyJc/66GC87/64Lxq1DZF7Oox32oJltiW2UBjTTKB94UdmyUCUwXWHJLuwJamwLIYR4Tdh9n8UILCy+xVg0+sW8inMxNmYZF4yzThmfH5V1eYi4ELKLzS4ukxZ2gfCixj97rqRlRl7Mro9PCCGEYGCsmJWWTF5ibKukBeMdkxcsFmpsP4y7i8vCP4Fm0oLyUtloVboXtLqwzmEvtBBCiLvA7v8sVrAYx2Jd9gv6bKkyLh15oXHtEVmXu4sLASejuqDxojITnRGYuG/2PpW8mF0foxBCCFGRCQGTliq+LYl1VYxjsRaL8/B4dwRxMctlAKWhuqCji9e9qMxAKxN1TlBjWwghxHvA4gCLGVhYvGMxbxTXuvEOYx7GXRabH85dxWXBQ7koMKOL2bmgH0U7vmclL2bXxyeEEEJ0yISg+iXd26M4tlRYMN5hbCvj9b2Xi+4qLgQ2Maei+MVDaRldtOwiRmE52+3FRGHJZOUENbaFEEK8F1l8w31YnPOaxaYYu9bEvxhLszgX491h4tujxcXsdmLYRcSCFxFFJLuYOJ4Z6Im0s+MUQgghZmBSwKQltjFeVbEt+yUdYx3+sh4/N5OXh8e9u4lLc5mISQteOHYB44XpXshMWqoLxy7aCWpsCyGEeE9YXGAxJCvsl/Ys/lW/qDN5ibEvxsAYe6vYZ3HsnstFdxMXQnWx8MLFCxgnGi9IduHYxUVh6QiMk11EIYQQokMWVyphwX6VXaniodcz0sLKQ7iLuDSzLbGNk5hdxOoiZdaZlUxYvG1hzDlBjW0hhBDvTSdmxHGMP1nsw8Ji3uiXeRb7MPaO4tv32L2yLncRF0J2IbHECYx2OCprLlj8oWHCgvIihBBCLGEUZ5i8MImphGUUL2NsjTGXxWQLNbbvxqPExSy/SNXF+oB2Jio4jheWXbR4oUby4v1YY1sIIYQw68UOFg8xLrFf3lmMY3GQiQyLrdkv8VU8vCu7i0tzmagqlWUyEckEhslKdbE68iKEEEKsYSQtLEbFGJbFw0xWql/eK2HBeBj5HrvHctHu4kKoRCaTlUxaRrIySpMxeelcrBPU2BZCCCEinRiSlY60sJhYxciRvGBMjDw09j1CXMyuJ6JzsXBi48VgF6u6YHjxZ4RFCCGE2JNOTMQY1o1/LHZmcXYUEx8WH3cVl4XLROdQY2GWOHOxYmHywkTG7PYYLdRCCCHELKP4ksXBGLuy+LYkLmZxMJMY5Hts7+WiXcWFkIlMJi/xwmUXiF0sHKsuUHVhsguEdPYRQgjx3nRiRRWLYszKYmO2EjGKnzE2sliM8TBr7869xcXs+uSxzYSFmWYmLdWFQkut5AWpLpgQQgixBIwrVfzJpAXrLA6OViBYwc82uz7O7Jh3ZTdxWbhMVAkLuyh4cUYXCqXlBO2sONl5CCGEEB1GcaSKRSx2ZdLCBAbbHXmp4iPyPbbnctFu4kLIBKC6OExYqouT7VddnPiZ7KJkF0gIIYTYEhZ7WIzqxsgl8bIjLU7W3pV7iotZLgSZOOCFmblI1YVgBY/BQh3bD7lQQgghXoZubEFpGcWxNfERYyWLx1n8vmssPI92WMLGy0RxcrOJxzSY99lrqgtjpC+EEELcmyo2YbxkcY7FxFGmhcXJLF5mcfJ7bK/lol3EhZCJTFdeKmkZFfY+1QWJ4FjWFkIIIWYYxUXcN4uRWZxbUrL4WwnL3ePivcTF7PpkWbsSmI9QY+mYJLso2eeOLowQQgixBxh3RmVGVkaxkklQFRuz9u7cU1ycbPLxIsQLMZKXrqzECzG6KAZtIYQQ4h5gHKriZhU7u4XFWBY7s7h5VzYXl8HzLay/5iJUf9Y1exEicQxrbAshhBBLYHEl1llsijGMxUoWA6uYifETYyWTlkja3+M5l83FhYAneioKTlhXYLLJZxcBJ58VIYQQ4giM4lUWK5fEzKqMYubdYug9xCUST6h7EUaTPXMh8DMqacnaQgghxB5UMSiLlfeMnZ14uTubiktzmSibgJHtfYR6NOG47+giGNQ4FrnrBRJCCPHSVHGmilFZ7KxiYSduViWL3xZq57u/9XLRpuJCYCeSTfoJapz06iLgWHURZiZeCCGEeDSZtGTyksXLKn6yOovNWQx1do2le4uLWX5SbOJH0lIVduGYsIwmHo83awshhBBbUMUcjE0YN1l8y0onjo7khcVNh41tzj3ExWEnml2E0WTj5M7IDJt0rLEthBBC3BMWjzKJ6cTNbgzN4nAmLJnE7MZm4tJ8viX2R5MeJ3TJxYht/LxKXoQQQoijkUkLi6csDo5iZxV3OwJjVX/L51w2ExcCE4NOqQSGmWJVs/fLPteg7X3WFkIIIbakij2jOMriXCdGMqnpyEonju4WM/cUl4zRhGPp2mJ3wuNYJPZ3m3AhhBCiSRWXWEyr4uraWFrF1btyHu2wAHYSeJKsxAkZTXg1Vk169flCCCHEkenEUBY/Z2Ioi5udGJrF0s3j63m0Q4fB2lXcNjrhOEEoIZkt4vaurBi0vT9qCyGEEHvQiUEshmVxFAUG42smLRhfR3G7FS+3es5lE3EhjATBx9DmsslmhsgmlwlLNfEOHqsQQghxBLI4ymJaFv+2iKnxvb2OsJi/Szw9j3bYgM5EV5McJztObCfbwt77LhMrhBBC7ADGrq6wYKysMi6jWMpiubN7TD2PdpgkO2B2kigv2SRXE4vbcDsTFoM2Y2ZfIYQQYitm4g/uy2JfJ1ZWiQEso3jOGJ3HFOfRDiMmn2/xekZeOhPLhOUE7U4RQgghjsgofmE8ZbF1TcaliqcWamxfscVzLqvFhcBOBk8MJzObZCYt2UVYM8nO6gkVQgghNqaKV1mcq2JjlXGpYikbN6jZcW3KebTDhmSTm01IZoNZjZN7IuM4kZtPqBBCCLEzTA4wlsZYGMdHsbRaLhrF8buwt7iMTjJOZlUqWWEFLxhOLE5w7GdtIYQQ4h50Y1KMaSy2jmLsbGyNMXZUduM82qFi4v8nwvYWEzwqbBJZO/aFEEKII1LFLrZtFFNnY2uM1Sy+WtG+6q99zuU82mESlIBqQuOkdieYTTabXHzvanKFEEKIZwTjWhb/ZmJoVbLYymK9kXoTzqMdFsAOkJ0gm+TR5Hafb8kmlU1oJI5tOtFCCCHEBKN4hKJQxVbsV7F0JDSjeI5sHkv3EBeHCcLohHFyuxPZnVQLtbc3n1QhhBBiJzBuxdjWjalZWfJAbnU8u7CVuGQHmE3oaPKWTCzWowll40IIIcRRwbjFJIHFW6xHMXWmsHg7coJVnEc7ZGz4D8/Fya0mtBKW2Max7oQKIYQQz0YWY0excTbespg6irFpvF3zgO55tMMEeNDViVSTO1vwPUbFQh1pTbYQQghxJ0ZxCeNtVfaMtQ4eD45twnm0wyTZxHbK2gnNJtVI7e3NJlIIIYS4E5UwxO0sLo7iaRZjMbZWBdk01p5HOyykEgU2maNJqyYSx7JJxAvqbDqhQgghxI6wuGp2G+OymLtl7GWx1kJ7l/h6Hu2wgtEkxsnMJnZUqvd1Yn+XSRRCCCEeCMbbOF7F3pnCYnYVf3eLt1uICx4cTlpWswnsTGi1TzaBFtpsMtl+QgghxKMZxScW21gsnI2n2T4sxmY1tll/mkXi0ngaeHRCbCJwotj4SFKycXa8o3MQQgghjkoW12ZiYxVfq9iM72dJXcbZhktQFokLIROEbBKzSc0mcbR99P5G2rEWQgghnoVKEkbxcEmMjdtH7x+PxcnGF7GVuDDiAY5OECckm0Tcxl7LJihrCyGEEM9MFeu6cXYUb6s424m7m7KHuMSDZyfCJhInDieRbasmEj/LQl3R2UcIIYS4J53YVMU+Fnex7sbeTqIAP3tT1opL94CyiUObY6Wa3Fhnk2ihz463ew5CCCHEo6niGIt9LPZ24moWj1n8zmJvRnc/ylpxQeLBxImsCpsAnEg2adnEjyZyZnKFEEKIo1LFuCrWsl/8MdaOYnNVLNTYXs20uDSeAq4OvCojq2PbuxMXx5zReQghhBBHhcW0LPbNxN4sDndir1PF3isaTnHDtLgQcKLYdjyhmUk8hXZlgtXE4ZgQQgjxKnRiXxZrWYzNYnFW8HMY7LgWsYW4mPEDyU4om8AlEzs7cRVLXiOEEELcgyUxqhOHZxIDI4nBz0GWnMMNW4mLc4La21lBMckmbukkZpPqbDKJQgghxB3J4lm3dGJqNz5XsfYE9SZsLS5m1we6pHQnju2/6eQIIYQQL0AVY6tYy2LsTLFQb8YacekcDO4zOsnOxKG8jN47wsaEEEKIZ6WKdVk8ZLGUtdk+o/c20md09qGsERcEJ+UEbbZ9NEEoMKNiSb1kUoUQQogjw2LbKBaOSpY4yOKxw2Ixbt+EKXFp/NkSk4Q43i1sckYCY0WNbSGEEOKVYPGO1VvG3SwWR7Lxnx3GbnHFlLgQcFLY9rhtdMI4YZiFGU2ihXqGJa8RQggh7smSWBVjYxVvsR7FWxZ/4+cw1sTpb9aKixk/gOxERmV2ouLnVG3GqokTQgghHsgoto3i40yZic0O9uP4KrYQlwqcrDjWnaBswhz8DNwWayGEEOJVYTFvFCOXxmCMx9lnbM6W4sIOPtvm7WxyOhOFE7brRAkhhBBPDIuZozKKy/G9Y83GNovRW4qLGT/QpWVWXqwYj9uFEEKIVyKLd504uUUMZsVIvQlbi0tFPIG9CrL7BAohhBAPhMW4Kh7uUSzUu7NUXKoDrCZxb7h/PgAAIABJREFUdPJYRk84O+wzhRBCiHemio0s3nb/gpcVI+1YMxbF6qXiguCHV5MU292C75FNGKuxjSyaOCGEEOIBdONZFRuXxNlR/K0+G8dX0RaXxj8QgweejbMTmS3xtawWQgghxBdVrBzF2yoG++tjm8XhbPxnh7FjfNMWlwUwydi6WFLjGNKeICGEEOKgjGJcJ1ZuWRzsb8oacWEHG8dZv5owNo5jTjVhcZ9YCyGEEK9OFfuq2Dkbj3E8bndYfK7idos14jILm0w2CZ3CWDURQgghxIvSiZ2zJb4+1ruzp7jEk4s1O/lqvPP6DjP7CiGEEM/ETIxbG3M7r585nin2FBcHT8jb1QRlfSd7L9aP7DaRQgghxIOoYt4oXmK7G4uz99o9zm4lLidSqv2wX01u9t7Va5DdJ1IIIYR4MLOxN7a7MXY29mavW8xW4sKYmYBqAnF7rONrkM0mSQghhHgiunGRxdZRDGbjcRu2N2dPcXGqE8P9skmN7dHE7DZZQgghxJORxUkWU+N23JfF7Lgdx3fjHuLCwBNmJ84mpZqQkfAwdp9gIYQQYmO6cW02FmaxN/a7MXk3lojLkgNlJ8omtJqU0WTi/kIIIYSYj5+zMTnuO8v0a5aIS4dqkrLtePAnKLjP0kkSQggh3pkqNmPczfbBsbhfFtc3YWtxWXrAbNJG+wghhBBiOaOYjTF5JvbuFrO3FpeMytCyCeme9OyEdvcTQgghjk43pnViZSUpo9g9itWbsYW4zBxoR1biGLazPnvNzHEJIYQQr8QoPo7ia7Ytbl8Sb2f2pWwhLlswEpiZbVVfCCGEeHW6sXAUT7vvc1f2FpfRpLCa7Tc7WbP7CyGEEK/GbCx8VMyeYm9xYcSTGmVadj15IYQQQtyAcTjLvOwuKYyWuJxOp7UHdrK5E2T7ZVLTfU8hhBDi3WGxM4vP3fg6G+MpXddoiUuDtQdcTVj1vms+UwghhHhHOnF1jcgw1nrCN1uJyxZ0JtLbuO9mEyKEEEK8IJ3Y2Y3DD+VI4mLGJ1UIIYQQ9+PQsXgvcZnJgBx6goQQQog3ZmmMnvGAKfYSlw67nZQQQgghduOh8fuR4lLxsAkRQgghhJkdNBYfVVyEEEIIIW44qrhcRjsIIYQQYlcOGYsfKS4XO+ikCCGEECLlofF7L3GZOSncr/s6IYQQQuzL0hg94wFT7CUuS1k6QUIIIYTYhkPH4iOJSzUxcRuzuN3MTgghhHgBOrGzG4cfylbislYc2GsvUDPWfKYQQgjxjnTiahWXl7DWE75picvlcln7YRebO+hswpgZdt9TCCGEeHdY7Mzicze+zsZ4Stc1WuKyMfHk8CAzORFCCCHEfRhJTYzhd4/Te4tLdVIoL9V+sxMzu78QQgjxaszGwkfF7Cn2Fpcuo8zLzLaqL4QQQrw63Vg4iqfd97krW4jLzImMjA0nCttZn71m5riEEEKIV2IUH0fxNdsWty+JtzP7UrYQlw5MMkYnnk0wMjtx3f2EEEKIo9ONaZ1YyWJ13Daqu8eyiq3FpTrpCjxx9tq7T44QQgjxwoxiNsbkmdi7W8zeWlyc7IArQ8MTu0DBfTafDCGEEOINqGIzxt1sHxyL+2VxfROWiMuSA+mcaNyvs08c33WShBBCiCdmNn7OxuS47yzTr1kiLlvAJqWazI6YsAnFNjI9YUIIIcSD6ca12ViYxd7Y78bk3biHuFRCgvuxicJ2Nqm4nxBCCPHuZHGSxdS4HfdlMTtux/Hd2FNccGKyiWD7VdtjHV+DZONCCCHEK9ONiyy2jmIwG4/bsL05W4lLdTJsP+x3JiCbQPYaZLcJFEIIIQ7CbOyN7W6MnY292esWs5W4VFyg9jaOZ5OWvT62ZyZRCCGEeCVG4lD1sd2Nxdl77R5n9xSX6kSricleV+3XYWZfIYQQ4pmYiXFrY27n9TPHM8We4oLgiXl7SWHsOlFCCCHEk9KJnbMlvj7Wu7NGXDKRYCeFJ5ZNwmiiOpPo3H0yhRBCiAdTxb5RHB3F2Go8bndYfK7idos14jIiO4GZgq/D9zLj++E2ZPGECSGEEAdhFOOquJjF1ey1nYLvtQttcblcLtVBsAPHbbEfx9eW+J5CCCGE4Owdf+N4BF9zu0PtGFe0xWWCzgmxcVY+k3F8rRU1tpH2ZAkhhBAPphvPqtg4isFZ7GWvje8xGt+EpeLSORA88D2Kc0lqIYQQ4l2pYuMovq4pFuqKzj43LBWXLmsma2R82WRF2CQumighhBDigLAYV8XDbpmJwfEzYr0LW4sLmzgc22KSqklj43G7EEII8Upk8a4TJ7ulE6MNahzbhC3FpTrA2cn7TNrdIoQQQohxvFwTf9lnIBeoV7OluDDYicxMWqcYtCPVhG02iUIIIcSdWRLzMGZ2SicmR7J4vBlbiMtogmJ/VND0Psk4e+/Yxn12nUAhhBDiQMTYNxszY8ydybxkn8Pi7+qYvFZcRnKAAtEtbJJwIqsJY1TbR68VQgghHs2aODaKuVncrV7HYnAVjy9QL2JKXCb/Ebq4L55QNWlZ1mVpEUIIId6JUVysSpZtGcVjC3VsD+PxzD8+ZzYpLhOwA+6ULDU1M4kIm9SpSRJCCCEOCIttVRyMcTRLFoza3WKh3pQ14tI9IHYCbPJwUrGdTXScpPjeOB63CyGEEK9AFuc68XEUX7P4HMfje8d6RHe/G9aIS0Y8eDwRnIBsAtnkzBZk8SQJIYQQByeLe0sKE5lRPDaocWwzthYXdqCjCWITg8Y3yrbg5FkxHtl8QoUQQoidqWJaJx5m8RcTBrPywj431puwlbiwg5qZuGoSu9uyiYtUk7fpxAohhBAbsiR+jWJtJiQzyQIWd7M4vEmc3UJcLlCz7Z2SpaZmMy54PJtMlBBCCPEEsBg4ir2jeNtJFmAMRjaLydPi0vizpZE8sEn7hP6lMcb68TOwro5JCCGEeCZm41wVO7txNxOY+BlYl7G24RQ3TIvLgM4JZBOQ2V5mg5nMsIJMT5QQQghxMLL4VpVOTM32yeJ3jLVYY3s1a8VldDDxBDoTySaFTVq3OGwicZsQQghxdKo4hnFvplQCE/cZvY+FOmO0vWStuDDYCYwmCyeNTWC2TzZxBv3ORHX2EUIIIe5JJzZhzI3jLO7OxlrcpypG+puxh7hEOhPIJnM0cdlrqgl0Np9EIYQQ4kGw+NaJsWw8E5WurBjpb85W4sIOPtuOk8UmprK8kcjgscSajQkhhBDPRDe+VbF3NsayfbO4i4y2T7FIXBpPAc9MYiYsbAKzycRJ7Uzm6ByEEEKIo5LFtSzOMukYxdgq5mZxNtZlnG24BGWRuAD4wbGPJ+LtmcnLJjG7EGwiLbTZRLH9hBBCiEczik9VnMXSiaWjwmK4kx1LZHWM3UJcMuIJjCYPx0YTiNvZZzixv3rChBBCiIOB8TaOs/jblZUqNscxFn93i7d7iQs7cHZycSKrickmGi9E9v4GNR6XEEII8QywuGp2G+NYnM3i5ijOjkQli6u7xNetxYUdZHWSbFK7ZXQh4kSyScSJFkIIIZ6BkSiw2Mr6ozjL4m6nIJvG2i3FJZu4als1qZ9m9jdpr5lUC3Ukjm06yUIIIcQCRnGJxdSsjOJnFW+zeI0xFY+HbVvNYnEZPA3MJptNcCYs3cn117MaJ3fzyRNCCCEeDIutGAezGMlialVY7K4EJY23S/+iyGyFuADZAWQTmk1gVrKJzS4IfpaDx4PjQgghxFHBuJXJQhZrR7G3KzFZrGXHE9kk1m4lLozOhLKJrcpfqNdOaBwXQgghjg7GrRjbZmNrJ6Z2Ymt2PLuwh7iwg81ONJsQNrFswuM2vFBVsVBH2OQLIYQQ92YUj2IsqwqLrRg/q5iL74PjLL5GNo+lW4sLSgGKQjWxo9I1Q3xPNqmbT6QQQghxZ7L4msXDNbE1i6ksvmKs3TTmrhIXeLgGDyzbVp30aGJnCptQC2022UIIIcQR6cSubkxdEmur2O1k7av+mgdzzVaKS4PqRDsTi5PYNcNLqNkEpxNatIUQQoh70I1JMaax2NqNsVmsrWLsqOzG3uISqSaWTS5OKKtHz7lUk2yhFkIIIZ6FkbDEGIjjGDtHNROWKq7uzh7iwuQARaGSC5yo0URWhU0sHkvkbhMvhBBCNKniVRbnRvFxJsbie8YYblCz49qU1eKy8B+iWzLJVaYFJzu+Z/Z5rAghhBBHZBS/MJ6y2Ipxk2VeqlLFzhhD03i69vkWsw3EBcgOqDPJmayMUlqsHScZJ9xCndG6AEIIIcTGzMSfGNMw3rFYytosplYSM4rnjNF5TLG1uDDwIjBpGQlMR1pGkxzbFtqbTqgQQgixIxi7ZmJpR15mYimLo7vH1L3EJZtY3Ocz1NVEVxOcTTZewNFEx2MVQgghjkAWR1lMy+IfxlRsVysXLLZ6HWExf5d4uom4TD7nkpU4IWwCWSqrugCVsFQ/CKO2EEIIsQedGJQJAsbTKjayOMq2M1mpYqpB+4otnm8x20hcAHZg1cnGCUF5yaRlNJaVzqQLIYQQR2QUR7OyJoayGD0TSzePr3uIy4hKWjoTzko24UxYYj8SxzafaCGEEGKSGJOymMVi3J6xlMnLXdlTXPCk8ESzkk14ZopVzd4z+1yn0xZCCCG2pBN7OnEzjo1iJJOZTFg6xUh/czYTl4n/t8j72aSzycwkprLFODaa7F0nWQghhFjJKH7FeFrFxCx2Yoz9JNtYPI2k/a2ebzHbUFwasBNlE47yUk34aBsro0m/hLYQQgjxCGIsymIVi52dX/RH25i0ZLEzi6e7cQ9x6Uy6Tzy7AGyS2aSziWaTnl0EvBCjthBCCLEFnZiTxU0W3zpxtIqtLH6O4qYlY5uzt7hkJ5VNPF4AnMjKELOLkAlMVoQQQogjMYpbmayMYmS1D8ZjjNdV7Nw1lm4qLs3nXGYmHi8CuyDZBfgk/WzSI3GMTf6uF0QIIcRbUcWZKkZlsTOLg514OYrDWfy2UDvf/S2fbzHbWFwaxIPvCsxo0v+a2Z/Q7ghLdRGcrC2EEELsQRWDslg5ip2xHWNlR2Y6wmLQ3p17iAueZDYBbOLjBWAS07kI8fWji4AXQwghhHgko3jViZWd2MliZTduGunvxubi0lwuiv04+XghcEJnLgReyNHFiGQXJW4XQggh1sDiCos/cZ8YI1nB+FfJSiYv8T1YjO7E9q/GxstEZjuISwO8KHFCqgvRFRac/NhnwsKKEEIIcQSqWMWEpYqFWczE17DC5OUhMfOe4hJPkLXZhVgqMeyZl1ijLI0Ehl2Yu18sIYQQL8MorlSygjWLdVlMnJGVKC0YG7P27txLXDIJyC6MX4xZYRldILwQ8YLgxTFoe18IIYTYEhYXYzuLV50Y2Y2PTGCqGO3cPUbuIi6D51x8DEtmetUkd8vIJuMFcu5yAYQQQggCk5lRHNs7ZlYC43yP7fF8i9lO4lIQT5S1RxcnTuyfUP5Cu3tB2EWojstCjW0hhBCiA4sjnRiUxclR3GOxMvuDlpGsWNG+C/cUlyzgs4uBFwYnll2UTGiy144uzl0vhBBCCBEYycooNrJYmP0xC3svFpMxNmbtXdlNXFYsF7GLkwlLJi9V6QjL6CKNzk0IIYRgdGLKqMzExm6MzOJujM1ZbHS+x/ZaJjLbUVwK4gmz9uyFqZaLsgtVXSB2YbKLJIQQQmxBFQ9ZTKxiI1uFYDFyFBtH8fAhsfHe4hJPENuji8MuUiYp2cXB98ALFNsOXhR2ke5+4YQQQjwdnfiB8YfFKBbHmLxUMbISlkpgnCpO7squ4rJwuQgLuyBZmV3Twx8I9vlG+j4mhBBCLAHjSRZzYiz0mglMJiijLAuLj6O4zOLf99iey0RmO4tLQecCsTKSlU7WpSMxowvE6O4nhBDi/ejGiE5MHMW1LB5WcbGTbWGx++48QlziiV5IvVRg2AWqLlh2cSrbNNIWQgghZsjiCSsYn1gsZHFuJCqzwmKkxvZd2F1cmstFXuPFWiIraJnV69iFu0BboiKEEGJPWBxkMWkUC1ns62RbWCwcyUvke2zvZSKzO4hLAU5EViqByS4EXqgtUmPxeC202ZgQQgjhdGJHNwZWAtOJfWx8NgZiPLwrjxKX7CJ2L1gmMNlFG11Iv3Dxc9mF8vphF0wIIcTLUMUYjEVdWenExNEv75m8WKixfTfuIi4Ty0XexomrDHNkmpmo4IVDgcFjMGh7P9bYFkII8d50YgbGmBh/MD51YmEVE0exkB2DU8bveywTmZn9Gu2wI3iCF1IyE2TCghdq9sJ9wGec7fZ4zMxO0BZCCCFmYcIyioGVrGS/uLM+ExYs2TFhTLw7d8m4mN2YWGZtay/czIXEC8cuYDwG/AFzLlBjWwghxHvSiRVxnGU8Yuzr/uLO4lz1i3tXWpDvsXtlW8zuKC4FeOGy0hEYduFGF7O6cOwiOtmFFEIIISqyeIJx5xFxr5KWQ8S9R4sLXjivl0pL5yL+hXZ1MUcX0blAjW0hhBDvRRbfcJ+sVPEO41g37i2VFws1tu/OXcWluVwU2ziRmcB0L97oQuL7o/niRWQSI4QQQmQwIYgxJotDS35Rr2JeJiyx75Tx+p7LRGZ3FpcEZndYRhdx9mJm0sIuKEpLJiwXqLEthBDiPWBxgMUMFusw5rEYtTbeVb+sj+Lxw+Pa3cWlmXXJLmglMN2LOLrAXYExuz4+IYQQogJjxoywjOLXKLZFecniaVdUvsfunW0xe4C4FGRCgMKA1ollRmCy92AXM7uokQvU2BZCCPHasPs/ixVZnMt+OWexblRQWLJ4x2Iti8mH4JH/jkvkYj//JgpO1Oe/2zJDjBf2j32d0+hiYvn493XxYp5D8WOI7Ytd/5suZvp3XYQQQnAyGWDCskZWRvJSxdJKXgzaD+MhGZfGcpGPY+mY6OgiVhe2urjZBcXjv0CNbSGEEK8Ju++zGMFiWxXjWKyaKVmmBWNcFduc7/FHLBOZHSfjYnY7SZ7NWCIvTGJ+29f5/hPacTtmXP7atlkX31cIIcTrUQVxlIFKWLoxzeOa179hW/U+XWnpiMzdeUjGxezG1NiE4HacYCYwmW3+TtojO2UXN7vI7HwOc6GFEELcDRYDsrjB5CUKzChedeNbJSyx75Rx+VHZFrNjZVzMbicqu8jxwp6tl2nJLnjctjTrYqTNuBTbhBBCPCdVEI+/2I6EpZttqQSlm3lhAlOVw/CwjIvZjbFldjeSl+xiZxfVL+wo8zKTdbFBWwghxHvQiQkxllUxbas4lglLJS3I99gjsy1mx8u4OD4p+JyLZznYXxnFC+1/JYQX+VcoOO79btYlFjzeKqsy2i6EEOJ5GAXxTFg6v4AzgUFZ+W1cYv5Cm0lLJjAG7UNxRHGJgZ1dcLzwUSzwQv+y24vORAa3fYTi7x/bvlzkx2GhbzYvM0IIIZ4fFvRZ3GJxDOWFxS2UFbYtvj4ToVG2JQrL4eTloUtFZlYtF2UX3i92vOiZsWYXGx9mytYEvY0/WJmlxuN1qjEhhBDPS/dez2IYkxavMQ5l8SrLtjBpYRmWKobRmPXoZSKzY2ZczL4m6QTteMFPUPvF9qyIX+wPy20Vl41wycgzLn/seqnIl4v88+NyEV5sMz2oK4QQr0gVwFEGMmnBX7qjdLC41REWJi/sl24mLxZqbB+Gh2dczG4Mjk1UdvG9jhemslW8+PEH4A+p4/swc8VjyeSF/UAIIYR4DbJ7fBa3osCwGIPxKtYshmXCkslLFrey+PvVOEC2xey4GRez2wncM+sS+7/Da/BZl4/wOfigrrcvoXaUdRFCiNehCuAoASgtmGnJsi6ZvGQCk8nLbLalkphDcBhxuVwul9PphMtDV7uEGkuUCa9dPPwHwYXE5STWv6DvFz7+dRIuG/01/tdFeMH1oK4QQrwuGJtim8WqKCne/kPqTF6yVQJvd7ItWUG+x46SbTE7kLgk4ESxrEvMeGDWBbMmfoFH8oKvidLiYpQ96+LH4n99FEXlUowJIYQ4PjEuXaDGMZZlwYwLigZmVTrSkmVcsmxLzLpksnVYDiUuO2RdUF7iD4RnU1Be8N+A8X39T6Jj1uUU2vE4Yj+iJSMhhHheqoDO4lKUF4xVlbBgtmUkMUxaXjLbYnYwcUlgwT/+AGRZF/x3XbL0G5OXmazLX7s+BrZkFGXM+5IVIYR4Xi6hjnEqk5coLB15YaKC7UxWUFxeJttidkBxWZh18SxHlJb4g+Hi8WHXUhKFJWZgZrIubMnI7FpOUGAYEhkhhDguo4DORCCThqXZlk7WBYUlZluyrAvyPXa0bIvZAcUlASeOZV1ijRkRlBcUkm7WxcUFsy6YcWFZF4RlXSQvQghxPPA+zn6BzgrKChbMnHSyLSzjkmVdMMvy1NkWs4OKy4qsy2i5yOUFpSXLusTMy2+7FhcsmHWJx3z+t2aSIlkRQojn4QJ1HI+i0sm2oLCMMi1MZrrS8hLZFrODiksCTiDLurAfGv8BccGIy0UoMGy5CDMvXvwHg2Vd4sO5XuKSkVkuKxIZIYQ4DlXwRgFgYlBlW1BgsuwKkxeUnSgwmbA8fbbF7MDisiDrErMdmHVhS0ZRWipxYdIyyrr4sZhdC5YTJUZLRkIIcUwwmGPciW2UlZlsy0hUKnnpZltYxgX5HjtqtsXswOKSgBOJz5KwHxqXF8+6oLT8gT4uE1XC4q+PWReXpChRju8TxeRCxoQQQhyLC9Q4hoLg8QczLn9CPZKT/0EfRSe+VxSYSlYy4XoaDi0uK7MuUR5i1iUKTMy4sMxLlm1BkYny4p8bj6X6AdGSkRBCHI8qmDMZiAV/efYaRSPLtqCwLMm4jAQG+R47crbF7ODikpBNOJMXzLrgUhFmX5i44J9Ho+y4sPwJn4vFTEtGQgjxLGCcuYQa25Ww4NJQJi2ZwHSEBcWls0Q0kphDc3hxaWRdfLz7Q4TLRr+hHmVazqHOimd5YtZn6ZKR5EUIIe5HJS1srLtEFKWFCcn/khqlpcq2dGSF8T1+9GyL2ROISwKbWBQWXDJykfA6Zl9cWrrZlyzrEot/7sySUSYvQggh7g9KSyYDMfawJSKWaYkS0s2yxDZK0Se0RwJTicyheQpxKbIuPulMCqIwxOUifCbF5QNlpMq4dLMuWMx+jvXz3/0imaxIZIQQYn+qQM5iTCYsWaaFScr/rJdtwUzLKOPCpMWg7f2vxhNkW8yeRFwSmMD4D5DZdbYj/kChvEQpYfLSfViXScs5fG6UKPt3WxQvgz7KiuRFCCH2A4N2FehRWLwd5SHLsmQCMypLpIUJjPMUksJ4GnFpZF1i2y9YzG7EJaO4nPMHxkYZl0pYqsyLf77ZdYbIQo3nJ1kRQoj7g/dmb7MSRYVlXLqyMsq2RIFhWR3//Hhc2TE73+1nybaYPZG4JGBgjz9sUV5itmOrJaORuJxIidkgJ2ZenExWJDJCCLE9VdCuZAULk5UtpGU228KkJfI0ksJ4KnFpZl28z+Ql/nChvEQJ6chKtv9IYiy0sx8qh2VdJC9CCLEdWVBnwpIJTJYByQQmispIWpi8zEoLizXf7WfKtpg9mbgksEDOfrjics3JfoTibNdLRjHrEuWjEpi474m0vcYMkNmPUJ3DmNnPD5XkRQgh9mEkLbjtM9TdjMsoy8JEJm5jwsKWizqZFkvGnoqnE5ck65JdnM9/2y4HmHU52fVyEYpKJSxMWvC153/fPwqM2bW8uLTgDxk7R8mLEEJsQyUtcYz9IhzlhWVZMnlBWelmXLJlIpZpGWVdLNRPl20xe0JxIcQAjj9wXru0eBszLygvnnVh4oJjTFZiidLiJX6+2fWxne2aKC2SFSGE2B4M6JmsRDHwWOJ1JSyYaWEC0xGWLNPCjpMJi0H7KXlKcYGsy/ew8aWWeEEx0+E/cExeMKsyIzDej3KEAhPlxTNDnnlBMlmRyAghxDxV8M4CP2Y1orTgEhGKB8uoVMKSyUuWacmyLJGbc37GbIvZk4qL2Y28xADOLhaTF8y6oLy4gPwOY0xmcJzJD2Zc4jFEXGJ8f8fPiWVdJC9CCNEnC+hZsMclmCgPKCxYUFjYMyz/I+OdTAsKTCZc8Zy+288qLWZPLC4JLIjjBWTygtmRTuaFbUOBYe/HBCZmXs72c5xn+wIFTfIihBDzVNISx6KwMHlBackyLlFOKlHpZFtQXrqZFkvGnpanFpeFD+qa3cpCFJhqyaiSGbYfShErBm3HBSYSpUXyIoQQfUbSgsEfRQWFJUoLk5VMWLoC0xEWLOwcbuTsmbMtZk8uLoQYvOOFwR9MlnVxyUB5wSWjKvPCsitsDIUmLhm5lPhxnu2aSl6EEEKMGUkLSkAUFiYvuDwUpQUFZe3DuKNsCwqLQfvpeXpxWfigLspLNGmUmJky+4xLVpyz8R+4TFYkMkIIcUsVuLOgn2U1mLBkSz1RUjKBGWVbXF66GZbIzXk/e7bF7AXExexGXjx4s4vjP4xmP8LiGY8oDmfLl4wyQYkZmG4mBmUF2368vq/j5+b74DbJixBCfJEF8yzQRyFgwoJLRJnA4LJQZ3moWiLCbMsF2pnEfJ/jK0iL2YuICyEG73ih4oWMAoPy4oJRyUuUlc6yEYoK9v0YHD/+s10LTNwWJU3yIoQQ11TSEsc6wuJtlJYs09IRFRzrSktHWAzaL8PLiMtGS0YuL1EqsL2koKCwMT9O7DsuMJEoLZIXIYT4YSQtLOCz5ZgoL1Faftu1uKCgVEtDSzIuI2GJ3AjLq2RbzF5IXAgxoLNtn/ZDlAX/IXXB+BPaS0r2WiYwFmrHz8GP+Zxsl7wIIcQXs9KCMoBLQ9nyEMpLV1iYtHSEZSbj8jKigryUuJCsSwzc8SLiDy/LumAZCcqoMFHpFuds/IdR8iKEEF/MSkuMA1W2JVsewgxLR14qaRnJS3b8LMZ9dV4o22L2YuJiRuXFjAeU4EC0AAAgAElEQVRzr7vycob2TDmRNhMZI23GmYxJXoQQ784SaWGikglLlWXpCEu2PNTNuFSyYqT/ctJi9oLiQohBm13kbMkoysvZ+JJRR2RQfNgYFgcFxqWELRnF7ZIXIcS7sVRamMCgsFTPtaCw/NduZYVlY0bCUi0TVQLzcqKCvKS4DLIu7ALHH9xMXpikzEgLe10mLUxifNz+fW2UFx9HaZG8CCHegY60xG1RWrJlIbY85HUUj6684OtGS0QdWYnSciMsr5htMXtRcTG7kZcqkHvtmZe4PcqLS4dnXkYik23HguOW1CgcZ7v9gWXniIy2CyHEMzEKzvgLaiy4PMSyLdXyUCUqmbywJSKWaRktFUVu5OVVpcXshcWFEOUF8ewFCszf0GbCUWVfqn2Y4GTFQo1tM559GYmM5EUI8Qqw+zmKSmyzLAvLtsTloSgvLNvSKfg6lmnpPNtSLRO9rKggLy0uE39l5H3/wTiF2gVmJBgoJSgu2T6ZqDBpQfw4Y/bFx82uZU3yIoR4JUbSEsdiQXnpCku2LFRlWCp5QYHJhKVaJnKu5uKVsy1mLy4uZlRezPJA7hIQsy4oL0xCUFKyrErWzgTGQptt9/eJxx6J0iJ5EUK8Ch1pyYQlSgvLuKCw4HMtlbDMLA+NsixMXpCbsVeXFrM3EBdCDOTZ9vjD7UR5wZIt+6yRFtZH4hguGcV9JC9CiFdhjbRUsoKZFrY81BGWLPMShSU+2+J1PJ4qyxKLhfpteAtxWbBkFIXF7Fpaoryc7euHbiQrswJjjZoheRFCvDJbSctfUtYuD1XCgtkWFKbPULOMCxMWg/ZbZFvM3kRczKi8mF0H8zjmdfzBd2kx47KBhWVhOtLCioU6wsYkL0KIV2RLacFsC0oLk5eOsMQ2ig8uEWXLRExUUFpu5uJdpMXsjcSFkAVxv/gs6+JltGQ0WjYaFQu1E8ezfRzJixDildhLWlBeZrIs/4V2lm1BWUFpYVkWlJhIKi/vwluJS7FklP0A4JcgMpKPUemIDH6OhXqE5EUI8QrsIS3smRbMtDB5YaKSyQtbImKZligweB6sWKi/Om+UbTF7M3ExK+XF21e7Wy4sWdalEhT2zMtITOI2RrWtKy8+5khehBBHgN2TsT0rLVmWhS0NVdmV7jMtlbSMMi0oLAbtt5MWszcUFzMqL2a3gdzHvHaBiaLhz7zg+NqC7+dgv0NHXgzarC+EEPdkL2lhWRZvR/lAeWHSgjU+05ItFWXSwoQlnusV7ygtZm8qLoQoLRi8zX4CfxSYSCUZnWJQZxITwddVZPISyc6/8/5CCLElmbSwelZamLxE2WBZlP9C6UoLystoiSi2I6m8vCNvKy4Ln3eJ0hLlIi4b4bZMQjpjTtZm/QwmL1FWKnnrfoYQQqxlFLS3kpZseaizRLTmuRaWaamyLVRa3jXbYvbG4mJWyou3IzHrghJjlssKSkcmLWb52FbiIHkRQhyZe0hLJSyVvKCwRGnBZaZRlgUzLRfSj3MhaQm8tbiYUXkxuw7gOJ4JS3zeJY6jgGRiwwSGtddKzRp58X2FEGJLWCDeS1qqjEsmK5mwZEtEM8+1ZNkWC/U37y4tZhIXBgvgcZvXLjAYyCspGYmMDdpb4fJysvFfHOHnsjEhhFhKV1rw/hvlZUZaomhgdqVaEkJhYUtEKEdZpqUSFnbuIiBxMRs978KyDp6xQIE52XXmBaUjk5W4P5MW3GcLXFpcYOL7Sl6EEPdgRlqwYLZlqbREYakyLLgNsyxZtoVlWvAccB6otCjb8oXE5V8WPKz7aTVMQpioZNuzfSvwix7HkNFfGqG8+JgjeRFCrCEL1rG9RFrwIdwoLkxaMjlhIlNlXJiwVNmWbsblqyNp+UbiEkied/nenIxFgYkCwjIvbL9qO+tXslD9YF/M7CO0L/YjLSfjAhPlxaDtfd9PCCE6ZPdSbHeEJYpLLCgt+CwLLgvFdpZ1Yc+2VNmW2Wda0vu3pOUaiUuNB+pYRzxjEb9UCEoHSomPd7bPMPODPsq+OCgyDhsTQgikkhZWr5GWuDxUSUuVZdky08LOBaUFa0GQuACN513wB4oJC2ZLWNv7nWxKVwqqH3Z23JHOv7CLdUTyIoSo2Fpaus+0VA/jjqRlaaYlWxrKsi1G6q+Osi03SFwIk/Li7Szb8je0R5kVpysA1Zce69E+ZtfHN1o6uoQxx7cJIUQEgy+7h+J9ykUF679Qd59p+W3XwsLE5f+gz5aUOpkWlCtJy4ZIXBIa8hLHY9sFZiaAV1mZ0XikujkgH3bNxX5kpfvn0mb5fHSOVwjx2rB7UCUt3o9BnmUtlj7TMpNtyYRlSbaFyYojaZlE4lKw8C+NRv+nEWvHMRzPJMn79Ice+vilwS8POx+XFheYDCZzlowJId6HSlpYjSVmWTCDgUtD7LmW0fJQbP8fjKO04JJTJSxRWvBcsvvw1VxJWmokLgMW/KVRJSyxrgRlBJOPbFu2n3Ox6782cuKxrnnuxfcXQrwH2f0GgzTeozDIxxqfZ1mSaZnJsmCmBbMtI2HBkgnLDZKWMRKXeVjAZvswgflrHCYyyOiHmX0hcKz75blYb9nIjM+Fsi9CvCfZ/RDb7L6EGQosmbBUz7RgpmUkL2x5KMuyoLxEwaqEJZ53rEUTiUuDxvMu+IP3aT8B/x4wCcnGYh338/JBXofLRtU/Wmf2My8RNiaEeB1YAGb3GmyzJZUoK0xavI5LQ91MSyYvI2mZWSLCrFFLWpRt6SFxabKRvGwduPHLgGN4k8jGLdSx7dvxH6pzgXHw/LPsCxsTQjw3LNhm9xOvsaCwMHHJnmlBaflt/FmV0bLQGmnB447nxO67sf7qSFraSFwmWCEv/kPMmA3iTDpin30psrHsS8WeeTH7OdZR1sXnw6DtsDEhxPPBgm1278G23xexrjItbHkIl4YqYcn6LEuTSQvLsniN55Xdl6/mTdIyh8RlkgXy4j/Enb/QqYg//N6vtnWKhZq9LvsvAjrLRg6KjOOfu3Q+hBCPIwu0eF+JdWxjkGeZlu7y0EhaKnnB/eP7ZdKCz7WMsizZnHx1JC3TSFwW0JAXHzO7lpY1z70wwcja2U2jU+LrvI3PvVzs61yiwLClIyZ0yr4I8dywQIv3B6xZwYCP2Qu2PNSRlq6wdJaGlkhLlBeH3VslLQuRuCyk8W+8xPYaacEvANuO+2U3iiUFl40udp1lcWlZu3Tk+wohjkl2H4rjo/tRlWnB5aGtpKUjLJhtiZ83kpYs42Kk/Y2kZTkSl32IgRh/aGflpbopsC9FdsNYWz6g9vdnmRfMwESUfRHi+bjYLXEsuw+xEgM9y7JsJS2ZsKC4sOWh+CxNV1piMWiLDZG4rKDIunjbSN9sLC+jH/bsJsK+NJ3CvnisYPbFsyyXf9tZ5oUtHRm0HZw3IcTjyO5FcfxC6uweE2smLCNpiYLRkRaUlyzTkklLFJaOtDis/9NRtmUVEpeVNOWFMZKXjPiFYDeIbBxvIKyfpTyxYPYl/rm011Fi4pxERtkXNi6E2J/s3hXHL6SObby3xHtMR1owy5JlW9hDtqMsC2ZacGloibRgca7mUtKyHonLBgzkxfuMrrzgDSGOx+1ZYTKCX77sS/hpXz8nuA/Ky8Xyf+8lzkWVffHtEZxLIcS+sPsVjuH9qHPvqaQFsywx2zJaHsoEZXZpyGtcGpqVlshVX9KyDRKXjWj8pVH2A9uRl/havFGwMXbjGI1lN5psv4txebnYtcDg8tHF8uxLtt3PTwIjxH5cjBPHL6TGdvYL0oy0RKGIkpEJy0heUFiqTMtfWyctWH91JC2bIXHZkA3kJf7wj8CbSbewmwq22X7Z+2X/WN3Ffp57MfuRmJF8aPlIiPuS3XPwHpPV2T0G7y2jpaHR8pDLBmZQMlHJpAUzLSNp8Xp0LzRSf3UkLZsicdmYlfIS/2Sa3RhGfTbelRG8ybB9s/piP/9C8Nm+ZGbmuZcly0dsXAjR52IcHL+QGu812f0ChcVrXJLB7AfLjnSyLZmwoLRgpgWXh+LxSloOhsRlByblxce6/0hddVNhNxa8mbA2FnbziWP+zEt8D1w2ig/ueo0SM6JaPqrGhRA1WTDFe1NWZ/eXSlqw4NLQzDMtI2Fh0pMtDWGmpZIWr81+zt1I/dWRtOyCxGUnJuXF7FpasgwDjmGptuENJt5cPpPxbJ/YR4m5WP+vjlzYfE58G84RtiPZuBDiFnYvwXHWxvvMJ4yxe0MmLSgNbGkIMyVMTDJhQVmploeYUFX3xTgHWf3VkbTshsRlRwby4sS+S0uVdcEbSLaNfdlwfFZaqtf8gtdFacmyL0zUfI6cKDK+3ccj2bgQgt8v2PiF1NjGewveL1BYPu12OSbLsoyyLdW/x4LiUgkLiks8brzH4T3UoO39n46kZVckLjvT/HdeUGY+LZcXdqPplo6AdEQFb1b459Lxr4xQYKK8eH2CUiGBEaJPFkDZfSSrs3sJ1jHwsyzLaHmILe90MywzWRaWacnud5KWAyJxuQMbyQt+WXAsu8Gwm022bW2JAhO/+B92LTCVvFQP70YkMELkZMGT3UNwPN4XvB/vHfG7jYVlWdjy0FJpmc2yoLREifokNZ4fmwucq5+OpOUuSFzuRFNekE+7Dt5OdrPxGtvsSziSELwZsZvTP8n2+NwL/gN17N988TqeK5uruGzk5yiBEeKH7F6C4zP3jnj/iDW7R7BMSyUssWDmpFNQduJ7x8+LwlItD7F7Jc6LczWnkpb7IXG5Iw15YZkFs68vEls6ym44cXt142E3oFEZpVVj+QXb8U+mL6FvdisusZhdz5fvdwlt3yf2nWxciFcgC5o4zgIv3j9Yyb7jKABVlqUSltlsC3sdykon08LuYez8LdTYlrTcGYnLnUnkxYxnEyKfdpuFyL5Q1Y0n9ivpwJsTy7pkN7FY4kO77CHdKDBxDtizL1sKDNsmxDNRBUvcxoIu3kOq+wbeJ9hSS5SDTqblf9DuZFwwM4OFyRJmgeJxx3PK5sBI/Y2k5f5IXB4AkRez28CdfRk+/62Z/GRfPHYz+iT9JdKStWP5BTUTmCXPviAzAjPaJsRRqQIlbot9FoQv0Mf7QnZ/QGEZSUsUFxQWJirVGL42y7KgtLB7FJ4zFiP1N5KWxyBxeRAbyEsViPFL9//bOdvlRJJeCcsz897/Be/YnB8+ZUQ6U1I1eAw4M0Khj2qgu5guPVuNFw0Xp8oYtLBF4DXOv3nB497iM7y8xTvALH/Nb19QBhjrGVU1SRzLOWvAan3AZs7Wgwm0/AcxGts9qcAFoWWyy7I8W8eWsfUR5yf7Dxlavk8Gl2/UAXhZtbUD8Zbq7GbDsbwg5TzfxGyhYjlbwPIxCDELUJbH3ZcV/wLD+cBHSJHGUAYY6xlUNUgcw3sfPca4Lqh1gN37CCyvwYFF7bQgkHSPhHL8F3yGplcwXMfY9ao5yv5DhpbvlcHlm7VugM3/y27E+w2XdyKy1OKkFigcZ4sVgxVcxBBaEGBw1wV3X07B//LoJY0t/wIW6VjUUYBR45b11eoaI47nnDXe6ZqAsbrXEVqqR0Nsl6Xbdal2WBBcEJ4UsOD14TxE4d8TA8tdyOByJyr+4qi7Ud6C777kuDK2UCnDBQxruLghwORFhO2+YB13XvKcsN0XBJhTqkWqrXgdm8dReLxlfaWq+52N5Rre96ym7n21BrD7GkEBdz8mj4cUpHTQgsBSQUs+f3a9aJE8xoaWO5LB5Y505Z9Ls90XvCErmwKLWswqw//fy2tcPipCgFHw8js+775UALOU55HJuzDWd6priDiumitrwOpex/v+FJcNn93nDFjyLosClgpMpsCCsKKgJZ93NrxutEgeY0PLncngcme64s+lIy4BRt2U1eL1RnK1kHVeAUz2CmB+x2d4wb9EeovPv4NhALPGAuKlahdGAUqef0OMdUSTRojHsMaq7u8cV/c83u/VPVw9GqqgZQIqHbBkcHmFWK1DE2BR8/ghQ8v9yeByh7rRj3bZ60/x+fcj7MZW4DJZ3PICN4UXBJj86GgByvJ5F+aU6hXARBpTqgAm11D4Gsuq1DVBNo73uvIYs/t7Aix4bytgmUAL+3Gt+sGtgpajuyx43WyOgvgPGVruUwaXO9UBeFla0KL+6ugUn+GFLWRqccPF4ogpeFkAszzbfVkef//CAGbNQ6Sc7cRUmkJMN279XHXNj43nGotZE861N6ipe1rByrKvhBbM/5K4ApZ83mzdyh7nR/kPGVruVwaXO9bgL44qLYCJuGy+arFTNzlb4DqQ+StiBShs9yXDS96BUbsvCDAv8Rli0CKNn1JtCecZIabbhamOsZ5b3f0Z8fkYlVe+MtbEFbCw+1dBC4LFBFhUno3BCoILrjn5/Nk1M4vkMTawPIAMLg+gK360G8EBJuLzTcwWPbXQIbTgwscMFyHcdUGA6X770gFMhpEFMQpg8nwq5TlGgMk1FH4v3edYj6lps2PHqSaKTba7Z9d9i/EUWBi4MGBhsMKMQQrW/kLMYAWhBdeiZXj9zCJ5jA0tDyKDy4PowI92Vy3vLuSGm6363QsDGLVwVMBSAc3/ggPM3zjvvqydlynAvECc5yNDTKQYQWb5SjsQEzE/zrp/TZscO041T2yu2bMGnO9Vdt/meBdYVsyARcFL95sVNHz/ClgUtOB1q3kK4j9kaHkcGVweSFf87iXi/YZWAJNjtQAqcFFAoiAFLUMKAsyCltcUI7wwgGG2xhBilK1jKuF8XwMxEf3nWd+rncbGjsUaa6Kq2VbGmvfuPYvQgtYBy64pYMmw8jcuzxevg107WhT+Q4aWx5LB5cE0gJdOC2BOcf7hasTnGz7/ZqRaELvFEBcjdQwCzAKX/Pjod/IMYNYYe3yU4SVDzAvEGe46kMm1CcTkOtPOsdbXa3I/Laljsc6aJ2usrPkueyOxukdfiVfAku/H/0jMwANN/dh2Ciy4VuRzZ4ZzpeZu6dP3ZGh5PBlcHlDFj3YjLpss3rC5Ea8Grm74X6SmFg+2MGYYYSDDgGXlGV5e4wwx+bHR8ggxOH6rHZhI8SnVlnIN537V1nFYU2ILavca65iONC/2mqrGGmj2GCvrYKWDlr8kxvsSIaMDFmXsvRS0MOuABdewIHH2HzKwPK4MLg+swe4La6BLb3HZlCeLZV40cIHExZH9qbOCFwSY/LgIwQUBBuO129LtwLzEJcS8pPoL5AH1nJ9SbQlr+D0wiMn1Suz7nLzOOutow1Kvw3rOWawaLObYlLFhq3uRwcpbzICFgcsEWNg4wsqK8+fmc2HnzIAF54XNHfMfMrQ8tgwuD64BvCitY3LjXnVmuAOTF5PfKc6QwnZc/gc5A5gV/0k+Pz7KtsZxFyYDS7UDgwCTa2uO0ELEp1RTYt+LApk8Vkl9z5PXPrOuaU7dvVPVWJx9FaNhs1bAomAF778OWtQuyQRWGOiwz0BYyZavowKWFUeq4Vxj/F4wtDy8DC5PoIOPjpYWtOQmzBbQ1cjZfwX9gfwV4mV/UpwhBhe2P2k8ewUwCDn42xfcdVGPkF4KryxIjLWs9V0sVSATzVinaoHeeZ971q2aUPU+bKxqjthQq5oyBizq/sOGz4Cggxa2M7IDKApW/oPPU9CigIXBSrYgcfYfMrA8jwwuT6TB7ouClyWEGLagKoBZuy4LUNgCyh4HMYCpdl0YwPxOcQUvXwkwCCwnqGVfaRdk2DETTRfx3fe9labnt6vJ+7JjsJZz1TRVY63s1sDCYCXHClg6gMGYQUu2o8DCYCVbFP5DhpbnksHlyTSAF6Y1zpqwWjDyo6O82OTdF7aILuhQAIPAonZdVszsb5xhZgIwCmIUuHQQEyI+pXz5U8qZ1PfGvmOma8HjURf86XlX94TKq0aJDRVjZmxXQQHLK4k7YMmgwmyy26LGKmBBaEJYUcDC5iNbkHjp0/dpaHk+GVyeUFc+Olp6i8vmWy28uAuz4CXvwkwAhvkFKApa8NER7r5MAeY1LiHmJeVHISZEjPNfgQzm+TimKdBEXA81362dhlQdi2MqrxolNlKM0aawcorPDf4IsCC8sEc6O34KLDnGc1fAwmAlWxT+QwaW55XB5Yn1j3dfFqicUjwFmD8pZvDyh/hu5+V34Rm4KIhh8JLjDHgIMQF5ruUx/E7wuFOKWb5Ufa9rPOvIwv5VsHPkXFDde7BxrOWcNcVcY80zG9awISOo5BgNYYXdTwgNDFgUvFRgMoGVCbAoWMnXz+apmnOM3wuGlqeWweXJVcBLBG+aTLk5R3xefFczXzkCzO8UK4DJEIPQwgAGY2UVuPyJS3DJ8ILQgrswL4XvLEhceVbL3+HS+i6Zuu94qQOTyXt8haafq47DuspZQ6w8xpW9FX7FrLkzUHmLS0jYAZYKXHZAhQFLPicGWvlaMa7mLgp/IUPL88vg8gMkHh1FvN/4VUNb46zprgUlx6f4DDB5Ac4AgwsuAgeDFtxhmYCLgpf1+m735ReJ1e6LgpduJyZIjJ59Vzlfx2K+tF5fqfq3cA/qzo2NYy3naqzyGLOcNeEKVhikMGBBeFGwMoEWBiVTYHmFGIEFQSVfk4IVNmdB4iX87gwsP0gGlx+kL9h9OcUZVNDWYxSEl1XL8FKBjIKWHXCp4OW3sF/EHwWYbicmmph5rOXvjAFNiFrW+v7vUdW/STZWNbmqETJfxcxYQz4KLAxWbgEtCk5YDd+TgYqCFmY4R8qi8BcytPwsGVx+mG68+6Lg5S3OzXyN4yK9AGGBDEKLAphl3V8WKXBh0HINwGRwuSXAYB4Dv5RzNobfcT6mGvuXqhoRG8NaztVY5TFmOdoEWLB5XwMsDFZ2wEWBCnsv9bl4rgzETiRWcxgkXsrxe8HA8iNlcPmhunL3ZY1hU10LTo5PcW7oa/FCkMk7MGwnhgHKUWhBcJkADIOXDDHMXgqPMVoUeQy8qqmcfcfrONUY8H2Oqms8ahzrKmeNr/IYszxbByvLK2OwoqBFAQvCyi68KGBBcFGGoIKm5onNbxT+QoaWnyuDyw/WFbsvqLc4N9ZTnHda1iKVG/oax8U7g0IGlwUoDGAQSHagpQIYzH+RmMFLzl9IrCDmBWpBxrAWA9/VVK5qO+NTdf/G2DjWcs6aXdcQVRPFGjbcXFOwkmNs7gpWcozQUIHFLrxUr1Gfz86VXRubE2VB4qUcvxcMLD9eL/43YEVQePkYGnhmuLugjMGAAggGGxXEdDUFLggx2RTEMJBRAINzw2K0KHIWL6nvDcfZmKrtjCt1Cw8brxoaNj12bNUoVZ5N7RowSMkxa+4VrKAxkOjAZVpj79kBCwMVNDZPaDHwFzK0WBHvC7Rl3WL3ZR237BTnRoyLf27sb8S/xhkOWPw33v/tLs9gpIMbBUIKXP7EZ7Bi4MUA5kXkzL+IXEFLBS6dr2KWT8d2VP27wrGcs3jiMWY5/ntlOfMKWhSwIKy8BQcGBRgdvKixHViZAssJYjZ36nvIHuP3goHFSvKOi/VJG7svK2bNkzVe1qzRGBAoY7skE5DpAIbBS84rgGHgwuyFxDhPKg/I1Xcw9dM4S9V3pRYg1chYPPEYq2bKGi5rxgpSmClwQTBg8MDAogORbrwDlSPAwuZt1SLlGK88+wsZWiyUwcWSEgDDmhrzlanGPQWYlaudkVt69v7qfBjEKJBh1888xpWFyHMda0uTmOXTsQjRmMQYa2wqZg0RayxXpkAFvQIXbPIIJwxcFERMdlt2PHtvBVIKWNj1d3Mahcf4veDmZAkZXKxWBwGGNdJs2Jg7gGFwUJnaPZmASrXzokzBVgUvXwUw1fcQA1/FLO/qS2qxwbpqaF0DxCaJcWfXAgs2egUBDFAUVKh4upPS7argObHrUMCCc4YWJM4e4/eCm5LVyOBijTR4fJTjqnGiTQGmAoMOKqrHPpOY5dkUVCloyTleK5sHNlcszxZNLQqvaixXtUps0cFa1eSYx7iqqaarwIWBSs6xySMAMDhQEIGgMQGS6jXKKrD6FmCJCEOLNZLBxdrSAGBU81PNlDXhKcDkHKFhYlOgmRo7FzzfHDNj1888xp2FyHN9CceruKoxsQVHNTTV8FhDZE2zMwUq6Bm4oL2SGCGlAhZl1wJKNjwXdu5fASw5zrXzoBuRtSGDi3VIG4+PVsyaJGuwrDFXjR6BAAGC5cyq38t0Vn3eLrhkY3NQzdPEoomZr2KWd8JFhzW4HDNfxZ2pRowNO9c6eyUxAwaWK6t+lzIFlJxXkIJWzVO2KOKVs/i94AZkHZDBxTqswe5LjpnHOBtrzKypM3jJ8QQulClwUa9Vn6HObWIvJFbzo+ZPzXU08VJVy2K1LLbYsMamalXMctVwWUPOHuPOXkm8Ayyqfg2kMFBh0ILXqeYHLUjMPMbnopuPdVAGF+tqfTHA5CbMfG7qDAgUQExAZAIn3fuxz8Zzq4xd5/JsTrDOLIo8Bh7jqpbFFhvW4CqPMcuzYeOtmnPV0JkhCChoybECFVbbhRXm8fzUdaq5QQsSM4/xueimY10pg4t1M/1DgMkxa+7M2I6HgoyjkFK9L/tcdX7L8LpeSKzmRc1bkPFo4uwxZnknXHRYs1NNEmNWY433jcTZY8zyCghwTEFFBx/TY6rPxfNDY3Og5q2af+YxPhfdbKwbyeBi3Vz/AGCwGaumrkztfFQgsxNjjX2GOhdl7Poqz+YJLYo8Bn4J80646HTNkDVPlmfDJqwadvYYV4aAsAsvR+Pqs5Wx61PzhBYkZh7jc9FNxrqxDC7Wl+kGALP8xKpGPrEKMio/Oab6jF17IXH2GLM8WxR5FB5jlqNwsWFNj3mMWZ4NmzFr1Kqh75ra7VCwMQGSClQ6SMmmrlfNG1oMPMbnopuL9UUyuFhfri8CGKypxs0aPssZSHTQUcFJBSndZ1XnmWuVxxhrQcawHoXHmOUoXGxY82MeY4FWMp0AAAZoSURBVNZcWUN+I3HlWdNHY+BQ7YBU8NGByeSz8DxPEKt5qOY1Bh7jc9FNxfpiGVysf6aDALNi1VSVsQbO/NQ62LgVqCh7aWJ1zSpHiyKP5KtY1dgioxogNtMcq0abDRsza9qswSsQ6GwCF9eASWfqutR8oEURrzx7jM9FNxPrH8ngYv1zbQJMjlVDnZpq9AoQpqYgpIKTakydwwuJK4/xxILElV/CXAkXHGyMzGM8Mda8K48xgwNmFWiosV04YedQXc/UgsTZV/G56CZi/WMZXKxv040AZnnVfLNhE68a/xQgKrtmV0XVWYzXpuKJRRMvqXiirjFWjXVqb02MMKDiCh46mwLK5PPUuatrzhZFjfkqPhfdPKxvksHF+nZ9AcDkeGKs0U+AYQIdO8d178tidf4Y71iQmHmMd8QaI/Oq8U7srYkVHCiYYLXJWHdcdw7VtUwsSMx8FZ+LbhrWN8vgYt2NhgCTc9ZAq+Y7Mdb4K1/FqtYd08WVZ9dR1aKpReExzlp1tcCwBsk8xlWNNXSsKSCYAMQEPCbHsLjy6tqURRMvsRrL34tuFtadyOBi3Z0KgInQTbNrsl2zZsYgJseV72o7x048xiyvLIo8iMe4qkXwZlg1UdZ4WV6ZgpYcT3xX2zm28lVcWYi88lV8IQOLdW8yuFh3qysBJseqEaucWbWDsQs11/iu1p0zWjS1IB7jqpbFFhvWPLEZ57iqobHGX8ELq93aq1p1zmhR5EH8NL6QgcW6VxlcrLvXBsBgrhov81UjV9bBQhdPa9O4Oze0aGpReIyPiDVQ5lmzVjU0BQKTXY4ONnZ2TI5CyrIQ+cRjzPLzgJuCdecyuFgPpQ2I6WLmq/iIdWCD+c6YquWxKMaX4TFB4uyreEeqqbLmWzXurtlXcNDBBI5Px6rajkUTMz+NL2RYsR5JBhfrIbUBMJizmPkqrhp/Zx1s7I5Vr4lijI1HfK7nWhUfUddgVaNmzbxr/GiTnZhbjTGLQZ3FzFcxy88DbgDWA8rgYj20GoCJ+NxcuyZc+arZd7VrbfLopzuHrhYDX8U76ppu5VXjn9Yq2wWQicWgFiSufBWz/HLQC7/1wDK4WE+jTYjBY9nYxDMg6PIKHo6Yej3WqzwGHmOWT1U12q5pT5q/AoaqPrXu9The5bHhMe7GLmRYsZ5FBhfr6bQJMF1eNW/V9Kfxbm3n+CpnceWrmOWdps23a+QVCExzVds9PjZiVcNxrE3zy0Ev8taTyeBiPbW+CGJyPPFdrQONo8d29Ymv4qpWiS06qlGzht/5ChS6/OixEX2t8lU8yS8HvbBbTyyDi/VjdGOIyTlr7Dtexd14d2xVq/w0rmqV2KIzaeBd8+/AoasdPXbHq9qR/HLQi7n1Q2RwsX6kDkAMq02a+wQOduFicox6TXXcNK5qO2KLD2vwKlZQ0MFDByWdn8BId+4Ys1zVzoNewK0fKIOL9aM1AJilClq6vIsnILHrd8eqmOWqtqNJo+6a/i487PrdY6r4SE5lYLF+sgwulvX/ugJiWG0nn0LELpTsjFdxVWPC46aLTAcyO/F0/JrXYnwkV7VPMqxY1rsMLpYldGOQYbXpDkcXq9ceeX+Wq5rSUXCJmDX2KTgw0FD1Sbwztlv7JIOKZXEZXCxroA2IiZg3/kltChhHxyZ5V7+V1GLUAcJRuDg6dosalWHFsnoZXCxrU5sQE7EHAkdru7mqHanfSlNwqeodcHT5tbWqTmVYsaw9GVws60p9MchUYzvvM61V9UrT1xxZcHYAYVpT9er8dt5HyqBiWdfJ4GJZN9YBkInYh5bvGlOavubIgnMEJr5jjMqgYlm3lcHFsr5YB0EmooeBbjzidsdk7R7faXcRmhx/i2O6cSqDimV9rQwulvUNugJmIubgcOvj7kXTRevWx32SIcWy/r0MLpZ1J7oSZpaOvMeR13ynjixaR15zIUOKZd2HDC6Wdce6Ecxk3fr97kU3XcgMKZZ1vzK4WNYD6guAptK//KyIG0NIJQOKZT2eDC6W9WT6x1Bz9zKcWNZzyeBiWT9Ujw44BhLL+pkyuFiWdZV2AcjAYVnWNTK4WJZlWZb1MPrVHWBZlmVZlnUvMrhYlmVZlvUwMrhYlmVZlvUwMrhYlmVZlvUwMrhYlmVZlvUwMrhYlmVZlvUwMrhYlmVZlvUwMrhYlmVZlvUw+j8ss1rMfWwjaQAAAABJRU5ErkJggg=="/>\n            </g>\n            <circle cx="1122.29" cy="672.21" r="254.26" style="fill:url(#arch-未命名的渐变_4-2)"/>\n            <circle id="center-circle" cx="1122.29" cy="672.21" r="254.26" style="mix-blend-mode:multiply;fill:url(#arch-未命名的渐变_8)"/>\n\n            <g id="tr" style="cursor: pointer;">\n                <rect id="text-bg-tr" />\n                <circle id="cir-tr" cx="1504.6" cy="227.44" r="60.56" style="fill:#83c2ff"/>\n                <text id="text-micro" x="1645.71" y="386.35" style="font-size:70.86614227294922px;font-family:DINOT-Medium,DIN OT">\n                    Microservices\n                </text>\n                <path id="icon-micro" d="M1731.48,224.93a2.35,2.35,0,0,1-1-4.48l2-.92c0-.2,0-.41,0-.61a7,7,0,1,1,2,4.86l-2,.94A2.42,2.42,0,0,1,1731.48,224.93Zm-43.34,1a7,7,0,1,1,7-7c0,.21,0,.41,0,.61l2,.93a2.34,2.34,0,0,1-1,4.47,2.21,2.21,0,0,1-1-.22l-2-.93A7,7,0,0,1,1688.14,225.94Zm28,26.1a7,7,0,1,1-4.67,0V249.3a2.34,2.34,0,0,1,4.67,0Zm21-14.42a9.36,9.36,0,1,1-8.6,5.69l-4.33-3.34a14,14,0,0,1-20.94-.08l-4.29,3.35a9.25,9.25,0,0,1,.77,3.73,9.35,9.35,0,1,1-3.65-7.41l4.69-3.66a14,14,0,0,1,10.65-19.11v-5.16a9.35,9.35,0,1,1,4.67,0v5.16a14,14,0,0,1,10.6,19.21l4.68,3.6A9.33,9.33,0,0,1,1737.21,237.62Z" style="fill-rule:evenodd"/>\n            </g>\n\n            <g id="tl" style="cursor: pointer;">\n                <rect id="text-bg-tl" />\n                <circle id="cir-tl" cx="440.53" cy="236.83" r="60.56" style="fill:#83c2ff"/>\n                <text id="text-servi" style="font-size:70.86614227294922px;font-family:DINOT-Medium,DIN OT">\n                    <tspan x="127.33" y="389.35">Service</tspan>\n                    <tspan x="127.33" y="479.35">Mesh</tspan>\n                </text>\n                <path id="icon-servi" d="M217,213.32a6.44,6.44,0,0,0-12.79-1.12l-45.12-10.34a6.44,6.44,0,0,0-12.55,2,6.34,6.34,0,0,0,1.42,4l-10.85,18.41a6.37,6.37,0,0,0-3.29-.93,6.46,6.46,0,1,0,2.07,12.54l22.89,19.42a6.44,6.44,0,1,0,11.64,4.6H199.7a6.44,6.44,0,1,0,7.38-7.26l4.25-35A6.44,6.44,0,0,0,217,213.32Zm-12.83.75a6.6,6.6,0,0,0,.58,2l-19.38,7a6.44,6.44,0,0,0-10.92-3.25l-16.23-12.25a6.32,6.32,0,0,0,1.22-3.74v-.06ZM153,210.34a6.37,6.37,0,0,0,4-1.39l16.44,12.42a6.41,6.41,0,0,0-.71,2.27l-32.51,7.05a6.35,6.35,0,0,0-1.61-3.24l10.77-18.27A6.45,6.45,0,0,0,153,210.34Zm-12.79,22.22,32.51-7.06a6.44,6.44,0,0,0,3.74,4.79L166.23,255a6.47,6.47,0,0,0-2.21-.41,6.38,6.38,0,0,0-4,1.44L137.6,237A6.41,6.41,0,0,0,140.16,232.56Zm27.7,23.28,10.34-25.08a5.29,5.29,0,0,0,.81.08,6.44,6.44,0,0,0,2.36-.46l19.53,26.79a6.27,6.27,0,0,0-1.2,2.91H170.38A6.44,6.44,0,0,0,167.86,255.84Zm37.38-1.21a6.44,6.44,0,0,0-3,1.22L183,229.45a6.41,6.41,0,0,0,2.43-4.39l20.38-7.39a6.41,6.41,0,0,0,3.71,2Z"/>\n            </g>\n\n            <g id="bl" style="cursor: pointer;">                \n                <rect id="text-bg-bl" />\n                <circle id="cir-bl" cx="613.44" cy="1241.44" r="60.56" style="fill:#83c2ff"/>\n                <path id="icon-immut" d="M215.56,1236.23h-1.91l-4.5,0a5.46,5.46,0,0,1-2.5-.89c-.05,0-.07,0-.1-.06a5.75,5.75,0,0,1-2.61-4.9,5.69,5.69,0,0,1,.33-1.83,4.74,4.74,0,0,1,.94-1.79l1-1,2.23-2.2,1.31-1.33a6.86,6.86,0,0,0-.07-8.46l-3.83-3.93a7,7,0,0,0-8.55-.12l-1.39,1.33-3.11,3.18h0a5.81,5.81,0,0,1-6,.78,5.72,5.72,0,0,1-3.49-4.69v-6.45a6.82,6.82,0,0,0-6.06-5.94h-5.46a7,7,0,0,0-6.1,5.9v6.39c0,.16-.08.34-.1.49v.06a2.78,2.78,0,0,0-.08.46.06.06,0,0,0-.06.06,2.46,2.46,0,0,1-.17.46,3.71,3.71,0,0,1-.24.49v0a5,5,0,0,1-1.42,1.77,5.84,5.84,0,0,1-3.81,1.39,5.65,5.65,0,0,1-3.61-1.27l-1-1-2.22-2.18-1.35-1.37a6.86,6.86,0,0,0-8.47.1l-3.92,3.87a7,7,0,0,0-.12,8.5l1.35,1.33,3.17,3.15.17.28s.08.1.16.2.08.18.14.26.11.12.11.18.12.22.18.33a.35.35,0,0,0,.06.18,2.67,2.67,0,0,0,.17.34.55.55,0,0,0,0,.16c0,.18.11.32.11.5a1.88,1.88,0,0,1,.07.53,5.68,5.68,0,0,1-1.68,4.88,5.74,5.74,0,0,1-3.45,1.67h-6.39a7,7,0,0,0-6,6l0,5.5a6.84,6.84,0,0,0,5.91,6.07h1.92l4.46.06a2.34,2.34,0,0,1,.53.08h.15a1.19,1.19,0,0,0,.39.12,5.91,5.91,0,0,1,2.87,9.31l-1,1-2.24,2.19-1.35,1.34a7,7,0,0,0,.07,8.48l3.9,3.93a6.92,6.92,0,0,0,8.51.08l1.33-1.33,3.19-3.12s0,0,.07-.06a3.45,3.45,0,0,0,.34-.3.39.39,0,0,0,.22-.08l.24-.19c.11-.06.25-.08.36-.14s.12-.06.14-.1a4.07,4.07,0,0,0,.51-.14,1.79,1.79,0,0,1,.46-.14h0l.49-.1h0a.89.89,0,0,0,.4-.06,5.92,5.92,0,0,1,4.5,1.75,5.83,5.83,0,0,1,1.7,3.49l0,1.37v5a6.79,6.79,0,0,0,6,6H177a6.85,6.85,0,0,0,6.07-5.86v-1.9l.05-3.22v-1.27a5.77,5.77,0,0,1,1.16-2.94,1.08,1.08,0,0,1,.19-.22s.08-.15.18-.19a7.14,7.14,0,0,1,1.17-1,.89.89,0,0,0,.35-.18c.1-.06.1-.06.14-.06l.11,0a1.64,1.64,0,0,1,.33-.14l-5.27-5.26A25.77,25.77,0,1,1,200.14,1245a25,25,0,0,1-1,7l5.32,5.23a6.68,6.68,0,0,1,1.18-1.72,6.43,6.43,0,0,1,1.94-1.19,5.43,5.43,0,0,1,1.5-.44h6.43a6.9,6.9,0,0,0,6-6v-5.56a6.86,6.86,0,0,0-5.87-6.06ZM206,1279.67a3.38,3.38,0,0,1-3.37-3.35,3.34,3.34,0,0,1,3.37-3.26,3.29,3.29,0,0,1,3.32,3.26A3.33,3.33,0,0,1,206,1279.67Zm5.08-7.62-18.92-18.69a19.61,19.61,0,0,0-17.72-28,19.72,19.72,0,0,0-5.24.7l8.39,8.37c3.49,3.5,3.22,9.37-.56,13.14s-9.65,4-13.13.56l-8.38-8.42a19.72,19.72,0,0,0,18.92,24.93,19.2,19.2,0,0,0,8.39-1.91l18.84,18.72a6.37,6.37,0,0,0,9-.4c2.57-2.56,2.76-6.62.41-9Z" style="fill-rule:evenodd"/>\n                <text id="text-immut" style="font-size:70.86614227294922px;font-family:DINOT-Medium,DIN OT">\n                    <tspan x="127.33" y="1390.81">Immutable</tspan>\n                    <tspan x="127.33" y="1480.81">infrastructure</tspan>\n                </text>\n            </g>\n\n            <g id="br" style="cursor: pointer;">\n                <rect id="text-bg-br" />\n                <circle id="cir-br" cx="1665.77" cy="1241.44" r="60.56" style="fill:#83c2ff"/>\n                <path id="icon-decla" d="M1857.79,1248.27a.76.76,0,0,0-1.08,0l-6.4,6.39-8.67-8.67,6.4-6.4a.77.77,0,0,0,0-1.09l-3.49-3.5a.79.79,0,0,0-1.09,0l-6.4,6.41-4.13-4.13a.82.82,0,0,0-.55-.22.85.85,0,0,0-.55.22l-9.78,9.79a19.23,19.23,0,0,0-2.33,24.34l-7.31,7.31a.77.77,0,0,0,0,1.09l4.07,4.07a.79.79,0,0,0,.55.22.82.82,0,0,0,.55-.22l7.31-7.31a19.21,19.21,0,0,0,24.35-2.33l9.79-9.79a.76.76,0,0,0,0-1.08l-4.13-4.13,6.41-6.41a.79.79,0,0,0,0-1.09Zm32.54-38.22-4.07-4.07a.79.79,0,0,0-.55-.22.83.83,0,0,0-.55.22l-7.31,7.31a19.24,19.24,0,0,0-24.35,2.33l-9.79,9.79a.77.77,0,0,0,0,1.09l26.1,26.09a.75.75,0,0,0,.54.22.82.82,0,0,0,.55-.22l9.79-9.79a19.22,19.22,0,0,0,2.33-24.34l7.31-7.31A.78.78,0,0,0,1890.33,1210.05Z" style="fill-rule:evenodd"/>\n                <text id="text-decla" x="1812.55" y="1390.81" style="font-size:70.86614227294922px;font-family:DINOT-Medium,DIN OT">\n                    Declarative API\n                </text>\n            </g>\n\n            <g id="text-cloud" style="cursor: pointer;">\n                <rect x="1100" y="704.07" width="640" height="149.62" style="fill:#fff;stroke:#afafaf;stroke-miterlimit:10"/>\n                <text x="1150" y="808.39" style="font-size:90.15303039550781px;font-family:DINOT-Medium,DIN OT">\n                    Cloud Native\n                </text>\n            </g>\n        </g>\n    </g>\n</svg>\n';

    function me(t, e) {
        var n = Object.keys(t);
        return Object.getOwnPropertySymbols && n.push.apply(n, Object.getOwnPropertySymbols(t)), e && (n = n.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), n
    }

    function ve(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? arguments[e] : {};
            e % 2 ? me(n, !0).forEach(function (e) {
                ge(t, e, n[e])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : me(n).forEach(function (e) {
                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
            })
        }
        return t
    }

    function ge(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function xe(t, e) {
        var n = JSON.parse(JSON.stringify(t));
        for (var r in e) for (var i in e[r]) for (var o in e[r][i]) {
            var s = n[r][i][o], a = e[r][i][o];
            n[r][i][o] = "function" == typeof a ? a(s, t[r]) : a
        }
        return n
    }

    var be = "#2e73d7", we = {r: 60.56, fill: "#83c2ff"}, Ae = {r: 110, fill: be}, qe = {r: 45}, Le = {fill: "#000"},
        Ee = {fill: "#fff"}, Se = {fill: "#929292"}, Ce = {fill: "#000", hasBG: !1}, Ve = {fill: "#fff", hasBG: !0},
        Ue = {fill: "#929292"}, je = {
            TL: {
                circle: ve({pos: [440.53, 236.83]}, we),
                icon: ve({pos: [172, 232]}, Le),
                text: ve({dmove: [70, 0]}, Ce)
            },
            TR: {
                circle: ve({pos: [1504.6, 227.44]}, we),
                icon: ve({pos: [1713, 229]}, Le),
                text: ve({dmove: [-40, -50]}, Ce)
            },
            BR: {
                circle: ve({pos: [1665.77, 1241.44]}, we),
                icon: ve({pos: [1851, 1244]}, Le),
                text: ve({dmove: [-300, 160]}, Ce)
            },
            BL: {
                circle: ve({pos: [613.44, 1241.44]}, we),
                icon: ve({pos: [172, 1244]}, Le),
                text: ve({dmove: [155, 180]}, Ce)
            }
        }, ke = xe(je, {
            TL: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] - 100, t[1] - 100]
                    }
                }, Ae), icon: ve({
                    pos: function (t, e) {
                        return [e.circle.pos[0] - 100, e.circle.pos[1] - 100]
                    }
                }, Ee), text: ve({}, Ve)
            }, TR: {
                circle: {
                    pos: function (t) {
                        return [t[0] - 40, t[1] + 30]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }, BR: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] - 70, t[1] - 160]
                    }
                }, qe), icon: ve({}, Se), text: ve({}, Ue)
            }, BL: {
                circle: {
                    pos: function (t) {
                        return [t[0] + 120, t[1] + 10]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }
        }), Ie = xe(je, {
            TR: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] + 300, t[1] - 150]
                    }
                }, Ae), icon: ve({
                    pos: function (t, e) {
                        return [e.circle.pos[0] + 300, e.circle.pos[1] - 150]
                    }
                }, Ee), text: ve({}, Ve)
            }, TL: {
                circle: {
                    pos: function (t) {
                        return [t[0] + 270, t[1] + 50]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }, BR: {
                circle: {
                    pos: function (t) {
                        return [t[0] - 100, t[1] + 70]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }, BL: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] - 50, t[1] - 100]
                    }
                }, qe), icon: ve({}, Se), text: ve({}, Ue)
            }
        }), Fe = xe(je, {
            BR: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] + 70, t[1] + 70]
                    }
                }, Ae), icon: ve({
                    pos: function (t, e) {
                        return [e.circle.pos[0] + 70, e.circle.pos[1] + 70]
                    }
                }, Ee), text: ve({}, Ve)
            }, TR: {
                circle: {
                    pos: function (t) {
                        return [t[0] + 60, t[1] + 20]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }, TL: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] + 270, t[1] + 20]
                    }
                }, qe), icon: ve({}, Se), text: ve({}, Ue)
            }, BL: {
                circle: {
                    pos: function (t) {
                        return [t[0] - 65, t[1] - 100]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }
        }), Re = xe(je, {
            BL: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] - 100, t[1] + 100]
                    }
                }, Ae), icon: ve({
                    pos: function (t, e) {
                        return [e.circle.pos[0] - 100, e.circle.pos[1] + 100]
                    }
                }, Ee), text: ve({}, Ve)
            }, TR: {
                circle: ve({
                    pos: function (t) {
                        return [t[0] - 60, t[1] + 60]
                    }
                }, qe), icon: ve({}, Se), text: ve({}, Ue)
            }, BR: {
                circle: {
                    pos: function (t) {
                        return [t[0] - 100, t[1] - 100]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }, TL: {
                circle: {
                    pos: function (t) {
                        return [t[0] + 60, t[1] + 60]
                    }
                }, icon: ve({}, Se), text: ve({}, Ue)
            }
        });

    function Be(t) {
        return function (t) {
            if (Array.isArray(t)) {
                for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                return n
            }
        }(t) || function (t) {
            if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
        }(t) || function () {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        }()
    }

    function We(t) {
        t("TL"), t("TR"), t("BR"), t("BL")
    }

    function Pe(t, e) {
        Object.keys(e).forEach(function (n) {
            var r = document.createElement("div");
            Nt(t).appendChild(r), r.innerHTML = e[n].svg, r.setAttribute("id", n)
        })
    }

    var Te = function () {
        Nt("#js-home-animation") && (Pe("#js-home-animation", {
            debris1: {svg: le},
            debris2: {svg: ue},
            debris3: {svg: he},
            box: {svg: ce}
        }), de(), Pe("#js-arch-animation", {arch: {svg: ye}}), function () {
            ae.a.select("#arch svg").first().size(600, 440);
            var t = {duration: 300}, e = {
                    TR: ae.a.select("#arch #tr").first(),
                    TL: ae.a.select("#arch #tl").first(),
                    BL: ae.a.select("#arch #bl").first(),
                    BR: ae.a.select("#arch #br").first()
                }, n = {
                    TR: ae.a.select("#arch #cir-tr").first(),
                    TL: ae.a.select("#arch #cir-tl").first(),
                    BL: ae.a.select("#arch #cir-bl").first(),
                    BR: ae.a.select("#arch #cir-br").first()
                }, r = {
                    TR: ae.a.select("#arch #icon-micro").first(),
                    TL: ae.a.select("#arch #icon-servi").first(),
                    BL: ae.a.select("#arch #icon-immut").first(),
                    BR: ae.a.select("#arch #icon-decla").first()
                }, i = {
                    TR: ae.a.select("#arch #text-micro"),
                    TL: ae.a.select("#arch #text-servi tspan"),
                    BL: ae.a.select("#arch #text-immut tspan"),
                    BR: ae.a.select("#arch #text-decla")
                }, o = {
                    TR: ae.a.select("#arch #text-bg-tr").first(),
                    TL: ae.a.select("#arch #text-bg-tl").first(),
                    BL: ae.a.select("#arch #text-bg-bl").first(),
                    BR: ae.a.select("#arch #text-bg-br").first()
                }, s = ae.a.select("#arch #border-line").first(), a = ae.a.select("#arch #main-bg").first(),
                c = ae.a.select("#arch #cross-line-1").first(), l = ae.a.select("#arch #cross-line-2").first(),
                u = ae.a.select("#arch #cir-shadow").first(), h = ae.a.select("#arch #text-cloud").first(), f = "INIT",
                p = {INIT: je, TL: ke, TR: Ie, BL: Re, BR: Fe};

            function d(e) {
                if (f !== e) {
                    var d = p[e];
                    We(function (r) {
                        var i = d[r].circle;
                        r === e ? n[r].style({filter: "url(#dropshadow)"}) : n[r].style({filter: "none"}), n[r].animate(t).attr({
                            cx: i.pos[0],
                            cy: i.pos[1],
                            r: i.r
                        }).style({fill: i.fill})
                    }), We(function (n) {
                        var i = d[n].icon;
                        n === e && r[n].center(i.pos[0], i.pos[1]).attr({
                            fill: i.fill,
                            opacity: 0
                        }).animate({
                            delay: t.duration,
                            duration: 200
                        }).attr({opacity: 1}), r[n].center(i.pos[0], i.pos[1]).animate(t).attr({fill: i.fill})
                    }), We(function (n) {
                        var r, s = d[n].text, a = i[n], c = o[n], l = [0, 0];
                        if (s.dmove && (f === n ? l = [-s.dmove[0], -s.dmove[1]] : e === n && (l = s.dmove)), s.hasBG) {
                            var u, h = a.bbox();
                            c.attr({
                                x: h.x - 32,
                                y: h.y - 16,
                                width: h.width + 64,
                                height: h.height + 32,
                                fill: "#fff",
                                opacity: 0
                            }), (u = c.animate({duration: 5})).dmove.apply(u, Be(l)).animate({duration: t.duration}).attr({
                                fill: be,
                                opacity: 1
                            })
                        } else c.attr({x: 0, y: 0, width: 0, height: 0, opacity: 0});
                        (r = a.animate({duration: 5})).dmove.apply(r, Be(l)).attr({fill: s.fill})
                    });
                    var y = new ae.a.PointArray([d.TR.circle.pos, d.TL.circle.pos, d.BL.circle.pos, d.BR.circle.pos, d.TR.circle.pos]).toString();
                    s.animate(t).attr({points: y}), a.animate(t).attr({points: y}), c.animate(t).attr({
                        x1: d.TL.circle.pos[0],
                        y1: d.TL.circle.pos[1],
                        x2: d.BR.circle.pos[0],
                        y2: d.BR.circle.pos[1]
                    }), l.animate(t).attr({
                        x1: d.TR.circle.pos[0],
                        y1: d.TR.circle.pos[1],
                        x2: d.BL.circle.pos[0],
                        y2: d.BL.circle.pos[1]
                    }), "L" === e[1] ? u.animate(t).move(0) : u.animate(t).move(90);
                    var m = "R" === e[1] ? -440 : 100, v = "T" === e[0] ? 30 : -60;
                    "INIT" === e && (m = 0, v = 0), h.animate(t).move(m, v).opacity("INIT" === e ? 1 : .6), f = e
                }
            }

            function y(t) {
                Zt("#js-arch .row").forEach(function (t) {
                    t.classList.remove("-selected")
                }), Nt("#js-arch .".concat(t)).classList.add("-selected")
            }

            var m = !1, v = "NONE", g = function (t) {
                v = t, !1 === m && (d(v), m = !0, setTimeout(function () {
                    m = !1, d(v)
                }, 500))
            };
            Zt("#js-arch .row").forEach(function (t) {
                function e(t) {
                    return Array.from(t.classList).filter(function (t) {
                        return t === t.toUpperCase()
                    })[0]
                }

                t.addEventListener("mouseenter", function () {
                    var t = e(this);
                    g(t), y(t)
                }), t.addEventListener("mouseleave", function () {
                    var t = e(this);
                    g(t), y(t)
                })
            }), Object.keys(n).forEach(function (t) {
                e[t].on("mouseenter", function () {
                    g(t), y(t)
                })
            }), h.on("mouseenter", function () {
                g("INIT"), y("INIT")
            })
        }())
    }, Ye = n(22), Ge = n.n(Ye);
    n(46);
}]);